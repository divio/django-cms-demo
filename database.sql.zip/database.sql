--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: aldryn_bootstrap3_boostrap3alertplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3alertplugin (
    cmsplugin_ptr_id integer NOT NULL,
    context character varying(255) NOT NULL,
    classes text NOT NULL,
    icon character varying(255) NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3alertplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3blockquoteplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3blockquoteplugin (
    cmsplugin_ptr_id integer NOT NULL,
    reverse boolean NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3blockquoteplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3buttonplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3buttonplugin (
    cmsplugin_ptr_id integer NOT NULL,
    btn_context character varying(255) NOT NULL,
    label character varying(256) NOT NULL,
    link_url character varying(200) NOT NULL,
    btn_size character varying(255) NOT NULL,
    classes text NOT NULL,
    icon_left character varying(255) NOT NULL,
    icon_right character varying(255) NOT NULL,
    link_page_id integer,
    link_anchor character varying(128) NOT NULL,
    link_mailto character varying(75),
    link_phone character varying(40),
    link_target character varying(100) NOT NULL,
    link_file_id integer,
    type character varying(10) NOT NULL,
    txt_context character varying(255) NOT NULL,
    btn_block boolean NOT NULL,
    responsive text NOT NULL,
    responsive_print text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3buttonplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3iconplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3iconplugin (
    cmsplugin_ptr_id integer NOT NULL,
    icon character varying(255) NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3iconplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3imageplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3imageplugin (
    cmsplugin_ptr_id integer NOT NULL,
    file_id integer,
    alt text NOT NULL,
    title text NOT NULL,
    aspect_ratio character varying(10) NOT NULL,
    thumbnail boolean NOT NULL,
    shape character varying(64) NOT NULL,
    classes text NOT NULL,
    img_responsive boolean NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3imageplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3labelplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3labelplugin (
    cmsplugin_ptr_id integer NOT NULL,
    label character varying(256) NOT NULL,
    context character varying(255) NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3labelplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3panelbodyplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3panelbodyplugin (
    cmsplugin_ptr_id integer NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3panelbodyplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3panelfooterplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3panelfooterplugin (
    cmsplugin_ptr_id integer NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3panelfooterplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3panelheadingplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3panelheadingplugin (
    cmsplugin_ptr_id integer NOT NULL,
    title text NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3panelheadingplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3panelplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3panelplugin (
    cmsplugin_ptr_id integer NOT NULL,
    context character varying(255) NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3panelplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3spacerplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3spacerplugin (
    cmsplugin_ptr_id integer NOT NULL,
    size character varying(255) NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3spacerplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3wellplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3wellplugin (
    cmsplugin_ptr_id integer NOT NULL,
    size character varying(255) NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3wellplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3accordionitemplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3accordionitemplugin (
    cmsplugin_ptr_id integer NOT NULL,
    title text NOT NULL,
    context character varying(255) NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3accordionitemplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3accordionplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3accordionplugin (
    cmsplugin_ptr_id integer NOT NULL,
    classes text NOT NULL,
    index integer,
    CONSTRAINT aldryn_bootstrap3_bootstrap3accordionplugin_index_check CHECK ((index >= 0)),
    CONSTRAINT ck_index_pstv_363f4afeaf9b2ab9 CHECK ((index >= 0))
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3accordionplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3carouselplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3carouselplugin (
    cmsplugin_ptr_id integer NOT NULL,
    style character varying(50) NOT NULL,
    transition_effect character varying(50) NOT NULL,
    ride boolean NOT NULL,
    "interval" integer NOT NULL,
    wrap boolean NOT NULL,
    pause boolean NOT NULL,
    classes text NOT NULL,
    aspect_ratio character varying(10) NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3carouselplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3carouselslidefolderplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3carouselslidefolderplugin (
    cmsplugin_ptr_id integer NOT NULL,
    folder_id integer NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3carouselslidefolderplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3carouselslideplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3carouselslideplugin (
    cmsplugin_ptr_id integer NOT NULL,
    link_url character varying(200) NOT NULL,
    link_page_id integer,
    link_file_id integer,
    link_anchor character varying(128) NOT NULL,
    link_mailto character varying(75),
    link_phone character varying(40),
    link_target character varying(100) NOT NULL,
    image_id integer,
    link_text character varying(200) NOT NULL,
    content text NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3carouselslideplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3columnplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3columnplugin (
    cmsplugin_ptr_id integer NOT NULL,
    classes text NOT NULL,
    xs_col integer,
    xs_offset integer,
    sm_col integer,
    sm_offset integer,
    md_col integer,
    md_offset integer,
    lg_col integer,
    lg_offset integer,
    xs_push integer,
    xs_pull integer,
    sm_push integer,
    sm_pull integer,
    md_push integer,
    md_pull integer,
    lg_push integer,
    lg_pull integer,
    tag character varying(50) NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3columnplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3listgroupitemplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3listgroupitemplugin (
    cmsplugin_ptr_id integer NOT NULL,
    title text NOT NULL,
    context character varying(255) NOT NULL,
    classes text NOT NULL,
    state character varying(255) NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3listgroupitemplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3listgroupplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3listgroupplugin (
    cmsplugin_ptr_id integer NOT NULL,
    classes text NOT NULL,
    add_list_group_class boolean NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3listgroupplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3rowplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3rowplugin (
    cmsplugin_ptr_id integer NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3rowplugin OWNER TO postgres;

--
-- Name: aldryn_forms_emailfieldplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_forms_emailfieldplugin (
    cmsplugin_ptr_id integer NOT NULL,
    label character varying(50) NOT NULL,
    required boolean NOT NULL,
    required_message text,
    placeholder_text character varying(50) NOT NULL,
    help_text text,
    min_value integer,
    max_value integer,
    custom_classes character varying(200) NOT NULL,
    email_send_notification boolean NOT NULL,
    email_subject character varying(200) NOT NULL,
    email_body text NOT NULL,
    CONSTRAINT aldryn_forms_emailfieldplugin_max_value_check CHECK ((max_value >= 0)),
    CONSTRAINT aldryn_forms_emailfieldplugin_min_value_check CHECK ((min_value >= 0))
);


ALTER TABLE public.aldryn_forms_emailfieldplugin OWNER TO postgres;

--
-- Name: aldryn_forms_fieldplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_forms_fieldplugin (
    cmsplugin_ptr_id integer NOT NULL,
    label character varying(50) NOT NULL,
    required boolean NOT NULL,
    placeholder_text character varying(50) NOT NULL,
    help_text text,
    min_value integer,
    max_value integer,
    required_message text,
    custom_classes character varying(200) NOT NULL,
    CONSTRAINT ck_max_value_pstv_706481aa8173c858 CHECK ((max_value >= 0)),
    CONSTRAINT ck_min_value_pstv_7ccbc9ba76b9dbfa CHECK ((min_value >= 0)),
    CONSTRAINT cmsplugin_fieldplugin_max_value_check CHECK ((max_value >= 0)),
    CONSTRAINT cmsplugin_fieldplugin_min_value_check CHECK ((min_value >= 0))
);


ALTER TABLE public.aldryn_forms_fieldplugin OWNER TO postgres;

--
-- Name: aldryn_forms_fieldsetplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_forms_fieldsetplugin (
    cmsplugin_ptr_id integer NOT NULL,
    legend character varying(50) NOT NULL,
    custom_classes character varying(200) NOT NULL
);


ALTER TABLE public.aldryn_forms_fieldsetplugin OWNER TO postgres;

--
-- Name: aldryn_forms_fileuploadfieldplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_forms_fileuploadfieldplugin (
    cmsplugin_ptr_id integer NOT NULL,
    label character varying(50) NOT NULL,
    required boolean NOT NULL,
    required_message text,
    placeholder_text character varying(50) NOT NULL,
    help_text text,
    min_value integer,
    max_value integer,
    custom_classes character varying(200) NOT NULL,
    upload_to_id integer NOT NULL,
    max_size bigint,
    CONSTRAINT aldryn_forms_fileuploadfieldplugin_max_value_check CHECK ((max_value >= 0)),
    CONSTRAINT aldryn_forms_fileuploadfieldplugin_min_value_check CHECK ((min_value >= 0))
);


ALTER TABLE public.aldryn_forms_fileuploadfieldplugin OWNER TO postgres;

--
-- Name: aldryn_forms_formbuttonplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_forms_formbuttonplugin (
    cmsplugin_ptr_id integer NOT NULL,
    label character varying(50) NOT NULL,
    custom_classes character varying(200) NOT NULL
);


ALTER TABLE public.aldryn_forms_formbuttonplugin OWNER TO postgres;

--
-- Name: aldryn_forms_formdata; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_forms_formdata (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    data text,
    sent_at timestamp with time zone NOT NULL,
    language character varying(10) NOT NULL
);


ALTER TABLE public.aldryn_forms_formdata OWNER TO postgres;

--
-- Name: aldryn_forms_formdata_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_forms_formdata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_forms_formdata_id_seq OWNER TO postgres;

--
-- Name: aldryn_forms_formdata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_forms_formdata_id_seq OWNED BY aldryn_forms_formdata.id;


--
-- Name: aldryn_forms_formdata_people_notified; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_forms_formdata_people_notified (
    id integer NOT NULL,
    formdata_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.aldryn_forms_formdata_people_notified OWNER TO postgres;

--
-- Name: aldryn_forms_formdata_people_notified_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_forms_formdata_people_notified_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_forms_formdata_people_notified_id_seq OWNER TO postgres;

--
-- Name: aldryn_forms_formdata_people_notified_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_forms_formdata_people_notified_id_seq OWNED BY aldryn_forms_formdata_people_notified.id;


--
-- Name: aldryn_forms_formplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_forms_formplugin (
    cmsplugin_ptr_id integer NOT NULL,
    name character varying(50) NOT NULL,
    error_message text,
    redirect_type character varying(20) NOT NULL,
    page_id integer,
    url character varying(200),
    custom_classes character varying(200) NOT NULL,
    form_template character varying(200) NOT NULL,
    success_message text
);


ALTER TABLE public.aldryn_forms_formplugin OWNER TO postgres;

--
-- Name: aldryn_forms_formplugin_recipients; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_forms_formplugin_recipients (
    id integer NOT NULL,
    formplugin_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.aldryn_forms_formplugin_recipients OWNER TO postgres;

--
-- Name: aldryn_forms_formplugin_recipients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_forms_formplugin_recipients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_forms_formplugin_recipients_id_seq OWNER TO postgres;

--
-- Name: aldryn_forms_formplugin_recipients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_forms_formplugin_recipients_id_seq OWNED BY aldryn_forms_formplugin_recipients.id;


--
-- Name: aldryn_forms_imageuploadfieldplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_forms_imageuploadfieldplugin (
    cmsplugin_ptr_id integer NOT NULL,
    label character varying(50) NOT NULL,
    required boolean NOT NULL,
    required_message text,
    placeholder_text character varying(50) NOT NULL,
    help_text text,
    min_value integer,
    max_value integer,
    custom_classes character varying(200) NOT NULL,
    upload_to_id integer NOT NULL,
    max_size bigint,
    max_width integer,
    max_height integer,
    CONSTRAINT aldryn_forms_imageuploadfieldplugin_max_height_check CHECK ((max_height >= 0)),
    CONSTRAINT aldryn_forms_imageuploadfieldplugin_max_value_check CHECK ((max_value >= 0)),
    CONSTRAINT aldryn_forms_imageuploadfieldplugin_max_width_check CHECK ((max_width >= 0)),
    CONSTRAINT aldryn_forms_imageuploadfieldplugin_min_value_check CHECK ((min_value >= 0))
);


ALTER TABLE public.aldryn_forms_imageuploadfieldplugin OWNER TO postgres;

--
-- Name: aldryn_forms_option; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_forms_option (
    id integer NOT NULL,
    value character varying(50) NOT NULL,
    field_id integer NOT NULL,
    default_value boolean NOT NULL
);


ALTER TABLE public.aldryn_forms_option OWNER TO postgres;

--
-- Name: aldryn_forms_option_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_forms_option_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_forms_option_id_seq OWNER TO postgres;

--
-- Name: aldryn_forms_option_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_forms_option_id_seq OWNED BY aldryn_forms_option.id;


--
-- Name: aldryn_forms_textareafieldplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_forms_textareafieldplugin (
    cmsplugin_ptr_id integer NOT NULL,
    label character varying(50) NOT NULL,
    required boolean NOT NULL,
    required_message text,
    placeholder_text character varying(50) NOT NULL,
    help_text text,
    min_value integer,
    max_value integer,
    text_area_columns integer,
    text_area_rows integer,
    custom_classes character varying(200) NOT NULL,
    CONSTRAINT cmsplugin_textareafieldplugin_max_value_check CHECK ((max_value >= 0)),
    CONSTRAINT cmsplugin_textareafieldplugin_min_value_check CHECK ((min_value >= 0)),
    CONSTRAINT cmsplugin_textareafieldplugin_text_area_columns_check CHECK ((text_area_columns >= 0)),
    CONSTRAINT cmsplugin_textareafieldplugin_text_area_rows_check CHECK ((text_area_rows >= 0))
);


ALTER TABLE public.aldryn_forms_textareafieldplugin OWNER TO postgres;

--
-- Name: aldryn_style_style; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_style_style (
    cmsplugin_ptr_id integer NOT NULL,
    class_name character varying(50) NOT NULL,
    id_name character varying(50) NOT NULL,
    tag_type character varying(50) NOT NULL,
    padding_left smallint,
    padding_right smallint,
    padding_top smallint,
    padding_bottom smallint,
    margin_left smallint,
    margin_right smallint,
    margin_top smallint,
    margin_bottom smallint,
    additional_class_names text NOT NULL,
    label character varying(128) NOT NULL
);


ALTER TABLE public.aldryn_style_style OWNER TO postgres;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: captcha_captchastore; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE captcha_captchastore (
    id integer NOT NULL,
    challenge character varying(32) NOT NULL,
    response character varying(32) NOT NULL,
    hashkey character varying(40) NOT NULL,
    expiration timestamp with time zone NOT NULL
);


ALTER TABLE public.captcha_captchastore OWNER TO postgres;

--
-- Name: captcha_captchastore_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE captcha_captchastore_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.captcha_captchastore_id_seq OWNER TO postgres;

--
-- Name: captcha_captchastore_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE captcha_captchastore_id_seq OWNED BY captcha_captchastore.id;


--
-- Name: cms_aliaspluginmodel; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_aliaspluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    plugin_id integer,
    alias_placeholder_id integer
);


ALTER TABLE public.cms_aliaspluginmodel OWNER TO postgres;

--
-- Name: cms_cmsplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_cmsplugin (
    id integer NOT NULL,
    placeholder_id integer,
    parent_id integer,
    "position" smallint,
    language character varying(15) NOT NULL,
    plugin_type character varying(50) NOT NULL,
    creation_date timestamp with time zone NOT NULL,
    changed_date timestamp with time zone NOT NULL,
    path character varying(255) NOT NULL,
    depth integer NOT NULL,
    numchild integer NOT NULL,
    CONSTRAINT ck_depth_pstv_1c6f9060a4525f89 CHECK ((depth >= 0)),
    CONSTRAINT ck_numchild_pstv_403c76dbea7c82c9 CHECK ((numchild >= 0)),
    CONSTRAINT cms_cmsplugin_depth_check CHECK ((depth >= 0)),
    CONSTRAINT cms_cmsplugin_numchild_check CHECK ((numchild >= 0)),
    CONSTRAINT cms_cmsplugin_position_check CHECK (("position" >= 0))
);


ALTER TABLE public.cms_cmsplugin OWNER TO postgres;

--
-- Name: cms_cmsplugin_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_cmsplugin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_cmsplugin_id_seq OWNER TO postgres;

--
-- Name: cms_cmsplugin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_cmsplugin_id_seq OWNED BY cms_cmsplugin.id;


--
-- Name: cms_globalpagepermission; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_globalpagepermission (
    id integer NOT NULL,
    user_id integer,
    group_id integer,
    can_change boolean NOT NULL,
    can_add boolean NOT NULL,
    can_delete boolean NOT NULL,
    can_change_advanced_settings boolean NOT NULL,
    can_publish boolean NOT NULL,
    can_change_permissions boolean NOT NULL,
    can_move_page boolean NOT NULL,
    can_view boolean NOT NULL,
    can_recover_page boolean NOT NULL
);


ALTER TABLE public.cms_globalpagepermission OWNER TO postgres;

--
-- Name: cms_globalpagepermission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_globalpagepermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_globalpagepermission_id_seq OWNER TO postgres;

--
-- Name: cms_globalpagepermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_globalpagepermission_id_seq OWNED BY cms_globalpagepermission.id;


--
-- Name: cms_globalpagepermission_sites; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_globalpagepermission_sites (
    id integer NOT NULL,
    globalpagepermission_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.cms_globalpagepermission_sites OWNER TO postgres;

--
-- Name: cms_globalpagepermission_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_globalpagepermission_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_globalpagepermission_sites_id_seq OWNER TO postgres;

--
-- Name: cms_globalpagepermission_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_globalpagepermission_sites_id_seq OWNED BY cms_globalpagepermission_sites.id;


--
-- Name: cms_page; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_page (
    id integer NOT NULL,
    created_by character varying(255) NOT NULL,
    changed_by character varying(255) NOT NULL,
    parent_id integer,
    creation_date timestamp with time zone NOT NULL,
    changed_date timestamp with time zone NOT NULL,
    publication_date timestamp with time zone,
    publication_end_date timestamp with time zone,
    in_navigation boolean NOT NULL,
    soft_root boolean NOT NULL,
    reverse_id character varying(40),
    navigation_extenders character varying(80),
    template character varying(100) NOT NULL,
    site_id integer NOT NULL,
    login_required boolean NOT NULL,
    limit_visibility_in_menu smallint,
    publisher_is_draft boolean NOT NULL,
    publisher_public_id integer,
    revision_id integer NOT NULL,
    application_urls character varying(200),
    application_namespace character varying(200),
    is_home boolean NOT NULL,
    languages character varying(255),
    xframe_options integer NOT NULL,
    path character varying(255) NOT NULL,
    depth integer NOT NULL,
    numchild integer NOT NULL,
    CONSTRAINT ck_depth_pstv_46f345fb120d1fad CHECK ((depth >= 0)),
    CONSTRAINT ck_numchild_pstv_109f9380b32b1465 CHECK ((numchild >= 0)),
    CONSTRAINT ck_revision_id_pstv_217412272bc9414b CHECK ((revision_id >= 0)),
    CONSTRAINT cms_page_depth_check CHECK ((depth >= 0)),
    CONSTRAINT cms_page_numchild_check CHECK ((numchild >= 0)),
    CONSTRAINT cms_page_revision_id_check CHECK ((revision_id >= 0))
);


ALTER TABLE public.cms_page OWNER TO postgres;

--
-- Name: cms_page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_page_id_seq OWNER TO postgres;

--
-- Name: cms_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_page_id_seq OWNED BY cms_page.id;


--
-- Name: cms_page_placeholders; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_page_placeholders (
    id integer NOT NULL,
    page_id integer NOT NULL,
    placeholder_id integer NOT NULL
);


ALTER TABLE public.cms_page_placeholders OWNER TO postgres;

--
-- Name: cms_page_placeholders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_page_placeholders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_page_placeholders_id_seq OWNER TO postgres;

--
-- Name: cms_page_placeholders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_page_placeholders_id_seq OWNED BY cms_page_placeholders.id;


--
-- Name: cms_pagepermission; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_pagepermission (
    id integer NOT NULL,
    user_id integer,
    group_id integer,
    can_change boolean NOT NULL,
    can_add boolean NOT NULL,
    can_delete boolean NOT NULL,
    can_change_advanced_settings boolean NOT NULL,
    can_publish boolean NOT NULL,
    can_change_permissions boolean NOT NULL,
    can_move_page boolean NOT NULL,
    can_view boolean NOT NULL,
    grant_on integer NOT NULL,
    page_id integer
);


ALTER TABLE public.cms_pagepermission OWNER TO postgres;

--
-- Name: cms_pagepermission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_pagepermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_pagepermission_id_seq OWNER TO postgres;

--
-- Name: cms_pagepermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_pagepermission_id_seq OWNED BY cms_pagepermission.id;


--
-- Name: cms_pageuser; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_pageuser (
    user_ptr_id integer NOT NULL,
    created_by_id integer NOT NULL
);


ALTER TABLE public.cms_pageuser OWNER TO postgres;

--
-- Name: cms_pageusergroup; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_pageusergroup (
    group_ptr_id integer NOT NULL,
    created_by_id integer NOT NULL
);


ALTER TABLE public.cms_pageusergroup OWNER TO postgres;

--
-- Name: cms_placeholder; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_placeholder (
    id integer NOT NULL,
    slot character varying(255) NOT NULL,
    default_width smallint,
    CONSTRAINT cms_placeholder_default_width_check CHECK ((default_width >= 0))
);


ALTER TABLE public.cms_placeholder OWNER TO postgres;

--
-- Name: cms_placeholder_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_placeholder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_placeholder_id_seq OWNER TO postgres;

--
-- Name: cms_placeholder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_placeholder_id_seq OWNED BY cms_placeholder.id;


--
-- Name: cms_placeholderreference; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_placeholderreference (
    cmsplugin_ptr_id integer NOT NULL,
    name character varying(255) NOT NULL,
    placeholder_ref_id integer
);


ALTER TABLE public.cms_placeholderreference OWNER TO postgres;

--
-- Name: cms_staticplaceholder; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_staticplaceholder (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    draft_id integer,
    public_id integer,
    dirty boolean NOT NULL,
    creation_method character varying(20) NOT NULL,
    site_id integer
);


ALTER TABLE public.cms_staticplaceholder OWNER TO postgres;

--
-- Name: cms_staticplaceholder_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_staticplaceholder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_staticplaceholder_id_seq OWNER TO postgres;

--
-- Name: cms_staticplaceholder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_staticplaceholder_id_seq OWNED BY cms_staticplaceholder.id;


--
-- Name: cms_title; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_title (
    id integer NOT NULL,
    language character varying(15) NOT NULL,
    title character varying(255) NOT NULL,
    menu_title character varying(255),
    slug character varying(255) NOT NULL,
    path character varying(255) NOT NULL,
    has_url_overwrite boolean NOT NULL,
    redirect character varying(2048),
    meta_description text,
    page_title character varying(255),
    page_id integer NOT NULL,
    creation_date timestamp with time zone NOT NULL,
    published boolean NOT NULL,
    publisher_is_draft boolean NOT NULL,
    publisher_public_id integer,
    publisher_state smallint NOT NULL
);


ALTER TABLE public.cms_title OWNER TO postgres;

--
-- Name: cms_title_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_title_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_title_id_seq OWNER TO postgres;

--
-- Name: cms_title_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_title_id_seq OWNED BY cms_title.id;


--
-- Name: cms_usersettings; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_usersettings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    language character varying(10) NOT NULL,
    clipboard_id integer
);


ALTER TABLE public.cms_usersettings OWNER TO postgres;

--
-- Name: cms_usersettings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_usersettings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_usersettings_id_seq OWNER TO postgres;

--
-- Name: cms_usersettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_usersettings_id_seq OWNED BY cms_usersettings.id;


--
-- Name: cmscloud_aldrynclouduser; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cmscloud_aldrynclouduser (
    id integer NOT NULL,
    cloud_id integer NOT NULL,
    user_id integer NOT NULL,
    CONSTRAINT cmscloud_aldrynclouduser_cloud_id_check CHECK ((cloud_id >= 0))
);


ALTER TABLE public.cmscloud_aldrynclouduser OWNER TO postgres;

--
-- Name: cmscloud_aldrynclouduser_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cmscloud_aldrynclouduser_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cmscloud_aldrynclouduser_id_seq OWNER TO postgres;

--
-- Name: cmscloud_aldrynclouduser_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cmscloud_aldrynclouduser_id_seq OWNED BY cmscloud_aldrynclouduser.id;


--
-- Name: cmsplugin_filer_file_filerfile; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cmsplugin_filer_file_filerfile (
    cmsplugin_ptr_id integer NOT NULL,
    file_id integer NOT NULL,
    title character varying(255),
    target_blank boolean NOT NULL,
    style character varying(255) NOT NULL
);


ALTER TABLE public.cmsplugin_filer_file_filerfile OWNER TO postgres;

--
-- Name: cmsplugin_filer_image_filerimage; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cmsplugin_filer_image_filerimage (
    cmsplugin_ptr_id integer NOT NULL,
    image_id integer,
    alt_text character varying(255),
    caption_text character varying(255),
    use_autoscale boolean NOT NULL,
    width integer,
    height integer,
    alignment character varying(10),
    free_link character varying(255),
    page_link_id integer,
    description text,
    image_url character varying(200),
    thumbnail_option_id integer,
    crop boolean NOT NULL,
    upscale boolean NOT NULL,
    original_link boolean NOT NULL,
    file_link_id integer,
    use_original_image boolean NOT NULL,
    target_blank boolean NOT NULL,
    style character varying(50) NOT NULL,
    CONSTRAINT cmsplugin_filerimage_height_check CHECK ((height >= 0)),
    CONSTRAINT cmsplugin_filerimage_width_check CHECK ((width >= 0))
);


ALTER TABLE public.cmsplugin_filer_image_filerimage OWNER TO postgres;

--
-- Name: cmsplugin_filer_image_thumbnailoption; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cmsplugin_filer_image_thumbnailoption (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    crop boolean NOT NULL,
    upscale boolean NOT NULL
);


ALTER TABLE public.cmsplugin_filer_image_thumbnailoption OWNER TO postgres;

--
-- Name: cmsplugin_filer_image_thumbnailoption_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cmsplugin_filer_image_thumbnailoption_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cmsplugin_filer_image_thumbnailoption_id_seq OWNER TO postgres;

--
-- Name: cmsplugin_filer_image_thumbnailoption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cmsplugin_filer_image_thumbnailoption_id_seq OWNED BY cmsplugin_filer_image_thumbnailoption.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    content_type_id integer,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_dbcache; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_dbcache (
    cache_key character varying(255) NOT NULL,
    value text NOT NULL,
    expires timestamp with time zone NOT NULL
);


ALTER TABLE public.django_dbcache OWNER TO postgres;

--
-- Name: django_select2_keymap; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_select2_keymap (
    id integer NOT NULL,
    key character varying(40) NOT NULL,
    value character varying(100) NOT NULL,
    accessed_on timestamp with time zone NOT NULL
);


ALTER TABLE public.django_select2_keymap OWNER TO postgres;

--
-- Name: django_select2_keymap_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_select2_keymap_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_select2_keymap_id_seq OWNER TO postgres;

--
-- Name: django_select2_keymap_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_select2_keymap_id_seq OWNED BY django_select2_keymap.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: djangocms_googlemap_googlemap; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE djangocms_googlemap_googlemap (
    cmsplugin_ptr_id integer NOT NULL,
    title character varying(100),
    address character varying(150) NOT NULL,
    zipcode character varying(30) NOT NULL,
    city character varying(100) NOT NULL,
    content character varying(255) NOT NULL,
    zoom smallint NOT NULL,
    lat numeric(10,6),
    lng numeric(10,6),
    route_planer_title character varying(150),
    route_planer boolean NOT NULL,
    width character varying(6) NOT NULL,
    height character varying(6) NOT NULL,
    info_window boolean NOT NULL,
    scrollwheel boolean NOT NULL,
    double_click_zoom boolean NOT NULL,
    draggable boolean NOT NULL,
    keyboard_shortcuts boolean NOT NULL,
    pan_control boolean NOT NULL,
    zoom_control boolean NOT NULL,
    street_view_control boolean NOT NULL,
    CONSTRAINT djangocms_googlemap_googlemap_zoom_check CHECK ((zoom >= 0))
);


ALTER TABLE public.djangocms_googlemap_googlemap OWNER TO postgres;

--
-- Name: djangocms_link_link; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE djangocms_link_link (
    cmsplugin_ptr_id integer NOT NULL,
    name character varying(256) NOT NULL,
    url character varying(200),
    page_link_id integer,
    mailto character varying(75),
    target character varying(100) NOT NULL,
    phone character varying(40),
    anchor character varying(128) NOT NULL
);


ALTER TABLE public.djangocms_link_link OWNER TO postgres;

--
-- Name: djangocms_snippet_snippet; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE djangocms_snippet_snippet (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    html text NOT NULL,
    template character varying(50) NOT NULL
);


ALTER TABLE public.djangocms_snippet_snippet OWNER TO postgres;

--
-- Name: djangocms_snippet_snippet_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE djangocms_snippet_snippet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.djangocms_snippet_snippet_id_seq OWNER TO postgres;

--
-- Name: djangocms_snippet_snippet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE djangocms_snippet_snippet_id_seq OWNED BY djangocms_snippet_snippet.id;


--
-- Name: djangocms_snippet_snippetptr; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE djangocms_snippet_snippetptr (
    cmsplugin_ptr_id integer NOT NULL,
    snippet_id integer NOT NULL
);


ALTER TABLE public.djangocms_snippet_snippetptr OWNER TO postgres;

--
-- Name: djangocms_text_ckeditor_text; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE djangocms_text_ckeditor_text (
    cmsplugin_ptr_id integer NOT NULL,
    body text NOT NULL
);


ALTER TABLE public.djangocms_text_ckeditor_text OWNER TO postgres;

--
-- Name: easy_thumbnails_source; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE easy_thumbnails_source (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL,
    storage_hash character varying(40) NOT NULL
);


ALTER TABLE public.easy_thumbnails_source OWNER TO postgres;

--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE easy_thumbnails_source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_source_id_seq OWNER TO postgres;

--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE easy_thumbnails_source_id_seq OWNED BY easy_thumbnails_source.id;


--
-- Name: easy_thumbnails_thumbnail; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE easy_thumbnails_thumbnail (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL,
    source_id integer NOT NULL,
    storage_hash character varying(40) NOT NULL
);


ALTER TABLE public.easy_thumbnails_thumbnail OWNER TO postgres;

--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE easy_thumbnails_thumbnail_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_thumbnail_id_seq OWNER TO postgres;

--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE easy_thumbnails_thumbnail_id_seq OWNED BY easy_thumbnails_thumbnail.id;


--
-- Name: easy_thumbnails_thumbnaildimensions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE easy_thumbnails_thumbnaildimensions (
    id integer NOT NULL,
    thumbnail_id integer NOT NULL,
    width integer,
    height integer,
    CONSTRAINT easy_thumbnails_thumbnaildimensions_height_check CHECK ((height >= 0)),
    CONSTRAINT easy_thumbnails_thumbnaildimensions_width_check CHECK ((width >= 0))
);


ALTER TABLE public.easy_thumbnails_thumbnaildimensions OWNER TO postgres;

--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE easy_thumbnails_thumbnaildimensions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_thumbnaildimensions_id_seq OWNER TO postgres;

--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE easy_thumbnails_thumbnaildimensions_id_seq OWNED BY easy_thumbnails_thumbnaildimensions.id;


--
-- Name: filer_clipboard; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE filer_clipboard (
    id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.filer_clipboard OWNER TO postgres;

--
-- Name: filer_clipboard_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE filer_clipboard_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.filer_clipboard_id_seq OWNER TO postgres;

--
-- Name: filer_clipboard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE filer_clipboard_id_seq OWNED BY filer_clipboard.id;


--
-- Name: filer_clipboarditem; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE filer_clipboarditem (
    id integer NOT NULL,
    file_id integer NOT NULL,
    clipboard_id integer NOT NULL
);


ALTER TABLE public.filer_clipboarditem OWNER TO postgres;

--
-- Name: filer_clipboarditem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE filer_clipboarditem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.filer_clipboarditem_id_seq OWNER TO postgres;

--
-- Name: filer_clipboarditem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE filer_clipboarditem_id_seq OWNED BY filer_clipboarditem.id;


--
-- Name: filer_file; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE filer_file (
    id integer NOT NULL,
    folder_id integer,
    file character varying(255),
    _file_size integer,
    has_all_mandatory_data boolean NOT NULL,
    original_filename character varying(255),
    name character varying(255) NOT NULL,
    owner_id integer,
    uploaded_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    description text,
    is_public boolean NOT NULL,
    sha1 character varying(40) NOT NULL,
    polymorphic_ctype_id integer
);


ALTER TABLE public.filer_file OWNER TO postgres;

--
-- Name: filer_file_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE filer_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.filer_file_id_seq OWNER TO postgres;

--
-- Name: filer_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE filer_file_id_seq OWNED BY filer_file.id;


--
-- Name: filer_folder; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE filer_folder (
    id integer NOT NULL,
    parent_id integer,
    name character varying(255) NOT NULL,
    owner_id integer,
    uploaded_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    CONSTRAINT filer_folder_level_check CHECK ((level >= 0)),
    CONSTRAINT filer_folder_lft_check CHECK ((lft >= 0)),
    CONSTRAINT filer_folder_rght_check CHECK ((rght >= 0)),
    CONSTRAINT filer_folder_tree_id_check CHECK ((tree_id >= 0))
);


ALTER TABLE public.filer_folder OWNER TO postgres;

--
-- Name: filer_folder_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE filer_folder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.filer_folder_id_seq OWNER TO postgres;

--
-- Name: filer_folder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE filer_folder_id_seq OWNED BY filer_folder.id;


--
-- Name: filer_folderpermission; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE filer_folderpermission (
    id integer NOT NULL,
    folder_id integer,
    type smallint NOT NULL,
    user_id integer,
    group_id integer,
    everybody boolean NOT NULL,
    can_edit smallint,
    can_read smallint,
    can_add_children smallint
);


ALTER TABLE public.filer_folderpermission OWNER TO postgres;

--
-- Name: filer_folderpermission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE filer_folderpermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.filer_folderpermission_id_seq OWNER TO postgres;

--
-- Name: filer_folderpermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE filer_folderpermission_id_seq OWNED BY filer_folderpermission.id;


--
-- Name: filer_image; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE filer_image (
    file_ptr_id integer NOT NULL,
    _height integer,
    _width integer,
    date_taken timestamp with time zone,
    default_alt_text character varying(255),
    default_caption character varying(255),
    author character varying(255),
    must_always_publish_author_credit boolean NOT NULL,
    must_always_publish_copyright boolean NOT NULL,
    subject_location character varying(64)
);


ALTER TABLE public.filer_image OWNER TO postgres;

--
-- Name: health_check_db_testmodel; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE health_check_db_testmodel (
    id integer NOT NULL,
    title character varying(128) NOT NULL
);


ALTER TABLE public.health_check_db_testmodel OWNER TO postgres;

--
-- Name: health_check_db_testmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE health_check_db_testmodel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.health_check_db_testmodel_id_seq OWNER TO postgres;

--
-- Name: health_check_db_testmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE health_check_db_testmodel_id_seq OWNED BY health_check_db_testmodel.id;


--
-- Name: menus_cachekey; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE menus_cachekey (
    id integer NOT NULL,
    language character varying(255) NOT NULL,
    site integer NOT NULL,
    key character varying(255) NOT NULL,
    CONSTRAINT menus_cachekey_site_check CHECK ((site >= 0))
);


ALTER TABLE public.menus_cachekey OWNER TO postgres;

--
-- Name: menus_cachekey_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE menus_cachekey_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menus_cachekey_id_seq OWNER TO postgres;

--
-- Name: menus_cachekey_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE menus_cachekey_id_seq OWNED BY menus_cachekey.id;


--
-- Name: reversion_revision; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE reversion_revision (
    id integer NOT NULL,
    date_created timestamp with time zone NOT NULL,
    user_id integer,
    comment text NOT NULL,
    manager_slug character varying(200) NOT NULL
);


ALTER TABLE public.reversion_revision OWNER TO postgres;

--
-- Name: reversion_revision_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE reversion_revision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reversion_revision_id_seq OWNER TO postgres;

--
-- Name: reversion_revision_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE reversion_revision_id_seq OWNED BY reversion_revision.id;


--
-- Name: reversion_version; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE reversion_version (
    id integer NOT NULL,
    revision_id integer NOT NULL,
    object_id text NOT NULL,
    content_type_id integer NOT NULL,
    format character varying(255) NOT NULL,
    serialized_data text NOT NULL,
    object_repr text NOT NULL,
    object_id_int integer
);


ALTER TABLE public.reversion_version OWNER TO postgres;

--
-- Name: reversion_version_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE reversion_version_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reversion_version_id_seq OWNER TO postgres;

--
-- Name: reversion_version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE reversion_version_id_seq OWNED BY reversion_version.id;


--
-- Name: robots_rule; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE robots_rule (
    id integer NOT NULL,
    robot character varying(255) NOT NULL,
    crawl_delay numeric(3,1)
);


ALTER TABLE public.robots_rule OWNER TO postgres;

--
-- Name: robots_rule_allowed; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE robots_rule_allowed (
    id integer NOT NULL,
    rule_id integer NOT NULL,
    url_id integer NOT NULL
);


ALTER TABLE public.robots_rule_allowed OWNER TO postgres;

--
-- Name: robots_rule_allowed_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE robots_rule_allowed_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.robots_rule_allowed_id_seq OWNER TO postgres;

--
-- Name: robots_rule_allowed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE robots_rule_allowed_id_seq OWNED BY robots_rule_allowed.id;


--
-- Name: robots_rule_disallowed; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE robots_rule_disallowed (
    id integer NOT NULL,
    rule_id integer NOT NULL,
    url_id integer NOT NULL
);


ALTER TABLE public.robots_rule_disallowed OWNER TO postgres;

--
-- Name: robots_rule_disallowed_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE robots_rule_disallowed_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.robots_rule_disallowed_id_seq OWNER TO postgres;

--
-- Name: robots_rule_disallowed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE robots_rule_disallowed_id_seq OWNED BY robots_rule_disallowed.id;


--
-- Name: robots_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE robots_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.robots_rule_id_seq OWNER TO postgres;

--
-- Name: robots_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE robots_rule_id_seq OWNED BY robots_rule.id;


--
-- Name: robots_rule_sites; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE robots_rule_sites (
    id integer NOT NULL,
    rule_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.robots_rule_sites OWNER TO postgres;

--
-- Name: robots_rule_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE robots_rule_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.robots_rule_sites_id_seq OWNER TO postgres;

--
-- Name: robots_rule_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE robots_rule_sites_id_seq OWNED BY robots_rule_sites.id;


--
-- Name: robots_url; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE robots_url (
    id integer NOT NULL,
    pattern character varying(255) NOT NULL
);


ALTER TABLE public.robots_url OWNER TO postgres;

--
-- Name: robots_url_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE robots_url_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.robots_url_id_seq OWNER TO postgres;

--
-- Name: robots_url_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE robots_url_id_seq OWNED BY robots_url.id;


--
-- Name: south_migrationhistory; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE south_migrationhistory (
    id integer NOT NULL,
    app_name character varying(255) NOT NULL,
    migration character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.south_migrationhistory OWNER TO postgres;

--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE south_migrationhistory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.south_migrationhistory_id_seq OWNER TO postgres;

--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE south_migrationhistory_id_seq OWNED BY south_migrationhistory.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_formdata ALTER COLUMN id SET DEFAULT nextval('aldryn_forms_formdata_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_formdata_people_notified ALTER COLUMN id SET DEFAULT nextval('aldryn_forms_formdata_people_notified_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_formplugin_recipients ALTER COLUMN id SET DEFAULT nextval('aldryn_forms_formplugin_recipients_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_option ALTER COLUMN id SET DEFAULT nextval('aldryn_forms_option_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY captcha_captchastore ALTER COLUMN id SET DEFAULT nextval('captcha_captchastore_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_cmsplugin ALTER COLUMN id SET DEFAULT nextval('cms_cmsplugin_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_globalpagepermission ALTER COLUMN id SET DEFAULT nextval('cms_globalpagepermission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_globalpagepermission_sites ALTER COLUMN id SET DEFAULT nextval('cms_globalpagepermission_sites_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_page ALTER COLUMN id SET DEFAULT nextval('cms_page_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_page_placeholders ALTER COLUMN id SET DEFAULT nextval('cms_page_placeholders_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pagepermission ALTER COLUMN id SET DEFAULT nextval('cms_pagepermission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_placeholder ALTER COLUMN id SET DEFAULT nextval('cms_placeholder_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_staticplaceholder ALTER COLUMN id SET DEFAULT nextval('cms_staticplaceholder_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_title ALTER COLUMN id SET DEFAULT nextval('cms_title_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_usersettings ALTER COLUMN id SET DEFAULT nextval('cms_usersettings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cmscloud_aldrynclouduser ALTER COLUMN id SET DEFAULT nextval('cmscloud_aldrynclouduser_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cmsplugin_filer_image_thumbnailoption ALTER COLUMN id SET DEFAULT nextval('cmsplugin_filer_image_thumbnailoption_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_select2_keymap ALTER COLUMN id SET DEFAULT nextval('django_select2_keymap_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY djangocms_snippet_snippet ALTER COLUMN id SET DEFAULT nextval('djangocms_snippet_snippet_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY easy_thumbnails_source ALTER COLUMN id SET DEFAULT nextval('easy_thumbnails_source_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY easy_thumbnails_thumbnail ALTER COLUMN id SET DEFAULT nextval('easy_thumbnails_thumbnail_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY easy_thumbnails_thumbnaildimensions ALTER COLUMN id SET DEFAULT nextval('easy_thumbnails_thumbnaildimensions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_clipboard ALTER COLUMN id SET DEFAULT nextval('filer_clipboard_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_clipboarditem ALTER COLUMN id SET DEFAULT nextval('filer_clipboarditem_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_file ALTER COLUMN id SET DEFAULT nextval('filer_file_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_folder ALTER COLUMN id SET DEFAULT nextval('filer_folder_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_folderpermission ALTER COLUMN id SET DEFAULT nextval('filer_folderpermission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY health_check_db_testmodel ALTER COLUMN id SET DEFAULT nextval('health_check_db_testmodel_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY menus_cachekey ALTER COLUMN id SET DEFAULT nextval('menus_cachekey_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reversion_revision ALTER COLUMN id SET DEFAULT nextval('reversion_revision_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reversion_version ALTER COLUMN id SET DEFAULT nextval('reversion_version_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY robots_rule ALTER COLUMN id SET DEFAULT nextval('robots_rule_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY robots_rule_allowed ALTER COLUMN id SET DEFAULT nextval('robots_rule_allowed_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY robots_rule_disallowed ALTER COLUMN id SET DEFAULT nextval('robots_rule_disallowed_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY robots_rule_sites ALTER COLUMN id SET DEFAULT nextval('robots_rule_sites_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY robots_url ALTER COLUMN id SET DEFAULT nextval('robots_url_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY south_migrationhistory ALTER COLUMN id SET DEFAULT nextval('south_migrationhistory_id_seq'::regclass);


--
-- Data for Name: aldryn_bootstrap3_boostrap3alertplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3alertplugin (cmsplugin_ptr_id, context, classes, icon) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3blockquoteplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3blockquoteplugin (cmsplugin_ptr_id, reverse, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3buttonplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3buttonplugin (cmsplugin_ptr_id, btn_context, label, link_url, btn_size, classes, icon_left, icon_right, link_page_id, link_anchor, link_mailto, link_phone, link_target, link_file_id, type, txt_context, btn_block, responsive, responsive_print) FROM stdin;
11	default	Link/Button - Creative Commons Attribution 4.0 International License	http://creativecommons.org/licenses/by/4.0/	md				\N					\N	lnk		f		
67	default	Link/Button - Creative Commons Attribution 4.0 International License	http://creativecommons.org/licenses/by/4.0/	md				\N					\N	lnk		f		
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3iconplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3iconplugin (cmsplugin_ptr_id, icon, classes) FROM stdin;
26	fa-crosshairs	
28	fa-thumb-tack	
30	fa-calendar	
32	fa-rocket	
121	fa-crosshairs	
124	fa-thumb-tack	
127	fa-calendar	
130	fa-rocket	
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3imageplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3imageplugin (cmsplugin_ptr_id, file_id, alt, title, aspect_ratio, thumbnail, shape, classes, img_responsive) FROM stdin;
2	1				f			t
47	3				f			t
50	2				f			t
69	4				f			t
41	5				f			t
92	5				f			t
95	3				f			t
98	2				f			t
101	4				f			t
104	1				f			t
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3labelplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3labelplugin (cmsplugin_ptr_id, label, context, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3panelbodyplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3panelbodyplugin (cmsplugin_ptr_id, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3panelfooterplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3panelfooterplugin (cmsplugin_ptr_id, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3panelheadingplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3panelheadingplugin (cmsplugin_ptr_id, title, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3panelplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3panelplugin (cmsplugin_ptr_id, context, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3spacerplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3spacerplugin (cmsplugin_ptr_id, size, classes) FROM stdin;
6	lg	
13	lg	
14	xs	
17	xs	
19	md	
33	md	
37	lg	
87	lg	
109	lg	
112	lg	
113	xs	
117	md	
131	xs	
132	md	
141	md	
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3wellplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3wellplugin (cmsplugin_ptr_id, size, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3accordionitemplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3accordionitemplugin (cmsplugin_ptr_id, title, context, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3accordionplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3accordionplugin (cmsplugin_ptr_id, classes, index) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3carouselplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3carouselplugin (cmsplugin_ptr_id, style, transition_effect, ride, "interval", wrap, pause, classes, aspect_ratio) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3carouselslidefolderplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3carouselslidefolderplugin (cmsplugin_ptr_id, folder_id, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3carouselslideplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3carouselslideplugin (cmsplugin_ptr_id, link_url, link_page_id, link_file_id, link_anchor, link_mailto, link_phone, link_target, image_id, link_text, content, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3columnplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3columnplugin (cmsplugin_ptr_id, classes, xs_col, xs_offset, sm_col, sm_offset, md_col, md_offset, lg_col, lg_offset, xs_push, xs_pull, sm_push, sm_pull, md_push, md_pull, lg_push, lg_pull, tag) FROM stdin;
5		\N	\N	\N	\N	24	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	div
21		\N	\N	12	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	div
22		\N	\N	12	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	div
23		\N	\N	12	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	div
24		\N	\N	12	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	div
108		\N	\N	\N	\N	24	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	div
119		\N	\N	12	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	div
122		\N	\N	12	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	div
125		\N	\N	12	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	div
128		\N	\N	12	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	div
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3listgroupitemplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3listgroupitemplugin (cmsplugin_ptr_id, title, context, classes, state) FROM stdin;
40				
46				
49				
68				
91				
94				
97				
100				
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3listgroupplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3listgroupplugin (cmsplugin_ptr_id, classes, add_list_group_class) FROM stdin;
39	list-timeline	f
90	list-timeline	f
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3rowplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3rowplugin (cmsplugin_ptr_id, classes) FROM stdin;
4	
20	
107	
118	
\.


--
-- Data for Name: aldryn_forms_emailfieldplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_forms_emailfieldplugin (cmsplugin_ptr_id, label, required, required_message, placeholder_text, help_text, min_value, max_value, custom_classes, email_send_notification, email_subject, email_body) FROM stdin;
\.


--
-- Data for Name: aldryn_forms_fieldplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_forms_fieldplugin (cmsplugin_ptr_id, label, required, placeholder_text, help_text, min_value, max_value, required_message, custom_classes) FROM stdin;
\.


--
-- Data for Name: aldryn_forms_fieldsetplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_forms_fieldsetplugin (cmsplugin_ptr_id, legend, custom_classes) FROM stdin;
\.


--
-- Data for Name: aldryn_forms_fileuploadfieldplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_forms_fileuploadfieldplugin (cmsplugin_ptr_id, label, required, required_message, placeholder_text, help_text, min_value, max_value, custom_classes, upload_to_id, max_size) FROM stdin;
\.


--
-- Data for Name: aldryn_forms_formbuttonplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_forms_formbuttonplugin (cmsplugin_ptr_id, label, custom_classes) FROM stdin;
\.


--
-- Data for Name: aldryn_forms_formdata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_forms_formdata (id, name, data, sent_at, language) FROM stdin;
\.


--
-- Name: aldryn_forms_formdata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_forms_formdata_id_seq', 1, false);


--
-- Data for Name: aldryn_forms_formdata_people_notified; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_forms_formdata_people_notified (id, formdata_id, user_id) FROM stdin;
\.


--
-- Name: aldryn_forms_formdata_people_notified_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_forms_formdata_people_notified_id_seq', 1, false);


--
-- Data for Name: aldryn_forms_formplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_forms_formplugin (cmsplugin_ptr_id, name, error_message, redirect_type, page_id, url, custom_classes, form_template, success_message) FROM stdin;
\.


--
-- Data for Name: aldryn_forms_formplugin_recipients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_forms_formplugin_recipients (id, formplugin_id, user_id) FROM stdin;
\.


--
-- Name: aldryn_forms_formplugin_recipients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_forms_formplugin_recipients_id_seq', 1, false);


--
-- Data for Name: aldryn_forms_imageuploadfieldplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_forms_imageuploadfieldplugin (cmsplugin_ptr_id, label, required, required_message, placeholder_text, help_text, min_value, max_value, custom_classes, upload_to_id, max_size, max_width, max_height) FROM stdin;
\.


--
-- Data for Name: aldryn_forms_option; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_forms_option (id, value, field_id, default_value) FROM stdin;
\.


--
-- Name: aldryn_forms_option_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_forms_option_id_seq', 1, false);


--
-- Data for Name: aldryn_forms_textareafieldplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_forms_textareafieldplugin (cmsplugin_ptr_id, label, required, required_message, placeholder_text, help_text, min_value, max_value, text_area_columns, text_area_rows, custom_classes) FROM stdin;
\.


--
-- Data for Name: aldryn_style_style; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_style_style (cmsplugin_ptr_id, class_name, id_name, tag_type, padding_left, padding_right, padding_top, padding_bottom, margin_left, margin_right, margin_top, margin_bottom, additional_class_names, label) FROM stdin;
3	feature-content		div	\N	\N	\N	\N	\N	\N	\N	\N		Content
1	feature-visual		div	\N	\N	\N	\N	\N	\N	\N	\N		Visual
8	container		div	\N	\N	\N	\N	\N	\N	\N	\N		Grid
12	text-center		div	\N	\N	\N	\N	\N	\N	\N	\N		Content
34	section-cyan		div	\N	\N	\N	\N	\N	\N	\N	\N	text-center	Section
38	text-center		div	\N	\N	\N	\N	\N	\N	\N	\N		
88	text-center		div	\N	\N	\N	\N	\N	\N	\N	\N		
103	feature-visual		div	\N	\N	\N	\N	\N	\N	\N	\N		Visual
105	feature-content		div	\N	\N	\N	\N	\N	\N	\N	\N		Content
106	container		div	\N	\N	\N	\N	\N	\N	\N	\N		Grid
111	text-center		div	\N	\N	\N	\N	\N	\N	\N	\N		Content
133	section-cyan		div	\N	\N	\N	\N	\N	\N	\N	\N	text-center	Section
139	text-center		div	\N	\N	\N	\N	\N	\N	\N	\N		Content
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can add group	2	add_group
5	Can change group	2	change_group
6	Can delete group	2	delete_group
7	Can add user	3	add_user
8	Can change user	3	change_user
9	Can delete user	3	delete_user
10	Can add content type	4	add_contenttype
11	Can change content type	4	change_contenttype
12	Can delete content type	4	delete_contenttype
13	Can add session	5	add_session
14	Can change session	5	change_session
15	Can delete session	5	delete_session
16	Can add site	6	add_site
17	Can change site	6	change_site
18	Can delete site	6	delete_site
19	Can add log entry	7	add_logentry
20	Can change log entry	7	change_logentry
21	Can delete log entry	7	delete_logentry
22	Can add migration history	8	add_migrationhistory
23	Can change migration history	8	change_migrationhistory
24	Can delete migration history	8	delete_migrationhistory
25	Can add key map	9	add_keymap
26	Can change key map	9	change_keymap
27	Can delete key map	9	delete_keymap
28	Can add test model	10	add_testmodel
29	Can change test model	10	change_testmodel
30	Can delete test model	10	delete_testmodel
31	Can publish Page	11	publish_page
32	Can edit static placeholders	11	edit_static_placeholder
33	Can add user setting	12	add_usersettings
34	Can change user setting	12	change_usersettings
35	Can delete user setting	12	delete_usersettings
36	Can add placeholder	13	add_placeholder
37	Can change placeholder	13	change_placeholder
38	Can delete placeholder	13	delete_placeholder
39	Can add cms plugin	14	add_cmsplugin
40	Can change cms plugin	14	change_cmsplugin
41	Can delete cms plugin	14	delete_cmsplugin
42	Can add page	11	add_page
43	Can change page	11	change_page
44	Can delete page	11	delete_page
45	Can view page	11	view_page
46	Can add Page global permission	15	add_globalpagepermission
47	Can change Page global permission	15	change_globalpagepermission
48	Can delete Page global permission	15	delete_globalpagepermission
49	Can add Page permission	16	add_pagepermission
50	Can change Page permission	16	change_pagepermission
51	Can delete Page permission	16	delete_pagepermission
52	Can add User (page)	17	add_pageuser
53	Can change User (page)	17	change_pageuser
54	Can delete User (page)	17	delete_pageuser
55	Can add User group (page)	18	add_pageusergroup
56	Can change User group (page)	18	change_pageusergroup
57	Can delete User group (page)	18	delete_pageusergroup
58	Can add title	19	add_title
59	Can change title	19	change_title
60	Can delete title	19	delete_title
61	Can add placeholder reference	20	add_placeholderreference
62	Can change placeholder reference	20	change_placeholderreference
63	Can delete placeholder reference	20	delete_placeholderreference
64	Can add static placeholder	21	add_staticplaceholder
65	Can change static placeholder	21	change_staticplaceholder
66	Can delete static placeholder	21	delete_staticplaceholder
67	Can add alias plugin model	22	add_aliaspluginmodel
68	Can change alias plugin model	22	change_aliaspluginmodel
69	Can delete alias plugin model	22	delete_aliaspluginmodel
70	Can add cache key	23	add_cachekey
71	Can change cache key	23	change_cachekey
72	Can delete cache key	23	delete_cachekey
73	Can add aldryn cloud user	24	add_aldrynclouduser
74	Can change aldryn cloud user	24	change_aldrynclouduser
75	Can delete aldryn cloud user	24	delete_aldrynclouduser
76	Can add style	25	add_style
77	Can change style	25	change_style
78	Can delete style	25	delete_style
79	Can add captcha store	26	add_captchastore
80	Can change captcha store	26	change_captchastore
81	Can delete captcha store	26	delete_captchastore
82	Can add Folder	27	add_folder
83	Can change Folder	27	change_folder
84	Can delete Folder	27	delete_folder
85	Can use directory listing	27	can_use_directory_listing
86	Can add folder permission	28	add_folderpermission
87	Can change folder permission	28	change_folderpermission
88	Can delete folder permission	28	delete_folderpermission
89	Can add file	29	add_file
90	Can change file	29	change_file
91	Can delete file	29	delete_file
92	Can add clipboard	30	add_clipboard
93	Can change clipboard	30	change_clipboard
94	Can delete clipboard	30	delete_clipboard
95	Can add clipboard item	31	add_clipboarditem
96	Can change clipboard item	31	change_clipboarditem
97	Can delete clipboard item	31	delete_clipboarditem
98	Can add image	32	add_image
99	Can change image	32	change_image
100	Can delete image	32	delete_image
101	Can add boostrap3 button plugin	33	add_boostrap3buttonplugin
102	Can change boostrap3 button plugin	33	change_boostrap3buttonplugin
103	Can delete boostrap3 button plugin	33	delete_boostrap3buttonplugin
104	Can add boostrap3 blockquote plugin	34	add_boostrap3blockquoteplugin
105	Can change boostrap3 blockquote plugin	34	change_boostrap3blockquoteplugin
106	Can delete boostrap3 blockquote plugin	34	delete_boostrap3blockquoteplugin
107	Can add boostrap3 icon plugin	35	add_boostrap3iconplugin
108	Can change boostrap3 icon plugin	35	change_boostrap3iconplugin
109	Can delete boostrap3 icon plugin	35	delete_boostrap3iconplugin
110	Can add boostrap3 label plugin	36	add_boostrap3labelplugin
111	Can change boostrap3 label plugin	36	change_boostrap3labelplugin
112	Can delete boostrap3 label plugin	36	delete_boostrap3labelplugin
113	Can add boostrap3 well plugin	37	add_boostrap3wellplugin
114	Can change boostrap3 well plugin	37	change_boostrap3wellplugin
115	Can delete boostrap3 well plugin	37	delete_boostrap3wellplugin
116	Can add boostrap3 alert plugin	38	add_boostrap3alertplugin
117	Can change boostrap3 alert plugin	38	change_boostrap3alertplugin
118	Can delete boostrap3 alert plugin	38	delete_boostrap3alertplugin
119	Can add boostrap3 image plugin	39	add_boostrap3imageplugin
120	Can change boostrap3 image plugin	39	change_boostrap3imageplugin
121	Can delete boostrap3 image plugin	39	delete_boostrap3imageplugin
122	Can add boostrap3 panel plugin	40	add_boostrap3panelplugin
123	Can change boostrap3 panel plugin	40	change_boostrap3panelplugin
124	Can delete boostrap3 panel plugin	40	delete_boostrap3panelplugin
125	Can add boostrap3 panel heading plugin	41	add_boostrap3panelheadingplugin
126	Can change boostrap3 panel heading plugin	41	change_boostrap3panelheadingplugin
127	Can delete boostrap3 panel heading plugin	41	delete_boostrap3panelheadingplugin
128	Can add boostrap3 panel body plugin	42	add_boostrap3panelbodyplugin
129	Can change boostrap3 panel body plugin	42	change_boostrap3panelbodyplugin
130	Can delete boostrap3 panel body plugin	42	delete_boostrap3panelbodyplugin
131	Can add boostrap3 panel footer plugin	43	add_boostrap3panelfooterplugin
132	Can change boostrap3 panel footer plugin	43	change_boostrap3panelfooterplugin
133	Can delete boostrap3 panel footer plugin	43	delete_boostrap3panelfooterplugin
134	Can add boostrap3 spacer plugin	44	add_boostrap3spacerplugin
135	Can change boostrap3 spacer plugin	44	change_boostrap3spacerplugin
136	Can delete boostrap3 spacer plugin	44	delete_boostrap3spacerplugin
137	Can add bootstrap3 row plugin	45	add_bootstrap3rowplugin
138	Can change bootstrap3 row plugin	45	change_bootstrap3rowplugin
139	Can delete bootstrap3 row plugin	45	delete_bootstrap3rowplugin
140	Can add bootstrap3 column plugin	46	add_bootstrap3columnplugin
141	Can change bootstrap3 column plugin	46	change_bootstrap3columnplugin
142	Can delete bootstrap3 column plugin	46	delete_bootstrap3columnplugin
143	Can add bootstrap3 accordion plugin	47	add_bootstrap3accordionplugin
144	Can change bootstrap3 accordion plugin	47	change_bootstrap3accordionplugin
145	Can delete bootstrap3 accordion plugin	47	delete_bootstrap3accordionplugin
146	Can add bootstrap3 accordion item plugin	48	add_bootstrap3accordionitemplugin
147	Can change bootstrap3 accordion item plugin	48	change_bootstrap3accordionitemplugin
148	Can delete bootstrap3 accordion item plugin	48	delete_bootstrap3accordionitemplugin
149	Can add bootstrap3 list group plugin	49	add_bootstrap3listgroupplugin
150	Can change bootstrap3 list group plugin	49	change_bootstrap3listgroupplugin
151	Can delete bootstrap3 list group plugin	49	delete_bootstrap3listgroupplugin
152	Can add bootstrap3 list group item plugin	50	add_bootstrap3listgroupitemplugin
153	Can change bootstrap3 list group item plugin	50	change_bootstrap3listgroupitemplugin
154	Can delete bootstrap3 list group item plugin	50	delete_bootstrap3listgroupitemplugin
155	Can add bootstrap3 carousel plugin	51	add_bootstrap3carouselplugin
156	Can change bootstrap3 carousel plugin	51	change_bootstrap3carouselplugin
157	Can delete bootstrap3 carousel plugin	51	delete_bootstrap3carouselplugin
158	Can add bootstrap3 carousel slide plugin	52	add_bootstrap3carouselslideplugin
159	Can change bootstrap3 carousel slide plugin	52	change_bootstrap3carouselslideplugin
160	Can delete bootstrap3 carousel slide plugin	52	delete_bootstrap3carouselslideplugin
161	Can add bootstrap3 carousel slide folder plugin	53	add_bootstrap3carouselslidefolderplugin
162	Can change bootstrap3 carousel slide folder plugin	53	change_bootstrap3carouselslidefolderplugin
163	Can delete bootstrap3 carousel slide folder plugin	53	delete_bootstrap3carouselslidefolderplugin
164	Can add source	54	add_source
165	Can change source	54	change_source
166	Can delete source	54	delete_source
167	Can add thumbnail	55	add_thumbnail
168	Can change thumbnail	55	change_thumbnail
169	Can delete thumbnail	55	delete_thumbnail
170	Can add thumbnail dimensions	56	add_thumbnaildimensions
171	Can change thumbnail dimensions	56	change_thumbnaildimensions
172	Can delete thumbnail dimensions	56	delete_thumbnaildimensions
173	Can add filer file	57	add_filerfile
174	Can change filer file	57	change_filerfile
175	Can delete filer file	57	delete_filerfile
176	Can add filer image	58	add_filerimage
177	Can change filer image	58	change_filerimage
178	Can delete filer image	58	delete_filerimage
179	Can add thumbnail option	59	add_thumbnailoption
180	Can change thumbnail option	59	change_thumbnailoption
181	Can delete thumbnail option	59	delete_thumbnailoption
182	Can add revision	60	add_revision
183	Can change revision	60	change_revision
184	Can delete revision	60	delete_revision
185	Can add version	61	add_version
186	Can change version	61	change_version
187	Can delete version	61	delete_version
188	Can add url	62	add_url
189	Can change url	62	change_url
190	Can delete url	62	delete_url
191	Can add rule	63	add_rule
192	Can change rule	63	change_rule
193	Can delete rule	63	delete_rule
194	Can add text	64	add_text
195	Can change text	64	change_text
196	Can delete text	64	delete_text
197	Can add link	65	add_link
198	Can change link	65	change_link
199	Can delete link	65	delete_link
200	Can add Snippet	66	add_snippet
201	Can change Snippet	66	change_snippet
202	Can delete Snippet	66	delete_snippet
203	Can add Snippet	67	add_snippetptr
204	Can change Snippet	67	change_snippetptr
205	Can delete Snippet	67	delete_snippetptr
206	Can add google map	68	add_googlemap
207	Can change google map	68	change_googlemap
208	Can delete google map	68	delete_googlemap
209	Can add form plugin	69	add_formplugin
210	Can change form plugin	69	change_formplugin
211	Can delete form plugin	69	delete_formplugin
212	Can add fieldset plugin	70	add_fieldsetplugin
213	Can change fieldset plugin	70	change_fieldsetplugin
214	Can delete fieldset plugin	70	delete_fieldsetplugin
215	Can add field plugin	71	add_fieldplugin
216	Can change field plugin	71	change_fieldplugin
217	Can delete field plugin	71	delete_fieldplugin
218	Can add text area field plugin	72	add_textareafieldplugin
219	Can change text area field plugin	72	change_textareafieldplugin
220	Can delete text area field plugin	72	delete_textareafieldplugin
221	Can add email field plugin	73	add_emailfieldplugin
222	Can change email field plugin	73	change_emailfieldplugin
223	Can delete email field plugin	73	delete_emailfieldplugin
224	Can add file upload field plugin	74	add_fileuploadfieldplugin
225	Can change file upload field plugin	74	change_fileuploadfieldplugin
226	Can delete file upload field plugin	74	delete_fileuploadfieldplugin
227	Can add image upload field plugin	75	add_imageuploadfieldplugin
228	Can change image upload field plugin	75	change_imageuploadfieldplugin
229	Can delete image upload field plugin	75	delete_imageuploadfieldplugin
230	Can add option	76	add_option
231	Can change option	76	change_option
232	Can delete option	76	delete_option
233	Can add form button plugin	77	add_formbuttonplugin
234	Can change form button plugin	77	change_formbuttonplugin
235	Can delete form button plugin	77	delete_formbuttonplugin
236	Can add Form submission	78	add_formdata
237	Can change Form submission	78	change_formdata
238	Can delete Form submission	78	delete_formdata
239	Can use Structure mode	13	use_structure
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_permission_id_seq', 239, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	!Okjdc4b9lfbxJiSosYDU5yIgsWdgjEo3CmMF5X6T	2015-05-22 13:22:20.809118+02	t	angelo.dini-12	Angelo	Dini	angelo.dini@divio.ch	t	t	2015-05-22 10:17:59.647887+02
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_id_seq', 1, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: captcha_captchastore; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY captcha_captchastore (id, challenge, response, hashkey, expiration) FROM stdin;
\.


--
-- Name: captcha_captchastore_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('captcha_captchastore_id_seq', 1, false);


--
-- Data for Name: cms_aliaspluginmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_aliaspluginmodel (cmsplugin_ptr_id, plugin_id, alias_placeholder_id) FROM stdin;
\.


--
-- Data for Name: cms_cmsplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_cmsplugin (id, placeholder_id, parent_id, "position", language, plugin_type, creation_date, changed_date, path, depth, numchild) FROM stdin;
2	2	1	0	en	Bootstrap3ImageCMSPlugin	2015-05-22 10:56:32.155156+02	2015-05-22 10:57:32.263513+02	00010001	2	0
1	2	\N	0	en	StylePlugin	2015-05-22 10:56:01.162919+02	2015-05-22 10:58:31.719967+02	0001	1	1
3	2	\N	2	en	StylePlugin	2015-05-22 10:58:07.414022+02	2015-05-22 10:58:21.519059+02	0002	1	1
8	2	3	1	en	StylePlugin	2015-05-22 11:01:16.060864+02	2015-05-22 11:01:22.155075+02	00020002	2	1
5	2	4	0	en	Bootstrap3ColumnCMSPlugin	2015-05-22 10:59:10.499039+02	2015-05-22 11:01:29.635017+02	0002000200010001	4	2
6	2	5	0	en	Bootstrap3SpacerCMSPlugin	2015-05-22 10:59:50.854682+02	2015-05-22 11:01:29.638794+02	00020002000100010001	5	0
7	2	5	1	en	TextPlugin	2015-05-22 11:00:04.937277+02	2015-05-22 11:01:29.642632+02	00020002000100010002	5	0
4	2	8	0	en	Bootstrap3RowCMSPlugin	2015-05-22 10:58:44.22542+02	2015-05-22 11:01:29.651895+02	000200020001	3	1
9	8	\N	0	en	TextPlugin	2015-05-22 11:02:09.409673+02	2015-05-22 11:02:13.516093+02	0003	1	0
11	10	10	0	en	Bootstrap3ButtonCMSPlugin	2015-05-22 11:02:50.656629+02	2015-05-22 11:03:05.927164+02	00040001	2	0
10	10	\N	0	en	TextPlugin	2015-05-22 11:02:31.62601+02	2015-05-22 11:03:11.56536+02	0004	1	1
51	7	49	1	en	TextPlugin	2015-05-22 12:55:01.417204+02	2015-05-22 12:56:25.844908+02	000C00030002	3	0
46	7	39	\N	en	Bootstrap3ListGroupItemCMSPlugin	2015-05-22 12:55:39.162767+02	2015-05-22 12:55:39.214728+02	000C0002	2	0
21	3	20	0	en	Bootstrap3ColumnCMSPlugin	2015-05-22 11:06:23.067414+02	2015-05-22 11:06:23.070254+02	000500070001	3	1
36	7	38	0	en	TextPlugin	2015-05-22 11:16:35.674531+02	2015-05-22 11:17:13.084803+02	000B0001	2	0
26	3	25	0	en	Bootstrap3IconCMSPlugin	2015-05-22 11:06:50.389734+02	2015-05-22 11:07:12.797266+02	00050007000100010001	5	0
25	3	21	0	en	TextPlugin	2015-05-22 11:06:36.687053+02	2015-05-22 11:07:17.127628+02	0005000700010001	4	1
22	3	20	1	en	Bootstrap3ColumnCMSPlugin	2015-05-22 11:06:23.076901+02	2015-05-22 11:06:23.080854+02	000500070002	3	1
37	7	\N	1	en	Bootstrap3SpacerCMSPlugin	2015-05-22 11:16:47.506489+02	2015-05-22 11:17:13.092933+02	000A	1	0
28	3	27	0	en	Bootstrap3IconCMSPlugin	2015-05-22 11:08:02.785517+02	2015-05-22 11:08:10.963255+02	00050007000200010001	5	0
27	3	22	0	en	TextPlugin	2015-05-22 11:07:50.132271+02	2015-05-22 11:08:12.441753+02	0005000700020001	4	1
23	3	20	2	en	Bootstrap3ColumnCMSPlugin	2015-05-22 11:06:23.085742+02	2015-05-22 11:06:23.089031+02	000500070003	3	1
38	7	\N	0	en	StylePlugin	2015-05-22 11:17:01.481937+02	2015-05-22 11:17:13.09945+02	000B	1	1
30	3	29	0	en	Bootstrap3IconCMSPlugin	2015-05-22 11:08:35.830034+02	2015-05-22 11:08:46.762039+02	00050007000300010001	5	0
29	3	23	0	en	TextPlugin	2015-05-22 11:08:25.281939+02	2015-05-22 11:08:48.535723+02	0005000700030001	4	1
24	3	20	3	en	Bootstrap3ColumnCMSPlugin	2015-05-22 11:06:23.094825+02	2015-05-22 11:06:23.097958+02	000500070004	3	1
32	3	31	0	en	Bootstrap3IconCMSPlugin	2015-05-22 11:09:13.485859+02	2015-05-22 11:09:19.976079+02	00050007000400010001	5	0
31	3	24	0	en	TextPlugin	2015-05-22 11:09:03.312179+02	2015-05-22 11:09:21.189683+02	0005000700040001	4	1
47	7	46	0	en	Bootstrap3ImageCMSPlugin	2015-05-22 11:18:20.205956+02	2015-05-22 12:55:39.186196+02	000C00020001	3	0
12	3	\N	0	en	StylePlugin	2015-05-22 11:03:41.457817+02	2015-05-22 11:03:47.125804+02	0005	1	8
13	3	12	0	en	Bootstrap3SpacerCMSPlugin	2015-05-22 11:04:01.806035+02	2015-05-22 11:09:53.65591+02	00050001	2	0
15	3	12	1	en	TextPlugin	2015-05-22 11:04:28.907568+02	2015-05-22 11:09:53.662222+02	00050003	2	0
14	3	12	2	en	Bootstrap3SpacerCMSPlugin	2015-05-22 11:04:16.457469+02	2015-05-22 11:09:53.669251+02	00050002	2	0
16	3	12	3	en	TextPlugin	2015-05-22 11:04:47.410034+02	2015-05-22 11:09:53.676319+02	00050004	2	0
18	3	12	5	en	TextPlugin	2015-05-22 11:05:30.146895+02	2015-05-22 11:09:53.683169+02	00050005	2	0
17	3	12	4	en	Bootstrap3SpacerCMSPlugin	2015-05-22 11:05:12.306498+02	2015-05-22 11:09:53.691587+02	00050008	2	0
19	3	12	6	en	Bootstrap3SpacerCMSPlugin	2015-05-22 11:05:45.474787+02	2015-05-22 11:09:53.699559+02	00050006	2	0
20	3	12	7	en	Bootstrap3RowCMSPlugin	2015-05-22 11:06:05.640613+02	2015-05-22 11:09:53.708685+02	00050007	2	4
33	3	\N	21	en	Bootstrap3SpacerCMSPlugin	2015-05-22 11:09:38.604832+02	2015-05-22 11:14:41.317521+02	0007	1	0
48	7	46	1	en	TextPlugin	2015-05-22 12:55:01.417204+02	2015-05-22 12:55:39.228758+02	000C00020002	3	0
35	3	34	0	en	TextPlugin	2015-05-22 11:15:21.507277+02	2015-05-22 11:15:26.376874+02	00080001	2	0
34	3	\N	22	en	StylePlugin	2015-05-22 11:14:56.992232+02	2015-05-22 11:15:42.211384+02	0008	1	1
40	7	39	0	en	Bootstrap3ListGroupItemCMSPlugin	2015-05-22 11:17:49.188288+02	2015-05-22 11:17:58.976541+02	000C0001	2	2
39	7	\N	3	en	Bootstrap3ListGroupCMSPlugin	2015-05-22 11:17:35.161506+02	2015-05-22 12:55:18.808542+02	000C	1	4
42	7	40	1	en	TextPlugin	2015-05-22 12:55:01.417204+02	2015-05-22 12:58:13.299192+02	000C00010002	3	0
41	7	40	0	en	Bootstrap3ImageCMSPlugin	2015-05-22 11:18:20.205956+02	2015-05-22 12:58:57.177017+02	000C00010001	3	0
49	7	39	\N	en	Bootstrap3ListGroupItemCMSPlugin	2015-05-22 12:55:44.617185+02	2015-05-22 12:55:44.678329+02	000C0003	2	0
50	7	49	0	en	Bootstrap3ImageCMSPlugin	2015-05-22 11:18:20.205956+02	2015-05-22 12:55:59.352958+02	000C00030001	3	0
87	19	\N	1	en	Bootstrap3SpacerCMSPlugin	2015-05-22 11:16:47.506489+02	2015-05-22 12:59:10.384961+02	000J	1	0
65	9	\N	0	en	TextPlugin	2015-05-22 11:02:09.409673+02	2015-05-22 12:57:11.667204+02	000H	1	0
67	11	66	0	en	Bootstrap3ButtonCMSPlugin	2015-05-22 11:02:50.656629+02	2015-05-22 12:57:11.698261+02	000I0001	2	0
66	11	\N	0	en	TextPlugin	2015-05-22 11:02:31.62601+02	2015-05-22 12:57:11.710222+02	000I	1	1
88	19	\N	0	en	StylePlugin	2015-05-22 11:17:01.481937+02	2015-05-22 12:59:10.39866+02	000K	1	1
68	7	39	\N	en	Bootstrap3ListGroupItemCMSPlugin	2015-05-22 12:57:30.754581+02	2015-05-22 12:57:30.803092+02	000C0004	2	0
70	7	68	1	en	TextPlugin	2015-05-22 12:55:01.417204+02	2015-05-22 12:57:30.816124+02	000C00040002	3	0
92	19	91	0	en	Bootstrap3ImageCMSPlugin	2015-05-22 11:18:20.205956+02	2015-05-22 12:59:10.454769+02	000L00010001	3	0
91	19	90	0	en	Bootstrap3ListGroupItemCMSPlugin	2015-05-22 11:17:49.188288+02	2015-05-22 12:59:10.441711+02	000L0001	2	2
69	7	68	0	en	Bootstrap3ImageCMSPlugin	2015-05-22 11:18:20.205956+02	2015-05-22 12:58:38.4995+02	000C00040001	3	0
95	19	94	0	en	Bootstrap3ImageCMSPlugin	2015-05-22 11:18:20.205956+02	2015-05-22 12:59:10.500556+02	000L00020001	3	0
94	19	90	\N	en	Bootstrap3ListGroupItemCMSPlugin	2015-05-22 12:55:39.162767+02	2015-05-22 12:59:10.488832+02	000L0002	2	2
98	19	97	0	en	Bootstrap3ImageCMSPlugin	2015-05-22 11:18:20.205956+02	2015-05-22 12:59:10.540761+02	000L00030001	3	0
97	19	90	\N	en	Bootstrap3ListGroupItemCMSPlugin	2015-05-22 12:55:44.617185+02	2015-05-22 12:59:10.528248+02	000L0003	2	2
90	19	\N	3	en	Bootstrap3ListGroupCMSPlugin	2015-05-22 11:17:35.161506+02	2015-05-22 12:59:10.429491+02	000L	1	4
101	19	100	0	en	Bootstrap3ImageCMSPlugin	2015-05-22 11:18:20.205956+02	2015-05-22 12:59:10.579952+02	000L00040001	3	0
100	19	90	\N	en	Bootstrap3ListGroupItemCMSPlugin	2015-05-22 12:57:30.754581+02	2015-05-22 12:59:10.568205+02	000L0004	2	2
89	19	88	0	en	TextPlugin	2015-05-22 11:16:35.674531+02	2015-05-22 12:59:10.604783+02	000K0001	2	0
93	19	91	1	en	TextPlugin	2015-05-22 12:55:01.417204+02	2015-05-22 12:59:10.61556+02	000L00010002	3	0
96	19	94	1	en	TextPlugin	2015-05-22 12:55:01.417204+02	2015-05-22 12:59:10.623408+02	000L00020002	3	0
99	19	97	1	en	TextPlugin	2015-05-22 12:55:01.417204+02	2015-05-22 12:59:10.631085+02	000L00030002	3	0
102	19	100	1	en	TextPlugin	2015-05-22 12:55:01.417204+02	2015-05-22 12:59:10.638743+02	000L00040002	3	0
103	4	\N	0	en	StylePlugin	2015-05-22 10:56:01.162919+02	2015-05-22 12:59:29.527809+02	000M	1	1
104	4	103	0	en	Bootstrap3ImageCMSPlugin	2015-05-22 10:56:32.155156+02	2015-05-22 12:59:29.540341+02	000M0001	2	0
105	4	\N	2	en	StylePlugin	2015-05-22 10:58:07.414022+02	2015-05-22 12:59:29.551681+02	000N	1	1
106	4	105	1	en	StylePlugin	2015-05-22 11:01:16.060864+02	2015-05-22 12:59:29.563566+02	000N0001	2	1
107	4	106	0	en	Bootstrap3RowCMSPlugin	2015-05-22 10:58:44.22542+02	2015-05-22 12:59:29.576644+02	000N00010001	3	1
109	4	108	0	en	Bootstrap3SpacerCMSPlugin	2015-05-22 10:59:50.854682+02	2015-05-22 12:59:29.601766+02	000N0001000100010001	5	0
108	4	107	0	en	Bootstrap3ColumnCMSPlugin	2015-05-22 10:59:10.499039+02	2015-05-22 12:59:29.58936+02	000N000100010001	4	2
110	4	108	1	en	TextPlugin	2015-05-22 11:00:04.937277+02	2015-05-22 12:59:29.633579+02	000N0001000100010002	5	0
112	5	111	0	en	Bootstrap3SpacerCMSPlugin	2015-05-22 11:04:01.806035+02	2015-05-22 12:59:29.663443+02	000O0001	2	0
113	5	111	2	en	Bootstrap3SpacerCMSPlugin	2015-05-22 11:04:16.457469+02	2015-05-22 12:59:29.676608+02	000O0002	2	0
117	5	111	6	en	Bootstrap3SpacerCMSPlugin	2015-05-22 11:05:45.474787+02	2015-05-22 12:59:29.730775+02	000O0006	2	0
119	5	118	0	en	Bootstrap3ColumnCMSPlugin	2015-05-22 11:06:23.067414+02	2015-05-22 12:59:29.756917+02	000O00070001	3	1
121	5	120	0	en	Bootstrap3IconCMSPlugin	2015-05-22 11:06:50.389734+02	2015-05-22 12:59:29.784802+02	000O0007000100010001	5	0
122	5	118	1	en	Bootstrap3ColumnCMSPlugin	2015-05-22 11:06:23.076901+02	2015-05-22 12:59:29.798485+02	000O00070002	3	1
124	5	123	0	en	Bootstrap3IconCMSPlugin	2015-05-22 11:08:02.785517+02	2015-05-22 12:59:29.826237+02	000O0007000200010001	5	0
125	5	118	2	en	Bootstrap3ColumnCMSPlugin	2015-05-22 11:06:23.085742+02	2015-05-22 12:59:29.839154+02	000O00070003	3	1
127	5	126	0	en	Bootstrap3IconCMSPlugin	2015-05-22 11:08:35.830034+02	2015-05-22 12:59:29.863802+02	000O0007000300010001	5	0
118	5	111	7	en	Bootstrap3RowCMSPlugin	2015-05-22 11:06:05.640613+02	2015-05-22 12:59:29.744882+02	000O0007	2	4
128	5	118	3	en	Bootstrap3ColumnCMSPlugin	2015-05-22 11:06:23.094825+02	2015-05-22 12:59:29.877607+02	000O00070004	3	1
130	5	129	0	en	Bootstrap3IconCMSPlugin	2015-05-22 11:09:13.485859+02	2015-05-22 12:59:29.902895+02	000O0007000400010001	5	0
111	5	\N	0	en	StylePlugin	2015-05-22 11:03:41.457817+02	2015-05-22 12:59:29.650089+02	000O	1	8
131	5	111	4	en	Bootstrap3SpacerCMSPlugin	2015-05-22 11:05:12.306498+02	2015-05-22 12:59:29.918347+02	000O0008	2	0
132	5	\N	21	en	Bootstrap3SpacerCMSPlugin	2015-05-22 11:09:38.604832+02	2015-05-22 12:59:29.929059+02	000P	1	0
133	5	\N	22	en	StylePlugin	2015-05-22 11:14:56.992232+02	2015-05-22 12:59:29.939807+02	000Q	1	1
114	5	111	1	en	TextPlugin	2015-05-22 11:04:28.907568+02	2015-05-22 12:59:29.966359+02	000O0003	2	0
115	5	111	3	en	TextPlugin	2015-05-22 11:04:47.410034+02	2015-05-22 12:59:29.97064+02	000O0004	2	0
116	5	111	5	en	TextPlugin	2015-05-22 11:05:30.146895+02	2015-05-22 12:59:29.974824+02	000O0005	2	0
120	5	119	0	en	TextPlugin	2015-05-22 11:06:36.687053+02	2015-05-22 12:59:29.986459+02	000O000700010001	4	1
123	5	122	0	en	TextPlugin	2015-05-22 11:07:50.132271+02	2015-05-22 12:59:29.996656+02	000O000700020001	4	1
126	5	125	0	en	TextPlugin	2015-05-22 11:08:25.281939+02	2015-05-22 12:59:30.006869+02	000O000700030001	4	1
129	5	128	0	en	TextPlugin	2015-05-22 11:09:03.312179+02	2015-05-22 12:59:30.017072+02	000O000700040001	4	1
134	5	133	0	en	TextPlugin	2015-05-22 11:15:21.507277+02	2015-05-22 12:59:30.028237+02	000Q0001	2	0
139	31	\N	0	en	StylePlugin	2015-05-22 13:03:20.34107+02	2015-05-22 13:05:46.617149+02	000T	1	1
141	31	\N	2	en	Bootstrap3SpacerCMSPlugin	2015-05-22 13:05:09.132715+02	2015-05-22 13:05:46.641889+02	000U	1	0
140	31	139	0	en	TextPlugin	2015-05-22 13:03:35.217263+02	2015-05-22 13:05:46.650557+02	000T0001	2	0
\.


--
-- Name: cms_cmsplugin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_cmsplugin_id_seq', 141, true);


--
-- Data for Name: cms_globalpagepermission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_globalpagepermission (id, user_id, group_id, can_change, can_add, can_delete, can_change_advanced_settings, can_publish, can_change_permissions, can_move_page, can_view, can_recover_page) FROM stdin;
\.


--
-- Name: cms_globalpagepermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_globalpagepermission_id_seq', 1, false);


--
-- Data for Name: cms_globalpagepermission_sites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_globalpagepermission_sites (id, globalpagepermission_id, site_id) FROM stdin;
\.


--
-- Name: cms_globalpagepermission_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_globalpagepermission_sites_id_seq', 1, false);


--
-- Data for Name: cms_page; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_page (id, created_by, changed_by, parent_id, creation_date, changed_date, publication_date, publication_end_date, in_navigation, soft_root, reverse_id, navigation_extenders, template, site_id, login_required, limit_visibility_in_menu, publisher_is_draft, publisher_public_id, revision_id, application_urls, application_namespace, is_home, languages, xframe_options, path, depth, numchild) FROM stdin;
7	angelo.dini-12	angelo.dini-12	\N	2015-05-22 10:54:04.458601+02	2015-05-22 12:59:10.650156+02	2015-05-22 10:54:04.440911+02	\N	t	f	\N	\N	INHERIT	1	f	\N	f	3	0	\N	\N	f	en	0	0004	1	0
4	angelo.dini-12	angelo.dini-12	\N	2015-05-22 10:53:37.817712+02	2015-05-22 10:54:36.26224+02	2015-05-22 10:54:35.664797+02	\N	f	f	footer		INHERIT	1	f	\N	t	8	0		\N	f	en	0	0005	1	2
8	angelo.dini-12	angelo.dini-12	\N	2015-05-22 10:54:35.681356+02	2015-05-22 10:54:35.879652+02	2015-05-22 10:54:35.664797+02	\N	f	f	footer		INHERIT	1	f	\N	f	4	0		\N	f	en	0	0006	1	2
2	angelo.dini-12	angelo.dini-12	\N	2015-05-22 10:53:16.101569+02	2015-05-22 12:59:30.080963+02	2015-05-22 10:53:16.088807+02	\N	t	f	\N	\N	tpl_home.html	1	f	\N	f	1	0	\N	\N	t	en	0	0002	1	0
9	angelo.dini-12	angelo.dini-12	8	2015-05-22 10:54:36.043374+02	2015-05-22 13:00:45.490236+02	2015-05-22 10:54:20.596101+02	\N	t	f	\N		INHERIT	1	f	\N	f	5	0		\N	f	en	0	00060001	2	0
5	angelo.dini-12	angelo.dini-12	4	2015-05-22 10:53:46.745182+02	2015-05-22 13:00:45.656602+02	2015-05-22 10:54:20.596101+02	\N	t	f	\N		INHERIT	1	f	\N	t	9	0		\N	f	en	0	00050001	2	0
10	angelo.dini-12	angelo.dini-12	8	2015-05-22 10:55:17.781571+02	2015-05-22 13:00:51.538191+02	2015-05-22 10:55:17.729485+02	\N	t	f	\N		INHERIT	1	f	\N	f	6	0		\N	f	en	0	00060002	2	0
6	angelo.dini-12	angelo.dini-12	4	2015-05-22 10:53:57.911514+02	2015-05-22 13:00:51.646771+02	2015-05-22 10:55:17.729485+02	\N	t	f	\N		INHERIT	1	f	\N	t	10	0		\N	f	en	0	00050002	2	0
12	angelo.dini-12	angelo.dini-12	\N	2015-05-22 13:05:43.702185+02	2015-05-22 13:05:43.799792+02	\N	\N	f	f	page_types	\N	INHERIT	1	f	\N	t	\N	0	\N	\N	f	en	0	0008	1	1
13	angelo.dini-12	angelo.dini-12	12	2015-05-22 13:05:46.465281+02	2015-05-22 13:05:46.73867+02	\N	\N	f	f	\N	\N	INHERIT	1	f	\N	t	\N	0	\N	\N	f	en	0	00080001	2	0
1	angelo.dini-12	angelo.dini-12	\N	2015-05-22 10:53:15.88738+02	2015-05-22 13:05:56.245598+02	2015-05-22 10:53:16.088807+02	\N	t	f	\N	\N	tpl_home.html	1	f	\N	t	2	0	\N	\N	t	en	0	0001	1	0
3	angelo.dini-12	angelo.dini-12	\N	2015-05-22 10:53:21.999651+02	2015-05-22 12:59:10.911731+02	2015-05-22 10:54:04.440911+02	\N	t	f	\N	\N	INHERIT	1	f	\N	t	7	0	\N	\N	f	en	0	0003	1	0
\.


--
-- Name: cms_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_page_id_seq', 13, true);


--
-- Data for Name: cms_page_placeholders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_page_placeholders (id, page_id, placeholder_id) FROM stdin;
1	1	2
2	1	3
3	2	4
4	2	5
5	3	6
6	3	7
7	4	12
8	4	13
9	5	14
10	5	15
11	6	16
12	6	17
13	7	18
14	7	19
15	8	20
16	8	21
17	9	22
18	9	23
19	10	24
20	10	25
23	12	28
24	12	29
25	13	30
26	13	31
\.


--
-- Name: cms_page_placeholders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_page_placeholders_id_seq', 26, true);


--
-- Data for Name: cms_pagepermission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_pagepermission (id, user_id, group_id, can_change, can_add, can_delete, can_change_advanced_settings, can_publish, can_change_permissions, can_move_page, can_view, grant_on, page_id) FROM stdin;
\.


--
-- Name: cms_pagepermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_pagepermission_id_seq', 1, false);


--
-- Data for Name: cms_pageuser; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_pageuser (user_ptr_id, created_by_id) FROM stdin;
\.


--
-- Data for Name: cms_pageusergroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_pageusergroup (group_ptr_id, created_by_id) FROM stdin;
\.


--
-- Data for Name: cms_placeholder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_placeholder (id, slot, default_width) FROM stdin;
1	clipboard	\N
2	feature	\N
3	content	\N
4	feature	\N
5	content	\N
6	feature	\N
7	content	\N
8	footer	\N
9	footer	\N
10	footer-theme	\N
11	footer-theme	\N
12	feature	\N
13	content	\N
14	feature	\N
15	content	\N
16	feature	\N
17	content	\N
18	feature	\N
19	content	\N
20	feature	\N
21	content	\N
22	feature	\N
23	content	\N
24	feature	\N
25	content	\N
28	feature	\N
29	content	\N
30	feature	\N
31	content	\N
\.


--
-- Name: cms_placeholder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_placeholder_id_seq', 31, true);


--
-- Data for Name: cms_placeholderreference; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_placeholderreference (cmsplugin_ptr_id, name, placeholder_ref_id) FROM stdin;
\.


--
-- Data for Name: cms_staticplaceholder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_staticplaceholder (id, name, code, draft_id, public_id, dirty, creation_method, site_id) FROM stdin;
1	footer	footer	8	9	f	template	\N
2	footer-theme	footer-theme	10	11	f	template	\N
\.


--
-- Name: cms_staticplaceholder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_staticplaceholder_id_seq', 2, true);


--
-- Data for Name: cms_title; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_title (id, language, title, menu_title, slug, path, has_url_overwrite, redirect, meta_description, page_title, page_id, creation_date, published, publisher_is_draft, publisher_public_id, publisher_state) FROM stdin;
7	en	About		about	about	f	\N			7	2015-05-22 10:53:22.118341+02	t	f	3	0
8	en	Footer		footer	footer	f				8	2015-05-22 10:53:37.900257+02	t	f	4	0
4	en	Footer		footer	footer	f				4	2015-05-22 10:53:37.900257+02	t	t	8	0
2	en	Home		home		f	\N			2	2015-05-22 10:53:15.998171+02	t	f	1	0
9	en	Impressum		impressum	footer/impressum	f	/en/about/			9	2015-05-22 10:53:46.838783+02	t	f	5	0
5	en	Impressum		impressum	footer/impressum	f	/en/about/			5	2015-05-22 10:53:46.838783+02	t	t	9	0
10	en	Terms		terms	footer/terms	f	/en/about/			10	2015-05-22 10:53:57.996636+02	t	f	6	0
6	en	Terms		terms	footer/terms	f	/en/about/			6	2015-05-22 10:53:57.996636+02	t	t	10	0
12	en	Page Types	\N	page_types	page_types	f	\N	\N	\N	12	2015-05-22 13:05:43.791998+02	f	t	\N	1
13	en	Content	\N	content	page_types/content	f	\N	\N	\N	13	2015-05-22 13:05:46.655705+02	f	t	\N	1
3	en	About		about	about	f	\N			3	2015-05-22 10:53:22.118341+02	t	t	7	0
1	en	Home		home		f	\N			1	2015-05-22 10:53:15.998171+02	t	t	2	0
\.


--
-- Name: cms_title_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_title_id_seq', 13, true);


--
-- Data for Name: cms_usersettings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_usersettings (id, user_id, language, clipboard_id) FROM stdin;
1	1	en	1
\.


--
-- Name: cms_usersettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_usersettings_id_seq', 1, true);


--
-- Data for Name: cmscloud_aldrynclouduser; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cmscloud_aldrynclouduser (id, cloud_id, user_id) FROM stdin;
1	12	1
\.


--
-- Name: cmscloud_aldrynclouduser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cmscloud_aldrynclouduser_id_seq', 1, true);


--
-- Data for Name: cmsplugin_filer_file_filerfile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cmsplugin_filer_file_filerfile (cmsplugin_ptr_id, file_id, title, target_blank, style) FROM stdin;
\.


--
-- Data for Name: cmsplugin_filer_image_filerimage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cmsplugin_filer_image_filerimage (cmsplugin_ptr_id, image_id, alt_text, caption_text, use_autoscale, width, height, alignment, free_link, page_link_id, description, image_url, thumbnail_option_id, crop, upscale, original_link, file_link_id, use_original_image, target_blank, style) FROM stdin;
\.


--
-- Data for Name: cmsplugin_filer_image_thumbnailoption; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cmsplugin_filer_image_thumbnailoption (id, name, width, height, crop, upscale) FROM stdin;
\.


--
-- Name: cmsplugin_filer_image_thumbnailoption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cmsplugin_filer_image_thumbnailoption_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_admin_log (id, action_time, user_id, content_type_id, object_id, object_repr, action_flag, change_message) FROM stdin;
1	2015-05-22 10:53:16.54083+02	1	11	1	Home	1	
2	2015-05-22 10:53:22.20028+02	1	11	3	About	1	
3	2015-05-22 10:53:37.9839+02	1	11	4	Footer	1	
4	2015-05-22 10:53:46.884582+02	1	11	5	Impressum	1	
5	2015-05-22 10:53:58.039212+02	1	11	6	Terms	1	
6	2015-05-22 10:54:04.838734+02	1	11	3	About	2	
7	2015-05-22 10:54:15.979062+02	1	11	4	Footer	2	Changed reverse_id and xframe_options.
8	2015-05-22 10:54:36.238066+02	1	11	4	Footer	2	
9	2015-05-22 10:55:18.012125+02	1	11	6	Terms	2	
10	2015-05-22 12:55:32.459995+02	1	11	1	clipboard	3	
11	2015-05-22 12:57:11.719418+02	1	11	3	About	2	
12	2015-05-22 12:58:20.479498+02	1	11	3	About	2	
13	2015-05-22 12:59:10.816964+02	1	11	3	About	2	
14	2015-05-22 12:59:30.198323+02	1	11	1	Home	2	
15	2015-05-22 13:00:27.944337+02	1	11	5	Impressum	2	Changed redirect and xframe_options.
16	2015-05-22 13:00:40.235423+02	1	11	6	Terms	2	Changed redirect and xframe_options.
17	2015-05-22 13:00:45.624117+02	1	11	5	Impressum	2	
18	2015-05-22 13:00:51.614111+02	1	11	6	Terms	2	
19	2015-05-22 13:02:09.888925+02	1	11	1	clipboard	3	
20	2015-05-22 13:03:07.4888+02	1	11	11	Content	1	
21	2015-05-22 13:04:57.796559+02	1	11	137	137	3	
22	2015-05-22 13:05:46.702023+02	1	11	13	Content	1	
23	2015-05-22 13:05:55.914921+02	1	11	11	Content	3	
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 23, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
1	permission	auth	permission
2	group	auth	group
3	user	auth	user
4	content type	contenttypes	contenttype
5	session	sessions	session
6	site	sites	site
7	log entry	admin	logentry
8	migration history	south	migrationhistory
9	key map	django_select2	keymap
10	test model	health_check_db	testmodel
11	page	cms	page
12	user setting	cms	usersettings
13	placeholder	cms	placeholder
14	cms plugin	cms	cmsplugin
15	Page global permission	cms	globalpagepermission
16	Page permission	cms	pagepermission
17	User (page)	cms	pageuser
18	User group (page)	cms	pageusergroup
19	title	cms	title
20	placeholder reference	cms	placeholderreference
21	static placeholder	cms	staticplaceholder
22	alias plugin model	cms	aliaspluginmodel
23	cache key	menus	cachekey
24	aldryn cloud user	cmscloud	aldrynclouduser
25	style	aldryn_style	style
26	captcha store	captcha	captchastore
27	Folder	filer	folder
28	folder permission	filer	folderpermission
29	file	filer	file
30	clipboard	filer	clipboard
31	clipboard item	filer	clipboarditem
32	image	filer	image
33	boostrap3 button plugin	aldryn_bootstrap3	boostrap3buttonplugin
34	boostrap3 blockquote plugin	aldryn_bootstrap3	boostrap3blockquoteplugin
35	boostrap3 icon plugin	aldryn_bootstrap3	boostrap3iconplugin
36	boostrap3 label plugin	aldryn_bootstrap3	boostrap3labelplugin
37	boostrap3 well plugin	aldryn_bootstrap3	boostrap3wellplugin
38	boostrap3 alert plugin	aldryn_bootstrap3	boostrap3alertplugin
39	boostrap3 image plugin	aldryn_bootstrap3	boostrap3imageplugin
40	boostrap3 panel plugin	aldryn_bootstrap3	boostrap3panelplugin
41	boostrap3 panel heading plugin	aldryn_bootstrap3	boostrap3panelheadingplugin
42	boostrap3 panel body plugin	aldryn_bootstrap3	boostrap3panelbodyplugin
43	boostrap3 panel footer plugin	aldryn_bootstrap3	boostrap3panelfooterplugin
44	boostrap3 spacer plugin	aldryn_bootstrap3	boostrap3spacerplugin
45	bootstrap3 row plugin	aldryn_bootstrap3	bootstrap3rowplugin
46	bootstrap3 column plugin	aldryn_bootstrap3	bootstrap3columnplugin
47	bootstrap3 accordion plugin	aldryn_bootstrap3	bootstrap3accordionplugin
48	bootstrap3 accordion item plugin	aldryn_bootstrap3	bootstrap3accordionitemplugin
49	bootstrap3 list group plugin	aldryn_bootstrap3	bootstrap3listgroupplugin
50	bootstrap3 list group item plugin	aldryn_bootstrap3	bootstrap3listgroupitemplugin
51	bootstrap3 carousel plugin	aldryn_bootstrap3	bootstrap3carouselplugin
52	bootstrap3 carousel slide plugin	aldryn_bootstrap3	bootstrap3carouselslideplugin
53	bootstrap3 carousel slide folder plugin	aldryn_bootstrap3	bootstrap3carouselslidefolderplugin
54	source	easy_thumbnails	source
55	thumbnail	easy_thumbnails	thumbnail
56	thumbnail dimensions	easy_thumbnails	thumbnaildimensions
57	filer file	cmsplugin_filer_file	filerfile
58	filer image	cmsplugin_filer_image	filerimage
59	thumbnail option	cmsplugin_filer_image	thumbnailoption
60	revision	reversion	revision
61	version	reversion	version
62	url	robots	url
63	rule	robots	rule
64	text	djangocms_text_ckeditor	text
65	link	djangocms_link	link
66	Snippet	djangocms_snippet	snippet
67	Snippet	djangocms_snippet	snippetptr
68	google map	djangocms_googlemap	googlemap
69	form plugin	aldryn_forms	formplugin
70	fieldset plugin	aldryn_forms	fieldsetplugin
71	field plugin	aldryn_forms	fieldplugin
72	text area field plugin	aldryn_forms	textareafieldplugin
73	email field plugin	aldryn_forms	emailfieldplugin
74	file upload field plugin	aldryn_forms	fileuploadfieldplugin
75	image upload field plugin	aldryn_forms	imageuploadfieldplugin
76	option	aldryn_forms	option
77	form button plugin	aldryn_forms	formbuttonplugin
78	Form submission	aldryn_forms	formdata
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_content_type_id_seq', 78, true);


--
-- Data for Name: django_dbcache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_dbcache (cache_key, value, expires) FROM stdin;
:1:cms-render_placeholder:24.en	gAJ9cQEoVQdjb250ZW50cQJjZGphbmdvLnV0aWxzLnNhZmVzdHJpbmcKU2FmZVRleHQKcQNYTQEAAAogICAgICAgICAgICA8ZGl2IGNsYXNzPSJmZWF0dXJlLXZpc3VhbCI+CiAgICAgICAgICAgICAgICA8aW1nIHNyYz0iL3N0YXRpYy9pbWcvdmlzdWFscy9mZWF0dXJlLWRlZmF1bHQuanBnIiBhbHQ9IiI+CiAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJmZWF0dXJlLWNvbnRlbnQgdGV4dC1jZW50ZXIiPgogICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0ic3BhY2VyIHNwYWNlci14cyI+Jm5ic3A7PC9kaXY+CiAgICAgICAgICAgICAgICA8aDE+VGhlIE5leHQgR2lhbnQgTGVhcCBGb3IgTWFua2luZDwvaDE+CiAgICAgICAgICAgIDwvZGl2PgogICAgICAgIHEEhYFxBX1xBmJVB3Nla2l6YWlxB31xCChoA1gDAAAAY3NzcQmFgXEKfXELYl1oA1gCAAAAanNxDIWBcQ19cQ5iXXV1Lg==	2015-05-22 13:01:41+02
:1:cms-render_placeholder:25.en	gAJ9cQEoVQdjb250ZW50cQJjZGphbmdvLnV0aWxzLnNhZmVzdHJpbmcKU2FmZVRleHQKcQNYAAAAAIWBcQR9cQViVQdzZWtpemFpcQZ9cQcoaANYAwAAAGNzc3EIhYFxCX1xCmJdaANYAgAAAGpzcQuFgXEMfXENYl11dS4=	2015-05-22 13:01:41+02
:1:cms-:permission:version	gAJLci4=	2015-05-22 13:10:56+02
:1:cms-render_placeholder:18.en	gAJ9cQEoVQdjb250ZW50cQJjZGphbmdvLnV0aWxzLnNhZmVzdHJpbmcKU2FmZVRleHQKcQNYTQEAAAogICAgICAgICAgICA8ZGl2IGNsYXNzPSJmZWF0dXJlLXZpc3VhbCI+CiAgICAgICAgICAgICAgICA8aW1nIHNyYz0iL3N0YXRpYy9pbWcvdmlzdWFscy9mZWF0dXJlLWRlZmF1bHQuanBnIiBhbHQ9IiI+CiAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJmZWF0dXJlLWNvbnRlbnQgdGV4dC1jZW50ZXIiPgogICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0ic3BhY2VyIHNwYWNlci14cyI+Jm5ic3A7PC9kaXY+CiAgICAgICAgICAgICAgICA8aDE+VGhlIE5leHQgR2lhbnQgTGVhcCBGb3IgTWFua2luZDwvaDE+CiAgICAgICAgICAgIDwvZGl2PgogICAgICAgIHEEhYFxBX1xBmJVB3Nla2l6YWlxB31xCChoA1gDAAAAY3NzcQmFgXEKfXELYl1oA1gCAAAAanNxDIWBcQ19cQ5iXXV1Lg==	2015-05-22 13:01:47+02
:1:cms-render_placeholder:22.en	gAJ9cQEoVQdjb250ZW50cQJjZGphbmdvLnV0aWxzLnNhZmVzdHJpbmcKU2FmZVRleHQKcQNYTQEAAAogICAgICAgICAgICA8ZGl2IGNsYXNzPSJmZWF0dXJlLXZpc3VhbCI+CiAgICAgICAgICAgICAgICA8aW1nIHNyYz0iL3N0YXRpYy9pbWcvdmlzdWFscy9mZWF0dXJlLWRlZmF1bHQuanBnIiBhbHQ9IiI+CiAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJmZWF0dXJlLWNvbnRlbnQgdGV4dC1jZW50ZXIiPgogICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0ic3BhY2VyIHNwYWNlci14cyI+Jm5ic3A7PC9kaXY+CiAgICAgICAgICAgICAgICA8aDE+VGhlIE5leHQgR2lhbnQgTGVhcCBGb3IgTWFua2luZDwvaDE+CiAgICAgICAgICAgIDwvZGl2PgogICAgICAgIHEEhYFxBX1xBmJVB3Nla2l6YWlxB31xCChoA1gDAAAAY3NzcQmFgXEKfXELYl1oA1gCAAAAanNxDIWBcQ19cQ5iXXV1Lg==	2015-05-22 13:00:53+02
:1:cms-render_placeholder:23.en	gAJ9cQEoVQdjb250ZW50cQJjZGphbmdvLnV0aWxzLnNhZmVzdHJpbmcKU2FmZVRleHQKcQNYAAAAAIWBcQR9cQViVQdzZWtpemFpcQZ9cQcoaANYAwAAAGNzc3EIhYFxCX1xCmJdaANYAgAAAGpzcQuFgXEMfXENYl11dS4=	2015-05-22 13:00:53+02
:1:CMS:site_choices-en	gAJdcQFLAVgLAAAAZXhhbXBsZS5jb21xAoZxA2Eu	2015-05-23 11:02:51+02
:1:menu_cache_menu_nodes_en_1_1_user	gAJdcQEoY21lbnVzLmJhc2UKTmF2aWdhdGlvbk5vZGUKcQIpgXEDfXEEKFUIX2NvdW50ZXJxBUsBVQRhdHRycQZ9cQcoVRl2aXNpYmxlX2Zvcl9hdXRoZW50aWNhdGVkcQiIVQ1hdXRoX3JlcXVpcmVkcQmJVQpyZXZlcnNlX2lkcQpOVQdpc19ob21lcQuIVQlzb2Z0X3Jvb3RxDIlVFXZpc2libGVfZm9yX2Fub255bW91c3ENiFUMcmVkaXJlY3RfdXJscQ5OdVUGcGFyZW50cQ9OVQV0aXRsZXEQWAQAAABIb21lVQN1cmxxEVUEL2VuL1UJbmFtZXNwYWNlcRJVB0NNU01lbnVxE1UIY2hpbGRyZW5xFF1VCXBhcmVudF9pZHEVTlUHdmlzaWJsZXEWiFUQcGFyZW50X25hbWVzcGFjZXEXTlUCaWRxGEsBdWJoAimBcRl9cRooaAVLAWgGfXEbKGgIiGgJiWgKTmgLiWgMiWgNiGgOTnVoD05oEFgFAAAAQWJvdXRoEVUKL2VuL2Fib3V0L2gSaBNoFF1oFU5oFohoF05oGEsDdWJoAimBcRx9cR0oaAVLAWgGfXEeKGgIiGgJiWgKWAYAAABmb290ZXJoC4loDIloDYhoDlgAAAAAdWgPTmgQWAYAAABGb290ZXJoEVULL2VuL2Zvb3Rlci9oEmgTaBRdcR8oaAIpgXEgfXEhKGgFSwFoBn1xIihoCIhoCYloCk5oC4loDIloDYhoDlgKAAAAL2VuL2Fib3V0L3VoD2gcaBBYCQAAAEltcHJlc3N1bWgRVRUvZW4vZm9vdGVyL2ltcHJlc3N1bS9oEmgTaBRdaBVLBGgWiGgXaBNoGEsFdWJoAimBcSN9cSQoaAVLAWgGfXElKGgIiGgJiWgKTmgLiWgMiWgNiGgOWAoAAAAvZW4vYWJvdXQvdWgPaBxoEFgFAAAAVGVybXNoEVURL2VuL2Zvb3Rlci90ZXJtcy9oEmgTaBRdaBVLBGgWiGgXaBNoGEsGdWJlaBVOaBaJaBdOaBhLBHViaCBoI2gCKYFxJn1xJyhoBUsBaAZ9cSgoaAiIaAmJaApYCgAAAHBhZ2VfdHlwZXNoC4loDIloDYhoDk51aA9OaBBYCgAAAFBhZ2UgVHlwZXNoEVUPL2VuL3BhZ2VfdHlwZXMvaBJoE2gUXXEpaAIpgXEqfXErKGgFSwFoBn1xLChoCIhoCYloCk5oC4loDIloDYhoDk51aA9oJmgQWAcAAABDb250ZW50aBFVFy9lbi9wYWdlX3R5cGVzL2NvbnRlbnQvaBJoE2gUXWgVSwxoFoloF2gTaBhLDXViYWgVTmgWiWgXTmgYSwx1YmgqZS4=	2015-05-22 14:05:59+02
:1:cms-CMS_PAGE_CACHE_VERSION	gAJLAi4=	2015-05-22 13:23:18+02
:1:cms-render_placeholder:5.en	gAJ9cQEoVQdjb250ZW50cQJjZGphbmdvLnV0aWxzLnNhZmVzdHJpbmcKU2FmZVRleHQKcQNYrwcAAAo8ZGl2IGNsYXNzPSJ0ZXh0LWNlbnRlciI+PGRpdiBjbGFzcz0ic3BhY2VyCiAgICAgc3BhY2VyLWxnCiAgICAiPjwvZGl2PjxoMT5UaGUgTmV4dCBHaWFudCBMZWFwIEZvciBNYW5raW5kPC9oMT48cCBjbGFzcz0ibGVhZCI+Q3VyYWJpdHVyIG5vbiBudWxsYSBzaXQgYW1ldCBuaXNsIHRlbXB1cyBjb252YWxsaXMgcXVpcyBhYyBsZWN0dXMuPGJyPgpEb25lYyBzb2xsaWNpdHVkaW4gbW9sZXN0aWUgbWFsZXN1YWRhLiBOdWxsYSBxdWlzIGxvcmVtIHV0IGxpYmVybyBtYWxlc3VhZGEgZmV1Z2lhdC48L3A+PGRpdiBjbGFzcz0ic3BhY2VyCiAgICAgc3BhY2VyLXhzCiAgICAiPjwvZGl2Pjxocj48ZGl2IGNsYXNzPSJzcGFjZXIKICAgICBzcGFjZXIteHMKICAgICI+PC9kaXY+PGgyPkhvdyBkbyB5b3UgcmVhY2ggbmV3IGxpbWl0cz88L2gyPjxkaXYgY2xhc3M9InNwYWNlcgogICAgIHNwYWNlci1tZAogICAgIj48L2Rpdj48ZGl2IGNsYXNzPSJyb3ciPjxkaXYgY2xhc3M9ImNvbC1zbS0xMiBjb2wtbWQtNiI+PHAgY2xhc3M9Imljb24tcm91bmRlZCI+PHNwYW4gY2xhc3M9Imljb24gZmEgZmEtY3Jvc3NoYWlycyIgYXJpYS1oaWRkZW49InRydWUiPjwvc3Bhbj48L3A+PGgzPlNldCB5b3VyIGdvYWxzPC9oMz48cD5DdXJhYml0dXIgbm9uIG51bGxhIHNpdCBhbWV0IG5pc2wgdGVtcHVzIGNvbnZhbGxpcyBxdWlzIGFjIGxlY3R1cy48L3A+PC9kaXY+PGRpdiBjbGFzcz0iY29sLXNtLTEyIGNvbC1tZC02Ij48cCBjbGFzcz0iaWNvbi1yb3VuZGVkIj48c3BhbiBjbGFzcz0iaWNvbiBmYSBmYS10aHVtYi10YWNrIiBhcmlhLWhpZGRlbj0idHJ1ZSI+PC9zcGFuPjwvcD48aDM+QmVsaWV2ZSBpbiB5b3Vyc2VsZjwvaDM+PHA+Q3VyYWJpdHVyIG5vbiBudWxsYSBzaXQgYW1ldCBuaXNsIHRlbXB1cyBjb252YWxsaXMgcXVpcyBhYyBsZWN0dXMuPC9wPjwvZGl2PjxkaXYgY2xhc3M9ImNvbC1zbS0xMiBjb2wtbWQtNiI+PHAgY2xhc3M9Imljb24tcm91bmRlZCI+PHNwYW4gY2xhc3M9Imljb24gZmEgZmEtY2FsZW5kYXIiIGFyaWEtaGlkZGVuPSJ0cnVlIj48L3NwYW4+PC9wPjxoMz5TY2hlZHVsZSBpdDwvaDM+PHA+Q3VyYWJpdHVyIG5vbiBudWxsYSBzaXQgYW1ldCBuaXNsIHRlbXB1cyBjb252YWxsaXMgcXVpcyBhYyBsZWN0dXMuPC9wPjwvZGl2PjxkaXYgY2xhc3M9ImNvbC1zbS0xMiBjb2wtbWQtNiI+PHAgY2xhc3M9Imljb24tcm91bmRlZCI+PHNwYW4gY2xhc3M9Imljb24gZmEgZmEtcm9ja2V0IiBhcmlhLWhpZGRlbj0idHJ1ZSI+PC9zcGFuPjwvcD48aDM+TGF1bmNoIGl0PC9oMz48cD5DdXJhYml0dXIgbm9uIG51bGxhIHNpdCBhbWV0IG5pc2wgdGVtcHVzIGNvbnZhbGxpcyBxdWlzIGFjIGxlY3R1cy48L3A+PC9kaXY+PC9kaXY+PC9kaXY+PGRpdiBjbGFzcz0ic3BhY2VyCiAgICAgc3BhY2VyLW1kCiAgICAiPgo8L2Rpdj4KCjxkaXYgY2xhc3M9InNlY3Rpb24tY3lhbiB0ZXh0LWNlbnRlciI+PGgyPldlIGZseSB5b3UgdG8gbmV3IGxpbWl0czwvaDI+PGgzPkJ1aWxkIFlvdXIgTWlzc2lvbjwvaDM+PHA+TG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQsIGl1cyBpbmFuaSB2ZXJlYXIgdXQsIGV1IHByaSBub3N0cm8gdnVscHV0YXRlLiBJbiBjaG9ybyBncmFlY2UgbWVhLCB2aWRpc3NlIG1vbGVzdGllIG1laSBlYTwvcD48aDM+TWFpbnRhaW4gWW91ciBQcm9qZWN0PC9oMz48cD5Mb3JlbSBpcHN1bSBkb2xvciBzaXQgYW1ldCwgaXVzIGluYW5pIHZlcmVhciB1dCwgZXUgcHJpIG5vc3RybyB2dWxwdXRhdGUuIEluIGNob3JvIGdyYWVjZSBtZWEsIHZpZGlzc2UgbW9sZXN0aWUgbWVpIGVhPC9wPjxoMz5Zb3UgTWFrZSBJdCBIYXBwZW48L2gzPjxwPkxvcmVtIGlwc3VtIGRvbG9yIHNpdCBhbWV0LCBpdXMgaW5hbmkgdmVyZWFyIHV0LCBldSBwcmkgbm9zdHJvIHZ1bHB1dGF0ZS4gSW4gY2hvcm8gZ3JhZWNlIG1lYSwgdmlkaXNzZSBtb2xlc3RpZSBtZWkgZWE8L3A+PC9kaXY+cQSFgXEFfXEGYlUHc2VraXphaXEHfXEIKGgDWAMAAABjc3NxCYWBcQp9cQtiXWgDWAIAAABqc3EMhYFxDX1xDmJddXUu	2015-05-22 13:23:21+02
:1:cms-render_placeholder:9.en	gAJ9cQEoVQdjb250ZW50cQJjZGphbmdvLnV0aWxzLnNhZmVzdHJpbmcKU2FmZVRleHQKcQNYagAAADxwPsKpIERpdmlvIEFsZHJ5biBMdGQuIEFsbCByaWdodHMgcmVzZXJ2ZWQuIEFsZHJ5buKEoiBpcyBhIHJlZ2lzdGVyZWQgdHJhZGVtYXJrIG9mIERpdmlvIEFsZHJ5biBMdGQuPC9wPgpxBIWBcQV9cQZiVQdzZWtpemFpcQd9cQgoaANYAwAAAGNzc3EJhYFxCn1xC2JdaANYAgAAAGpzcQyFgXENfXEOYl11dS4=	2015-05-22 13:23:21+02
:1:cms-render_placeholder:11.en	gAJ9cQEoVQdjb250ZW50cQJjZGphbmdvLnV0aWxzLnNhZmVzdHJpbmcKU2FmZVRleHQKcQNYAgEAADxwPlRoZSBBbGRyeW4gZVhwbG9yZXIgVGhlbWUgYW5kIGl0cyBjb250ZW50IGlzIGxpY2Vuc2VkIHVuZGVyIGHCoAoKPGEgaHJlZj0iaHR0cDovL2NyZWF0aXZlY29tbW9ucy5vcmcvbGljZW5zZXMvYnkvNC4wLyIKICAgY2xhc3M9IgogICAgICAgIAogICAgICAgICAgICAKICAgICAgICAKICAgICAgICAiCiAgICA+TGluay9CdXR0b24gLSBDcmVhdGl2ZSBDb21tb25zIEF0dHJpYnV0aW9uIDQuMCBJbnRlcm5hdGlvbmFsIExpY2Vuc2U8L2E+Ci48L3A+CnEEhYFxBX1xBmJVB3Nla2l6YWlxB31xCChoA1gDAAAAY3NzcQmFgXEKfXELYl1oA1gCAAAAanNxDIWBcQ19cQ5iXXV1Lg==	2015-05-22 13:23:21+02
\.


--
-- Data for Name: django_select2_keymap; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_select2_keymap (id, key, value, accessed_on) FROM stdin;
\.


--
-- Name: django_select2_keymap_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_select2_keymap_id_seq', 1, false);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
0zx8uqlzkdr2q8awlcv8k72i0hlbs1dk	YTBkZjNkZDQ1N2UzOWY3NWRhZGQ0NjExOTUwYTI1MjhhNGFiZTA2Nzp7InNoYXJpbmdfdG9rZW4iOiJhNmFjNjYwMDg1ZWQ5ZTVmNDljZDJmYzQzNTk1OTE4NzM0MDcxZDI3NmQzNzEzM2Y5NmY0NDI4NTk5MzkyODI0In0=	2015-06-05 10:17:57.285653+02
huho8r69cnw7oow3d8quao4r6b73u14v	YTBkZjNkZDQ1N2UzOWY3NWRhZGQ0NjExOTUwYTI1MjhhNGFiZTA2Nzp7InNoYXJpbmdfdG9rZW4iOiJhNmFjNjYwMDg1ZWQ5ZTVmNDljZDJmYzQzNTk1OTE4NzM0MDcxZDI3NmQzNzEzM2Y5NmY0NDI4NTk5MzkyODI0In0=	2015-06-05 10:21:43.371229+02
2l79glpwxgkl5rd0dakmzlmaspopflxw	OTJjYjZiZDdkZjYwNGJlMzQ1MGY4NTM5MTk0Yzg0MjJhMGQ5NmE5Zjp7ImNtc19hZG1pbl9zaXRlIjoxLCJfYXV0aF91c2VyX2lkIjoxLCJjbXNfdG9vbGJhcl9kaXNhYmxlZCI6ZmFsc2UsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2FsZHJ5bl91c2VyIjp0cnVlLCJjbXNfZWRpdCI6ZmFsc2UsImZpbGVyX2xhc3RfZm9sZGVyX2lkIjoiMiIsIl9zZXNzaW9uX2V4cGlyeSI6ODY0MDB9	2015-05-23 13:06:08.595173+02
m3075ze4vx09qar5w3090yu5nqgwosrw	YTBkZjNkZDQ1N2UzOWY3NWRhZGQ0NjExOTUwYTI1MjhhNGFiZTA2Nzp7InNoYXJpbmdfdG9rZW4iOiJhNmFjNjYwMDg1ZWQ5ZTVmNDljZDJmYzQzNTk1OTE4NzM0MDcxZDI3NmQzNzEzM2Y5NmY0NDI4NTk5MzkyODI0In0=	2015-06-05 13:10:35.0497+02
amn41txp6m5how6dzjv8497wsjd0594h	OTE0NWRjNmZjZGZkOWU2YWI1YTg1ZmQyMTBhMTkwMzhhN2Y1MjMzMTp7Il9zZXNzaW9uX2V4cGlyeSI6ODY0MDAsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MSwiX2FsZHJ5bl91c2VyIjp0cnVlfQ==	2015-05-23 13:22:20.819891+02
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_site (id, domain, name) FROM stdin;
1	example.com	example.com
\.


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_site_id_seq', 1, true);


--
-- Data for Name: djangocms_googlemap_googlemap; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY djangocms_googlemap_googlemap (cmsplugin_ptr_id, title, address, zipcode, city, content, zoom, lat, lng, route_planer_title, route_planer, width, height, info_window, scrollwheel, double_click_zoom, draggable, keyboard_shortcuts, pan_control, zoom_control, street_view_control) FROM stdin;
\.


--
-- Data for Name: djangocms_link_link; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY djangocms_link_link (cmsplugin_ptr_id, name, url, page_link_id, mailto, target, phone, anchor) FROM stdin;
\.


--
-- Data for Name: djangocms_snippet_snippet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY djangocms_snippet_snippet (id, name, html, template) FROM stdin;
\.


--
-- Name: djangocms_snippet_snippet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('djangocms_snippet_snippet_id_seq', 1, false);


--
-- Data for Name: djangocms_snippet_snippetptr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY djangocms_snippet_snippetptr (cmsplugin_ptr_id, snippet_id) FROM stdin;
\.


--
-- Data for Name: djangocms_text_ckeditor_text; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY djangocms_text_ckeditor_text (cmsplugin_ptr_id, body) FROM stdin;
7	<h1>Explore your limits</h1>\n\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\nDonec sollicitudin molestie malesuada.<br>\nNulla quis lorem ut libero malesuada feugiat.</p>\n
9	<p>© Divio Aldryn Ltd. All rights reserved. Aldryn™ is a registered trademark of Divio Aldryn Ltd.</p>\n
10	<p>The Aldryn eXplorer Theme and its content is licensed under a <img alt="Link/Button" style="line-height: 28.7999992370605px;" id="plugin_obj_11" src="http://xplorer-standardsite-minimalistic-stage.us-iad-rs.aldryn.io/static/cms/img/icons/plugins/link.png" title="Link/Button - Link/Button - Creative Commons Attribution 4.0 International License">.</p>\n
15	<h1>The Next Giant Leap For Mankind</h1>\n\n<p class="lead">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\n
16	<hr>
18	<h2>How do you reach new limits?</h2>\n
25	<p class="icon-rounded"><img alt="Icon" id="plugin_obj_26" title="Icon - fa-crosshairs"></p>\n\n<h3>Set your goals</h3>\n\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\n
27	<p class="icon-rounded"><img alt="Icon" id="plugin_obj_28" title="Icon - fa-thumb-tack"></p>\n\n<h3>Believe in yourself</h3>\n\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\n
29	<p class="icon-rounded"><img alt="Icon" id="plugin_obj_30" title="Icon - fa-calendar"></p>\n\n<h3>Schedule it</h3>\n\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\n
31	<p class="icon-rounded"><img alt="Icon" id="plugin_obj_32" title="Icon - fa-rocket"></p>\n\n<h3>Launch it</h3>\n\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\n
35	<h2>We fly you to new limits</h2>\n\n<h3>Build Your Mission</h3>\n\n<p>Lorem ipsum dolor sit amet, ius inani verear ut, eu pri nostro vulputate. In choro graece mea, vidisse molestie mei ea</p>\n\n<h3>Maintain Your Project</h3>\n\n<p>Lorem ipsum dolor sit amet, ius inani verear ut, eu pri nostro vulputate. In choro graece mea, vidisse molestie mei ea</p>\n\n<h3>You Make It Happen</h3>\n\n<p>Lorem ipsum dolor sit amet, ius inani verear ut, eu pri nostro vulputate. In choro graece mea, vidisse molestie mei ea</p>\n
36	<h1>Take The Next Step</h1>\n\n<p class="lead">There are many variations of passages of Lorem Ipsum available.<br>\nBut the majority have suffered alteration in some form.<br>\nBy injected humour, or randomised words which don't look even slightly believable.</p>\n
48	<h3>2001<br>\nEverything started</h3>\n\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\n
51	<h3>2007<br>\nWe embraced Django</h3>\n\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
65	<p>© Divio Aldryn Ltd. All rights reserved. Aldryn™ is a registered trademark of Divio Aldryn Ltd.</p>\n
66	<p>The Aldryn eXplorer Theme and its content is licensed under a <img alt="Link/Button - Link/Button - Creative Commons Attribution 4.0 International License" id="plugin_obj_67" title="Link/Button - Link/Button - Creative Commons Attribution 4.0 International License">.</p>\n
70	<h3>2001<br>\nEverything started</h3>\n\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\n
42	<h3>2020<br>\nNext milestone…</h3>\n\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
89	<h1>Take The Next Step</h1>\n\n<p class="lead">There are many variations of passages of Lorem Ipsum available.<br>\nBut the majority have suffered alteration in some form.<br>\nBy injected humour, or randomised words which don't look even slightly believable.</p>\n
93	<h3>2020<br>\nNext milestone…</h3>\n\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
96	<h3>2001<br>\nEverything started</h3>\n\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\n
99	<h3>2007<br>\nWe embraced Django</h3>\n\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
102	<h3>2001<br>\nEverything started</h3>\n\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\n
110	<h1>Explore your limits</h1>\n\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\nDonec sollicitudin molestie malesuada.<br>\nNulla quis lorem ut libero malesuada feugiat.</p>\n
114	<h1>The Next Giant Leap For Mankind</h1>\n\n<p class="lead">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\n
115	<hr>
116	<h2>How do you reach new limits?</h2>\n
120	<p class="icon-rounded"><img alt="Icon - fa-crosshairs" id="plugin_obj_121" title="Icon - fa-crosshairs"></p>\n\n<h3>Set your goals</h3>\n\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\n
123	<p class="icon-rounded"><img alt="Icon - fa-thumb-tack" id="plugin_obj_124" title="Icon - fa-thumb-tack"></p>\n\n<h3>Believe in yourself</h3>\n\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\n
126	<p class="icon-rounded"><img alt="Icon - fa-calendar" id="plugin_obj_127" title="Icon - fa-calendar"></p>\n\n<h3>Schedule it</h3>\n\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\n
129	<p class="icon-rounded"><img alt="Icon - fa-rocket" id="plugin_obj_130" title="Icon - fa-rocket"></p>\n\n<h3>Launch it</h3>\n\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\n
134	<h2>We fly you to new limits</h2>\n\n<h3>Build Your Mission</h3>\n\n<p>Lorem ipsum dolor sit amet, ius inani verear ut, eu pri nostro vulputate. In choro graece mea, vidisse molestie mei ea</p>\n\n<h3>Maintain Your Project</h3>\n\n<p>Lorem ipsum dolor sit amet, ius inani verear ut, eu pri nostro vulputate. In choro graece mea, vidisse molestie mei ea</p>\n\n<h3>You Make It Happen</h3>\n\n<p>Lorem ipsum dolor sit amet, ius inani verear ut, eu pri nostro vulputate. In choro graece mea, vidisse molestie mei ea</p>\n
140	<h1>This is a Content page</h1>\n\n<p class="lead">There are many variations of passages of Lorem Ipsum available.<br>\nBut the majority have suffered alteration in some form.<br>\nBy injected humour, or randomised words which don't look even slightly believable.</p>\n
\.


--
-- Data for Name: easy_thumbnails_source; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY easy_thumbnails_source (id, name, modified, storage_hash) FROM stdin;
1	filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg	2015-05-22 10:57:08.881078+02	7a10d30e2c28de472f94a9478890f28d
2	filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg	2015-05-22 11:19:41.906151+02	7a10d30e2c28de472f94a9478890f28d
3	filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg	2015-05-22 11:19:42.070239+02	7a10d30e2c28de472f94a9478890f28d
4	filer_public/e7/b4/e7b4fae2-1e3b-484c-b1a9-24d62c7aa6b3/timeline_3.jpg	2015-05-22 11:19:51.790244+02	7a10d30e2c28de472f94a9478890f28d
5	filer_public/51/1b/511b2f7a-2e29-486a-a8ba-dabe4915687f/timeline_4.jpg	2015-05-22 11:19:52.405723+02	7a10d30e2c28de472f94a9478890f28d
\.


--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('easy_thumbnails_source_id_seq', 5, true);


--
-- Data for Name: easy_thumbnails_thumbnail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY easy_thumbnails_thumbnail (id, name, modified, source_id, storage_hash) FROM stdin;
1	filer_public_thumbnails/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg__32x32_q90_crop_subsampling-2_upscale.jpg	2015-05-22 10:57:11.082132+02	1	7a10d30e2c28de472f94a9478890f28d
2	filer_public_thumbnails/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg__64x64_q90_crop_subsampling-2_upscale.jpg	2015-05-22 10:57:13.239414+02	1	7a10d30e2c28de472f94a9478890f28d
3	filer_public_thumbnails/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg__48x48_q90_crop_subsampling-2_upscale.jpg	2015-05-22 10:57:15.388511+02	1	7a10d30e2c28de472f94a9478890f28d
4	filer_public_thumbnails/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg__16x16_q90_crop_subsampling-2_upscale.jpg	2015-05-22 10:57:17.539247+02	1	7a10d30e2c28de472f94a9478890f28d
5	filer_public_thumbnails/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg__1170x0_q90_subsampling-2_upscale.jpg	2015-05-22 10:57:35.60629+02	1	7a10d30e2c28de472f94a9478890f28d
6	filer_public_thumbnails/filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg__32x32_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:19:43.970985+02	2	7a10d30e2c28de472f94a9478890f28d
7	filer_public_thumbnails/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg__32x32_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:19:44.147258+02	3	7a10d30e2c28de472f94a9478890f28d
8	filer_public_thumbnails/filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg__64x64_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:19:46.044244+02	2	7a10d30e2c28de472f94a9478890f28d
9	filer_public_thumbnails/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg__64x64_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:19:46.213392+02	3	7a10d30e2c28de472f94a9478890f28d
10	filer_public_thumbnails/filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg__48x48_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:19:48.101948+02	2	7a10d30e2c28de472f94a9478890f28d
11	filer_public_thumbnails/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg__48x48_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:19:48.277506+02	3	7a10d30e2c28de472f94a9478890f28d
12	filer_public_thumbnails/filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg__16x16_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:19:50.163696+02	2	7a10d30e2c28de472f94a9478890f28d
13	filer_public_thumbnails/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg__16x16_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:19:50.36026+02	3	7a10d30e2c28de472f94a9478890f28d
14	filer_public_thumbnails/filer_public/e7/b4/e7b4fae2-1e3b-484c-b1a9-24d62c7aa6b3/timeline_3.jpg__32x32_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:19:53.942712+02	4	7a10d30e2c28de472f94a9478890f28d
15	filer_public_thumbnails/filer_public/51/1b/511b2f7a-2e29-486a-a8ba-dabe4915687f/timeline_4.jpg__32x32_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:19:54.50783+02	5	7a10d30e2c28de472f94a9478890f28d
16	filer_public_thumbnails/filer_public/e7/b4/e7b4fae2-1e3b-484c-b1a9-24d62c7aa6b3/timeline_3.jpg__64x64_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:19:56.027888+02	4	7a10d30e2c28de472f94a9478890f28d
17	filer_public_thumbnails/filer_public/51/1b/511b2f7a-2e29-486a-a8ba-dabe4915687f/timeline_4.jpg__64x64_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:19:56.584474+02	5	7a10d30e2c28de472f94a9478890f28d
18	filer_public_thumbnails/filer_public/e7/b4/e7b4fae2-1e3b-484c-b1a9-24d62c7aa6b3/timeline_3.jpg__48x48_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:19:58.120779+02	4	7a10d30e2c28de472f94a9478890f28d
19	filer_public_thumbnails/filer_public/e7/b4/e7b4fae2-1e3b-484c-b1a9-24d62c7aa6b3/timeline_3.jpg__16x16_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:20:00.190843+02	4	7a10d30e2c28de472f94a9478890f28d
20	filer_public_thumbnails/filer_public/51/1b/511b2f7a-2e29-486a-a8ba-dabe4915687f/timeline_4.jpg__48x48_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:20:03.688141+02	5	7a10d30e2c28de472f94a9478890f28d
21	filer_public_thumbnails/filer_public/51/1b/511b2f7a-2e29-486a-a8ba-dabe4915687f/timeline_4.jpg__16x16_q90_crop_subsampling-2_upscale.jpg	2015-05-22 11:20:05.765436+02	5	7a10d30e2c28de472f94a9478890f28d
22	filer_public_thumbnails/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg__1170x0_q90_subsampling-2_upscale.jpg	2015-05-22 12:54:33.012126+02	3	7a10d30e2c28de472f94a9478890f28d
23	filer_public_thumbnails/filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg__1170x0_q90_subsampling-2_upscale.jpg	2015-05-22 12:56:02.960501+02	2	7a10d30e2c28de472f94a9478890f28d
24	filer_public_thumbnails/filer_public/e7/b4/e7b4fae2-1e3b-484c-b1a9-24d62c7aa6b3/timeline_3.jpg__1170x0_q90_subsampling-2_upscale.jpg	2015-05-22 12:59:00.758389+02	4	7a10d30e2c28de472f94a9478890f28d
25	filer_public_thumbnails/filer_public/51/1b/511b2f7a-2e29-486a-a8ba-dabe4915687f/timeline_4.jpg__1170x0_q90_subsampling-2_upscale.jpg	2015-05-22 12:59:03.16101+02	5	7a10d30e2c28de472f94a9478890f28d
\.


--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('easy_thumbnails_thumbnail_id_seq', 25, true);


--
-- Data for Name: easy_thumbnails_thumbnaildimensions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY easy_thumbnails_thumbnaildimensions (id, thumbnail_id, width, height) FROM stdin;
1	1	32	32
2	2	64	64
3	3	48	48
4	4	16	16
5	5	1170	490
6	6	32	32
7	7	32	32
8	8	64	64
9	9	64	64
10	10	48	48
11	11	48	48
12	12	16	16
13	13	16	16
14	14	32	32
15	15	32	32
16	16	64	64
17	17	64	64
18	18	48	48
19	19	16	16
20	20	48	48
21	21	16	16
22	22	1170	1170
23	23	1170	1170
24	24	1170	1170
25	25	1170	1170
\.


--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('easy_thumbnails_thumbnaildimensions_id_seq', 25, true);


--
-- Data for Name: filer_clipboard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY filer_clipboard (id, user_id) FROM stdin;
1	1
\.


--
-- Name: filer_clipboard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('filer_clipboard_id_seq', 1, true);


--
-- Data for Name: filer_clipboarditem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY filer_clipboarditem (id, file_id, clipboard_id) FROM stdin;
\.


--
-- Name: filer_clipboarditem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('filer_clipboarditem_id_seq', 5, true);


--
-- Data for Name: filer_file; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY filer_file (id, folder_id, file, _file_size, has_all_mandatory_data, original_filename, name, owner_id, uploaded_at, modified_at, description, is_public, sha1, polymorphic_ctype_id) FROM stdin;
1	1	filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg	252876	f	feature-default.jpg		1	2015-05-22 10:57:08.888008+02	2015-05-22 10:57:18.549627+02	\N	t	d2c0fedfb34ceaaeb4318307b895be45e2f1c509	32
2	2	filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg	13696	f	timeline_2.jpg		1	2015-05-22 11:19:41.911266+02	2015-05-22 12:54:19.300854+02	\N	t	122faaf22e0ba1b6189722ae088dbed8025cdf81	32
3	2	filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg	32623	f	timeline_1.jpg		1	2015-05-22 11:19:42.075715+02	2015-05-22 12:54:19.317527+02	\N	t	8105a7b693f569a87d5d0be160e8e15424e591de	32
4	2	filer_public/e7/b4/e7b4fae2-1e3b-484c-b1a9-24d62c7aa6b3/timeline_3.jpg	30434	f	timeline_3.jpg		1	2015-05-22 11:19:51.796084+02	2015-05-22 12:54:19.345671+02	\N	t	661b0b7d12e4c52591da0264e1a0c24f29504e01	32
5	2	filer_public/51/1b/511b2f7a-2e29-486a-a8ba-dabe4915687f/timeline_4.jpg	17446	f	timeline_4.jpg		1	2015-05-22 11:19:52.41092+02	2015-05-22 12:54:19.35948+02	\N	t	1c99f548b6889a57fec00d3b3ca5d21a3fcc7f52	32
\.


--
-- Name: filer_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('filer_file_id_seq', 5, true);


--
-- Data for Name: filer_folder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY filer_folder (id, parent_id, name, owner_id, uploaded_at, created_at, modified_at, lft, rght, tree_id, level) FROM stdin;
1	\N	visuals	1	2015-05-22 10:56:41.399158+02	2015-05-22 10:56:41.399182+02	2015-05-22 10:56:41.399196+02	1	2	1	0
2	\N	timeline	1	2015-05-22 11:19:30.923278+02	2015-05-22 11:19:30.923303+02	2015-05-22 11:19:30.923317+02	1	2	2	0
\.


--
-- Name: filer_folder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('filer_folder_id_seq', 2, true);


--
-- Data for Name: filer_folderpermission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY filer_folderpermission (id, folder_id, type, user_id, group_id, everybody, can_edit, can_read, can_add_children) FROM stdin;
\.


--
-- Name: filer_folderpermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('filer_folderpermission_id_seq', 1, false);


--
-- Data for Name: filer_image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY filer_image (file_ptr_id, _height, _width, date_taken, default_alt_text, default_caption, author, must_always_publish_author_credit, must_always_publish_copyright, subject_location) FROM stdin;
1	570	1360	2015-05-22 10:57:07.130559+02	\N	\N	\N	f	f	\N
2	184	184	2015-05-22 11:19:40.274969+02	\N	\N	\N	f	f	\N
3	184	184	2015-05-22 11:19:40.401736+02	\N	\N	\N	f	f	\N
4	184	184	2015-05-22 11:19:50.221094+02	\N	\N	\N	f	f	\N
5	184	184	2015-05-22 11:19:50.856178+02	\N	\N	\N	f	f	\N
\.


--
-- Data for Name: health_check_db_testmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY health_check_db_testmodel (id, title) FROM stdin;
\.


--
-- Name: health_check_db_testmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('health_check_db_testmodel_id_seq', 1, false);


--
-- Data for Name: menus_cachekey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY menus_cachekey (id, language, site, key) FROM stdin;
77	en	1	menu_cache_menu_nodes_en_1_1_user
\.


--
-- Name: menus_cachekey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('menus_cachekey_id_seq', 77, true);


--
-- Data for Name: reversion_revision; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY reversion_revision (id, date_created, user_id, comment, manager_slug) FROM stdin;
1	2015-05-22 10:53:16.561099+02	1	Initial version.	default
2	2015-05-22 10:53:22.2119+02	1	Initial version.	default
3	2015-05-22 10:53:37.996133+02	1	Initial version.	default
4	2015-05-22 10:53:46.902361+02	1	Initial version.	default
5	2015-05-22 10:53:58.051071+02	1	Initial version.	default
6	2015-05-22 10:54:04.852635+02	1	Publish	default
7	2015-05-22 10:54:15.991109+02	1	Changed reverse_id and xframe_options.	default
8	2015-05-22 10:54:25.6571+02	1	Publish	default
9	2015-05-22 10:54:36.252201+02	1	Publish	default
10	2015-05-22 10:55:18.026288+02	1	Publish	default
62	2015-05-22 11:08:48.662053+02	1	Text plugin edited at position 0 in content	default
63	2015-05-22 11:09:03.431175+02	1	Text plugin added to content	default
64	2015-05-22 11:09:13.609865+02	1	Icon plugin added to content	default
65	2015-05-22 11:09:20.100665+02	1	Icon plugin edited at position 0 in content	default
66	2015-05-22 11:09:21.318239+02	1	Text plugin edited at position 0 in content	default
67	2015-05-22 11:09:38.714986+02	1	Spacer plugin added to content	default
68	2015-05-22 11:09:42.539117+02	1	Spacer plugin edited at position 21 in content	default
69	2015-05-22 11:09:53.815063+02	1	Plugins were moved	default
70	2015-05-22 11:14:41.45448+02	1	Spacer plugin edited at position 21 in content	default
71	2015-05-22 11:14:57.133591+02	1	Style plugin added to content	default
72	2015-05-22 11:15:04.081206+02	1	Style plugin edited at position 22 in content	default
73	2015-05-22 11:15:21.625258+02	1	Text plugin added to content	default
74	2015-05-22 11:15:26.505941+02	1	Text plugin edited at position 0 in content	default
75	2015-05-22 11:15:42.342787+02	1	Style plugin edited at position 22 in content	default
88	2015-05-22 11:18:20.250402+02	1	Image plugin added to content	default
89	2015-05-22 12:54:29.668342+02	1	Image plugin edited at position 0 in content	default
90	2015-05-22 12:55:01.47176+02	1	Text plugin added to content	default
91	2015-05-22 12:55:05.643403+02	1	Text plugin edited at position 1 in content	default
92	2015-05-22 12:55:18.884073+02	1	List Group plugin edited at position 3 in content	default
93	2015-05-22 12:55:39.316256+02	1	Copied plugins to content	default
94	2015-05-22 12:55:44.810866+02	1	Copied plugins to content	default
95	2015-05-22 12:55:59.469517+02	1	Image plugin edited at position 0 in content	default
96	2015-05-22 12:56:25.941737+02	1	Text plugin edited at position 1 in content	default
97	2015-05-22 12:56:49.930976+02	1	Text plugin edited at position 1 in content	default
98	2015-05-22 12:57:11.800263+02	1	Publish	default
99	2015-05-22 12:57:30.945901+02	1	Copied plugins to content	default
100	2015-05-22 12:58:13.417103+02	1	Text plugin edited at position 1 in content	default
101	2015-05-22 12:58:20.610614+02	1	Publish	default
102	2015-05-22 12:58:38.610688+02	1	Image plugin edited at position 0 in content	default
103	2015-05-22 12:58:57.296356+02	1	Image plugin edited at position 0 in content	default
104	2015-05-22 12:59:10.899007+02	1	Publish	default
105	2015-05-22 12:59:30.307755+02	1	Publish	default
106	2015-05-22 13:00:27.956605+02	1	Changed redirect and xframe_options.	default
107	2015-05-22 13:00:40.255221+02	1	Changed redirect and xframe_options.	default
108	2015-05-22 13:00:45.645837+02	1	Publish	default
109	2015-05-22 13:00:51.63618+02	1	Publish	default
110	2015-05-22 13:03:07.501653+02	1	Initial version.	default
111	2015-05-22 13:03:20.367076+02	1	Style plugin added to content	default
112	2015-05-22 13:03:27.110006+02	1	Style plugin edited at position 0 in content	default
113	2015-05-22 13:03:35.24842+02	1	Text plugin added to content	default
114	2015-05-22 13:03:39.312182+02	1	Text plugin edited at position 0 in content	default
115	2015-05-22 13:03:46.755192+02	1	Style plugin added to content	default
116	2015-05-22 13:04:58.128712+02	1	Style plugin at position 2 in content was deleted.	default
117	2015-05-22 13:05:09.163901+02	1	Spacer plugin added to content	default
118	2015-05-22 13:05:12.419752+02	1	Spacer plugin edited at position 2 in content	default
119	2015-05-22 13:05:46.725892+02	1	Initial version.	default
\.


--
-- Name: reversion_revision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('reversion_revision_id_seq', 119, true);


--
-- Data for Name: reversion_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY reversion_version (id, revision_id, object_id, content_type_id, format, serialized_data, object_repr, object_id_int) FROM stdin;
1	1	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [2, 3], "changed_date": "2015-05-22T10:53:16.456", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
2	1	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
3	1	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
4	1	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
5	2	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": false, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
6	2	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T10:53:22.124", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": null, "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
7	2	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
8	2	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
9	3	4	19	json	[{"pk": 4, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Footer", "has_url_overwrite": false, "redirect": null, "page": 4, "published": false, "path": "footer", "creation_date": "2015-05-22T10:53:37.900", "slug": "footer"}}]	Footer (footer, en)	4
10	3	4	11	json	[{"pk": 4, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0004", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [12, 13], "changed_date": "2015-05-22T10:53:37.907", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": null, "creation_date": "2015-05-22T10:53:37.817", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Footer	4
11	3	13	13	json	[{"pk": 13, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	13
12	3	12	13	json	[{"pk": 12, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	12
13	4	15	13	json	[{"pk": 15, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	15
14	4	5	11	json	[{"pk": 5, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "00040001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": null, "publication_end_date": null, "template": "INHERIT", "placeholders": [14, 15], "changed_date": "2015-05-22T10:53:46.804", "limit_visibility_in_menu": null, "parent": 4, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": null, "creation_date": "2015-05-22T10:53:46.745", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 2, "revision_id": 0}}]	Impressum	5
15	4	14	13	json	[{"pk": 14, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	14
16	4	5	19	json	[{"pk": 5, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Impressum", "has_url_overwrite": false, "redirect": null, "page": 5, "published": false, "path": "footer/impressum", "creation_date": "2015-05-22T10:53:46.838", "slug": "impressum"}}]	Impressum (impressum, en)	5
17	5	16	13	json	[{"pk": 16, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	16
18	5	17	13	json	[{"pk": 17, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	17
19	5	6	19	json	[{"pk": 6, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Terms", "has_url_overwrite": false, "redirect": null, "page": 6, "published": false, "path": "footer/terms", "creation_date": "2015-05-22T10:53:57.996", "slug": "terms"}}]	Terms (terms, en)	6
20	5	6	11	json	[{"pk": 6, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "00040002", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": null, "publication_end_date": null, "template": "INHERIT", "placeholders": [16, 17], "changed_date": "2015-05-22T10:53:57.962", "limit_visibility_in_menu": null, "parent": 4, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": null, "creation_date": "2015-05-22T10:53:57.911", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 2, "revision_id": 0}}]	Terms	6
21	6	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2468	89	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2951	105	28	35	json	[{"pk": 28, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-thumb-tack"}}]	fa-thumb-tack	28
22	6	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T10:54:04.737", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
23	6	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
24	6	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
25	7	4	19	json	[{"pk": 4, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Footer", "has_url_overwrite": false, "redirect": "", "page": 4, "published": false, "path": "footer", "creation_date": "2015-05-22T10:53:37.900", "slug": "footer"}}]	Footer (footer, en)	4
26	7	4	11	json	[{"pk": 4, "model": "cms.page", "fields": {"navigation_extenders": "", "site": 1, "application_namespace": null, "path": "0005", "in_navigation": true, "reverse_id": "footer", "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [12, 13], "changed_date": "2015-05-22T10:54:15.886", "limit_visibility_in_menu": null, "parent": null, "numchild": 2, "soft_root": false, "is_home": false, "publication_date": null, "creation_date": "2015-05-22T10:53:37.817", "application_urls": "", "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Footer	4
27	7	13	13	json	[{"pk": 13, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	13
28	7	12	13	json	[{"pk": 12, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	12
29	8	5	19	json	[{"pk": 5, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Impressum", "has_url_overwrite": false, "redirect": null, "page": 5, "published": true, "path": "footer/impressum", "creation_date": "2015-05-22T10:53:46.838", "slug": "impressum"}}]	Impressum (impressum, en)	5
30	8	5	11	json	[{"pk": 5, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "00050001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [14, 15], "changed_date": "2015-05-22T10:54:25.608", "limit_visibility_in_menu": null, "parent": 4, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:20.596", "creation_date": "2015-05-22T10:53:46.745", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 2, "revision_id": 0}}]	Impressum	5
31	8	14	13	json	[{"pk": 14, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	14
32	8	15	13	json	[{"pk": 15, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	15
33	9	4	11	json	[{"pk": 4, "model": "cms.page", "fields": {"navigation_extenders": "", "site": 1, "application_namespace": null, "path": "0005", "in_navigation": false, "reverse_id": "footer", "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [12, 13], "changed_date": "2015-05-22T10:54:35.955", "limit_visibility_in_menu": null, "parent": null, "numchild": 2, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:35.664", "creation_date": "2015-05-22T10:53:37.817", "application_urls": "", "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Footer	4
34	9	12	13	json	[{"pk": 12, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	12
35	9	13	13	json	[{"pk": 13, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	13
36	9	4	19	json	[{"pk": 4, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Footer", "has_url_overwrite": false, "redirect": "", "page": 4, "published": true, "path": "footer", "creation_date": "2015-05-22T10:53:37.900", "slug": "footer"}}]	Footer (footer, en)	4
37	10	16	13	json	[{"pk": 16, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	16
38	10	17	13	json	[{"pk": 17, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	17
39	10	6	19	json	[{"pk": 6, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Terms", "has_url_overwrite": false, "redirect": null, "page": 6, "published": true, "path": "footer/terms", "creation_date": "2015-05-22T10:53:57.996", "slug": "terms"}}]	Terms (terms, en)	6
40	10	6	11	json	[{"pk": 6, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "00050002", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [16, 17], "changed_date": "2015-05-22T10:55:17.962", "limit_visibility_in_menu": null, "parent": 4, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:55:17.729", "creation_date": "2015-05-22T10:53:57.911", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 2, "revision_id": 0}}]	Terms	6
2466	89	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T11:18:20.262", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2467	89	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2561	94	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2469	89	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2470	89	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2471	89	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2472	89	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	41
2473	89	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": true, "classes": "list-timeline"}}]	1 items	39
2474	89	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 1, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2475	89	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2476	89	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:54:29.563", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2477	89	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2478	89	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2479	89	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2480	89	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:42.704", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2481	89	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2482	90	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T12:54:29.681", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2483	90	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2484	90	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2485	90	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2486	90	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2487	90	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2488	90	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	41
2489	90	42	14	json	[{"pk": 42, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:01.426", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00010002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	42	42
2490	90	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": true, "classes": "list-timeline"}}]	1 items	39
2491	90	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 2, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2492	90	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2562	94	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2493	90	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:54:29.563", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2494	90	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2495	90	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2496	90	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2497	90	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:42.704", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2498	90	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2517	92	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T12:55:05.655", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2518	92	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2519	92	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2520	92	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2521	92	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2499	91	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T12:55:01.483", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2500	91	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2501	91	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2502	91	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2503	91	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2504	91	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2505	91	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	41
2506	91	42	64	json	[{"pk": 42, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	42
2507	91	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": true, "classes": "list-timeline"}}]	1 items	39
2508	91	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 2, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2509	91	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
1703	66	20	45	json	[{"pk": 20, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	4 columns	20
2510	91	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:54:29.563", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2511	91	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2512	91	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2513	91	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2514	91	42	14	json	[{"pk": 42, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:05.557", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00010002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	42	42
2515	91	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:42.704", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2516	91	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2522	92	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2523	92	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	41
2524	92	42	64	json	[{"pk": 42, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	42
2525	92	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": false, "classes": "list-timeline"}}]	1 items	39
2526	92	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 2, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2527	92	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2528	92	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:54:29.563", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2529	92	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2530	92	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2531	92	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2532	92	42	14	json	[{"pk": 42, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:05.557", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00010002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	42	42
2533	92	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:18.808", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2534	92	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2535	93	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T12:55:18.897", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2536	93	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2537	93	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2538	93	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2539	93	46	50	json	[{"pk": 46, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		46
2608	95	49	50	json	[{"pk": 49, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		49
2540	93	47	39	json	[{"pk": 47, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	47
2541	93	48	14	json	[{"pk": 48, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.228", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00020002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	48	48
2542	93	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2543	93	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2544	93	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2545	93	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": false, "classes": "list-timeline"}}]	2 items	39
2546	93	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2547	93	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	41
2548	93	42	64	json	[{"pk": 42, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	42
2549	93	46	14	json	[{"pk": 46, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.214", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:39.162", "depth": 2, "position": null, "path": "000C0002", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	46	46
2550	93	47	14	json	[{"pk": 47, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.186", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00020001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	47	47
2551	93	48	64	json	[{"pk": 48, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	48
2552	93	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2553	93	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2554	93	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2555	93	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:18.808", "language": "en", "parent": null, "numchild": 2, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2556	93	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 2, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2557	93	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:54:29.563", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2558	93	42	14	json	[{"pk": 42, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:05.557", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00010002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	42	42
2559	94	51	64	json	[{"pk": 51, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	51
2560	94	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T12:55:39.329", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2563	94	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2564	94	46	50	json	[{"pk": 46, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		46
2565	94	47	14	json	[{"pk": 47, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.186", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00020001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	47	47
2566	94	48	14	json	[{"pk": 48, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.228", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00020002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	48	48
2567	94	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2568	94	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2569	94	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2570	94	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": false, "classes": "list-timeline"}}]	3 items	39
2571	94	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2572	94	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	41
2573	94	42	64	json	[{"pk": 42, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	42
2574	94	50	14	json	[{"pk": 50, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:44.645", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00030001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	50	50
2575	94	46	14	json	[{"pk": 46, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.214", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:39.162", "depth": 2, "position": null, "path": "000C0002", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	46	46
2576	94	47	39	json	[{"pk": 47, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	47
2577	94	48	64	json	[{"pk": 48, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	48
2578	94	49	50	json	[{"pk": 49, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		49
2579	94	50	39	json	[{"pk": 50, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	50
2580	94	51	14	json	[{"pk": 51, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:44.695", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00030002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	51	51
2581	94	49	14	json	[{"pk": 49, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:44.678", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:44.617", "depth": 2, "position": null, "path": "000C0003", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	49	49
2582	94	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2583	94	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2584	94	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2585	94	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:18.808", "language": "en", "parent": null, "numchild": 3, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2586	94	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 2, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2587	94	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:54:29.563", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2588	94	42	14	json	[{"pk": 42, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:05.557", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00010002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	42	42
2589	95	51	64	json	[{"pk": 51, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	51
2590	95	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T12:55:44.824", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2591	95	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2592	95	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2593	95	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2594	95	46	50	json	[{"pk": 46, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		46
2595	95	47	14	json	[{"pk": 47, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.186", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00020001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	47	47
2596	95	48	14	json	[{"pk": 48, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.228", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00020002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	48	48
2597	95	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2598	95	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2599	95	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2600	95	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": false, "classes": "list-timeline"}}]	3 items	39
2601	95	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2602	95	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	41
2603	95	42	64	json	[{"pk": 42, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	42
2604	95	50	14	json	[{"pk": 50, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:59.352", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00030001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	50	50
2605	95	46	14	json	[{"pk": 46, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.214", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:39.162", "depth": 2, "position": null, "path": "000C0002", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	46	46
2606	95	47	39	json	[{"pk": 47, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	47
2607	95	48	64	json	[{"pk": 48, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	48
2609	95	50	39	json	[{"pk": 50, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 2, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg)	50
2610	95	51	14	json	[{"pk": 51, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:44.695", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00030002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	51	51
2611	95	49	14	json	[{"pk": 49, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:44.678", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:44.617", "depth": 2, "position": null, "path": "000C0003", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	49	49
2612	95	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2613	95	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2614	95	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2615	95	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:18.808", "language": "en", "parent": null, "numchild": 3, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2616	95	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 2, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2617	95	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:54:29.563", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2618	95	42	14	json	[{"pk": 42, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:05.557", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00010002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	42	42
2619	96	51	64	json	[{"pk": 51, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2007<br>\\nWe embraced Django</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2007 We embraced...	51
2620	96	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T12:55:59.484", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2621	96	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2622	96	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2623	96	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2624	96	46	50	json	[{"pk": 46, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		46
2625	96	47	14	json	[{"pk": 47, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.186", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00020001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	47	47
2626	96	48	14	json	[{"pk": 48, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.228", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00020002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	48	48
2627	96	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2628	96	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2629	96	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2630	96	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": false, "classes": "list-timeline"}}]	3 items	39
2631	96	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2654	97	46	50	json	[{"pk": 46, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		46
2632	96	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	41
2633	96	42	64	json	[{"pk": 42, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	42
2634	96	50	14	json	[{"pk": 50, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:59.352", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00030001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	50	50
2635	96	46	14	json	[{"pk": 46, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.214", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:39.162", "depth": 2, "position": null, "path": "000C0002", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	46	46
2636	96	47	39	json	[{"pk": 47, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	47
2637	96	48	64	json	[{"pk": 48, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	48
2638	96	49	50	json	[{"pk": 49, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		49
2639	96	50	39	json	[{"pk": 50, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 2, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg)	50
2640	96	51	14	json	[{"pk": 51, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:56:25.844", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00030002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	51	51
2641	96	49	14	json	[{"pk": 49, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:44.678", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:44.617", "depth": 2, "position": null, "path": "000C0003", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	49	49
2642	96	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2643	96	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2644	96	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2645	96	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:18.808", "language": "en", "parent": null, "numchild": 3, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2646	96	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 2, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2647	96	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:54:29.563", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2648	96	42	14	json	[{"pk": 42, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:05.557", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00010002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	42	42
2649	97	51	64	json	[{"pk": 51, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2007<br>\\nWe embraced Django</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2007 We embraced...	51
2650	97	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T12:56:25.956", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2651	97	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2652	97	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2653	97	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2655	97	47	14	json	[{"pk": 47, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.186", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00020001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	47	47
2656	97	48	14	json	[{"pk": 48, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.228", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00020002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	48	48
2657	97	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2658	97	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2659	97	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2660	97	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": false, "classes": "list-timeline"}}]	3 items	39
2661	97	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2662	97	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	41
2663	97	42	64	json	[{"pk": 42, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2015<br>\\nThe new Explorer Theme</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2015 The new...	42
2664	97	50	14	json	[{"pk": 50, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:59.352", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00030001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	50	50
2665	97	46	14	json	[{"pk": 46, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.214", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:39.162", "depth": 2, "position": null, "path": "000C0002", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	46	46
2666	97	47	39	json	[{"pk": 47, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	47
2667	97	48	64	json	[{"pk": 48, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	48
2668	97	49	50	json	[{"pk": 49, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		49
2669	97	50	39	json	[{"pk": 50, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 2, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg)	50
2670	97	51	14	json	[{"pk": 51, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:56:25.844", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00030002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	51	51
2671	97	49	14	json	[{"pk": 49, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:44.678", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:44.617", "depth": 2, "position": null, "path": "000C0003", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	49	49
2672	97	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2673	97	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2674	97	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2675	97	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:18.808", "language": "en", "parent": null, "numchild": 3, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2676	97	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 2, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2722	99	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": false, "classes": "list-timeline"}}]	4 items	39
2677	97	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:54:29.563", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2678	97	42	14	json	[{"pk": 42, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:56:49.833", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00010002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	42	42
2679	98	51	64	json	[{"pk": 51, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2007<br>\\nWe embraced Django</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2007 We embraced...	51
2680	98	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T12:57:11.562", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2681	98	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2682	98	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2683	98	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2684	98	46	50	json	[{"pk": 46, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		46
2685	98	47	14	json	[{"pk": 47, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.186", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00020001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	47	47
2686	98	48	14	json	[{"pk": 48, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.228", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00020002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	48	48
2687	98	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2688	98	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2689	98	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2690	98	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": false, "classes": "list-timeline"}}]	3 items	39
2691	98	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2692	98	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	41
2693	98	42	64	json	[{"pk": 42, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2015<br>\\nThe new Explorer Theme</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2015 The new...	42
2694	98	50	14	json	[{"pk": 50, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:59.352", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00030001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	50	50
2695	98	46	14	json	[{"pk": 46, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.214", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:39.162", "depth": 2, "position": null, "path": "000C0002", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	46	46
2696	98	47	39	json	[{"pk": 47, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	47
2697	98	48	64	json	[{"pk": 48, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	48
2698	98	49	50	json	[{"pk": 49, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		49
2723	99	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2699	98	50	39	json	[{"pk": 50, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 2, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg)	50
2700	98	51	14	json	[{"pk": 51, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:56:25.844", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00030002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	51	51
2701	98	49	14	json	[{"pk": 49, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:44.678", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:44.617", "depth": 2, "position": null, "path": "000C0003", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	49	49
2702	98	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2703	98	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2704	98	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2705	98	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:18.808", "language": "en", "parent": null, "numchild": 3, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2706	98	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 2, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2707	98	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:54:29.563", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2708	98	42	14	json	[{"pk": 42, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:56:49.833", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00010002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	42	42
2709	99	51	64	json	[{"pk": 51, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2007<br>\\nWe embraced Django</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2007 We embraced...	51
2710	99	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T12:57:11.812", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2711	99	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2712	99	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2713	99	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2714	99	46	50	json	[{"pk": 46, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		46
2715	99	68	50	json	[{"pk": 68, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		68
2716	99	47	14	json	[{"pk": 47, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.186", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00020001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	47	47
2717	99	69	39	json	[{"pk": 69, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	69
2718	99	48	14	json	[{"pk": 48, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.228", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00020002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	48	48
2719	99	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2720	99	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2721	99	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2724	99	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	41
2725	99	42	64	json	[{"pk": 42, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2015<br>\\nThe new Explorer Theme</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2015 The new...	42
2726	99	50	39	json	[{"pk": 50, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 2, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg)	50
2727	99	46	14	json	[{"pk": 46, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.214", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:39.162", "depth": 2, "position": null, "path": "000C0002", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	46	46
2728	99	47	39	json	[{"pk": 47, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	47
2729	99	48	64	json	[{"pk": 48, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	48
2730	99	49	50	json	[{"pk": 49, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		49
2731	99	50	14	json	[{"pk": 50, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:59.352", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00030001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	50	50
2732	99	51	14	json	[{"pk": 51, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:56:25.844", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00030002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	51	51
2733	99	70	64	json	[{"pk": 70, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	70
2734	99	68	14	json	[{"pk": 68, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:57:30.803", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:57:30.754", "depth": 2, "position": null, "path": "000C0004", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	68	68
2735	99	69	14	json	[{"pk": 69, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:57:30.780", "language": "en", "parent": 68, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00040001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	69	69
2736	99	70	14	json	[{"pk": 70, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:57:30.816", "language": "en", "parent": 68, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00040002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	70	70
2737	99	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2738	99	49	14	json	[{"pk": 49, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:44.678", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:44.617", "depth": 2, "position": null, "path": "000C0003", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	49	49
2739	99	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2740	99	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2741	99	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:18.808", "language": "en", "parent": null, "numchild": 4, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2742	99	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 2, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2743	99	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:54:29.563", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2744	99	42	14	json	[{"pk": 42, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:56:49.833", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00010002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	42	42
2767	100	50	14	json	[{"pk": 50, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:59.352", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00030001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	50	50
2745	100	51	64	json	[{"pk": 51, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2007<br>\\nWe embraced Django</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2007 We embraced...	51
2746	100	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T12:57:30.959", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2747	100	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2748	100	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2749	100	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2750	100	46	50	json	[{"pk": 46, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		46
2751	100	68	50	json	[{"pk": 68, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		68
2752	100	47	14	json	[{"pk": 47, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.186", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00020001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	47	47
2753	100	69	39	json	[{"pk": 69, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	69
2754	100	48	14	json	[{"pk": 48, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.228", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00020002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	48	48
2755	100	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2756	100	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2757	100	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2758	100	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": false, "classes": "list-timeline"}}]	4 items	39
2759	100	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2760	100	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	41
2761	100	42	64	json	[{"pk": 42, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2020<br>\\nNext milestone\\u2026</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2020 Next milestone…...	42
2762	100	50	39	json	[{"pk": 50, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 2, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg)	50
2763	100	46	14	json	[{"pk": 46, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.214", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:39.162", "depth": 2, "position": null, "path": "000C0002", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	46	46
2764	100	47	39	json	[{"pk": 47, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	47
2765	100	48	64	json	[{"pk": 48, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	48
2766	100	49	50	json	[{"pk": 49, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		49
2902	104	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": false, "classes": "list-timeline"}}]	4 items	39
2768	100	51	14	json	[{"pk": 51, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:56:25.844", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00030002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	51	51
2769	100	70	64	json	[{"pk": 70, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	70
2770	100	68	14	json	[{"pk": 68, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:57:30.803", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:57:30.754", "depth": 2, "position": null, "path": "000C0004", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	68	68
2771	100	69	14	json	[{"pk": 69, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:57:30.780", "language": "en", "parent": 68, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00040001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	69	69
2772	100	70	14	json	[{"pk": 70, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:57:30.816", "language": "en", "parent": 68, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00040002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	70	70
2773	100	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2774	100	49	14	json	[{"pk": 49, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:44.678", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:44.617", "depth": 2, "position": null, "path": "000C0003", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	49	49
2775	100	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2776	100	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2777	100	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:18.808", "language": "en", "parent": null, "numchild": 4, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2778	100	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 2, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2779	100	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:54:29.563", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2780	100	42	14	json	[{"pk": 42, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:58:13.299", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00010002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	42	42
2781	101	51	64	json	[{"pk": 51, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2007<br>\\nWe embraced Django</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2007 We embraced...	51
2782	101	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T12:58:20.368", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2783	101	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2784	101	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2785	101	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2786	101	46	50	json	[{"pk": 46, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		46
2787	101	68	50	json	[{"pk": 68, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		68
2788	101	47	14	json	[{"pk": 47, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.186", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00020001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	47	47
2789	101	69	39	json	[{"pk": 69, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	69
2790	101	48	14	json	[{"pk": 48, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.228", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00020002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	48	48
2791	101	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2792	101	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2793	101	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2794	101	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": false, "classes": "list-timeline"}}]	4 items	39
2795	101	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2796	101	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	41
2797	101	42	64	json	[{"pk": 42, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2020<br>\\nNext milestone\\u2026</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2020 Next milestone…...	42
2798	101	50	39	json	[{"pk": 50, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 2, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg)	50
2799	101	46	14	json	[{"pk": 46, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.214", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:39.162", "depth": 2, "position": null, "path": "000C0002", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	46	46
2800	101	47	39	json	[{"pk": 47, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	47
2801	101	48	64	json	[{"pk": 48, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	48
2802	101	49	50	json	[{"pk": 49, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		49
2803	101	50	14	json	[{"pk": 50, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:59.352", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00030001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	50	50
2804	101	51	14	json	[{"pk": 51, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:56:25.844", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00030002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	51	51
2805	101	70	64	json	[{"pk": 70, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	70
2806	101	68	14	json	[{"pk": 68, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:57:30.803", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:57:30.754", "depth": 2, "position": null, "path": "000C0004", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	68	68
2807	101	69	14	json	[{"pk": 69, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:57:30.780", "language": "en", "parent": 68, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00040001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	69	69
2808	101	70	14	json	[{"pk": 70, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:57:30.816", "language": "en", "parent": 68, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00040002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	70	70
2809	101	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2810	101	49	14	json	[{"pk": 49, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:44.678", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:44.617", "depth": 2, "position": null, "path": "000C0003", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	49	49
2811	101	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2812	101	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
1828	68	20	45	json	[{"pk": 20, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	4 columns	20
2813	101	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:18.808", "language": "en", "parent": null, "numchild": 4, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2814	101	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 2, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2815	101	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:54:29.563", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2816	101	42	14	json	[{"pk": 42, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:58:13.299", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00010002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	42	42
2817	102	51	64	json	[{"pk": 51, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2007<br>\\nWe embraced Django</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2007 We embraced...	51
2818	102	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T12:58:20.627", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2819	102	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2820	102	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2821	102	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2822	102	46	50	json	[{"pk": 46, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		46
2823	102	68	50	json	[{"pk": 68, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		68
2824	102	47	14	json	[{"pk": 47, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.186", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00020001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	47	47
2825	102	69	39	json	[{"pk": 69, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 4, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/e7/b4/e7b4fae2-1e3b-484c-b1a9-24d62c7aa6b3/timeline_3.jpg)	69
2826	102	48	14	json	[{"pk": 48, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.228", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00020002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	48	48
2827	102	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2828	102	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2829	102	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2830	102	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": false, "classes": "list-timeline"}}]	4 items	39
2831	102	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2832	102	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	41
2833	102	42	64	json	[{"pk": 42, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2020<br>\\nNext milestone\\u2026</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2020 Next milestone…...	42
2834	102	50	39	json	[{"pk": 50, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 2, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg)	50
2903	104	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2835	102	46	14	json	[{"pk": 46, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.214", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:39.162", "depth": 2, "position": null, "path": "000C0002", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	46	46
2836	102	47	39	json	[{"pk": 47, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	47
2837	102	48	64	json	[{"pk": 48, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	48
2838	102	49	50	json	[{"pk": 49, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		49
2839	102	50	14	json	[{"pk": 50, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:59.352", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00030001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	50	50
2840	102	51	14	json	[{"pk": 51, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:56:25.844", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00030002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	51	51
2841	102	70	64	json	[{"pk": 70, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	70
2842	102	68	14	json	[{"pk": 68, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:57:30.803", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:57:30.754", "depth": 2, "position": null, "path": "000C0004", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	68	68
2843	102	69	14	json	[{"pk": 69, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:58:38.499", "language": "en", "parent": 68, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00040001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	69	69
2844	102	70	14	json	[{"pk": 70, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:57:30.816", "language": "en", "parent": 68, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00040002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	70	70
2845	102	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2846	102	49	14	json	[{"pk": 49, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:44.678", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:44.617", "depth": 2, "position": null, "path": "000C0003", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	49	49
2847	102	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2848	102	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2849	102	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:18.808", "language": "en", "parent": null, "numchild": 4, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2850	102	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 2, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2851	102	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:54:29.563", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2852	102	42	14	json	[{"pk": 42, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:58:13.299", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00010002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	42	42
2853	103	51	64	json	[{"pk": 51, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2007<br>\\nWe embraced Django</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2007 We embraced...	51
2854	103	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T12:58:38.626", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2855	103	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2856	103	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2949	105	26	35	json	[{"pk": 26, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-crosshairs"}}]	fa-crosshairs	26
2857	103	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2858	103	46	50	json	[{"pk": 46, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		46
2859	103	68	50	json	[{"pk": 68, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		68
2860	103	47	14	json	[{"pk": 47, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.186", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00020001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	47	47
2861	103	69	39	json	[{"pk": 69, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 4, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/e7/b4/e7b4fae2-1e3b-484c-b1a9-24d62c7aa6b3/timeline_3.jpg)	69
2862	103	48	14	json	[{"pk": 48, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.228", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00020002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	48	48
2863	103	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2864	103	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2865	103	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2866	103	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": false, "classes": "list-timeline"}}]	4 items	39
2867	103	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2868	103	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 5, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/51/1b/511b2f7a-2e29-486a-a8ba-dabe4915687f/timeline_4.jpg)	41
2869	103	42	64	json	[{"pk": 42, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2020<br>\\nNext milestone\\u2026</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2020 Next milestone…...	42
2870	103	50	39	json	[{"pk": 50, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 2, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg)	50
2871	103	46	14	json	[{"pk": 46, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.214", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:39.162", "depth": 2, "position": null, "path": "000C0002", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	46	46
2872	103	47	39	json	[{"pk": 47, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	47
2873	103	48	64	json	[{"pk": 48, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	48
2874	103	49	50	json	[{"pk": 49, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		49
2875	103	50	14	json	[{"pk": 50, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:59.352", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00030001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	50	50
2876	103	51	14	json	[{"pk": 51, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:56:25.844", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00030002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	51	51
2877	103	70	64	json	[{"pk": 70, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	70
2878	103	68	14	json	[{"pk": 68, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:57:30.803", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:57:30.754", "depth": 2, "position": null, "path": "000C0004", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	68	68
1902	69	30	35	json	[{"pk": 30, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-calendar"}}]	fa-calendar	30
2879	103	69	14	json	[{"pk": 69, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:58:38.499", "language": "en", "parent": 68, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00040001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	69	69
2880	103	70	14	json	[{"pk": 70, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:57:30.816", "language": "en", "parent": 68, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00040002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	70	70
2881	103	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2882	103	49	14	json	[{"pk": 49, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:44.678", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:44.617", "depth": 2, "position": null, "path": "000C0003", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	49	49
2883	103	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2884	103	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2885	103	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:18.808", "language": "en", "parent": null, "numchild": 4, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2886	103	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 2, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2887	103	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:58:57.177", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2888	103	42	14	json	[{"pk": 42, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:58:13.299", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00010002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	42	42
2889	104	51	64	json	[{"pk": 51, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2007<br>\\nWe embraced Django</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2007 We embraced...	51
2890	104	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T12:59:10.736", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2891	104	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2892	104	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2893	104	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2894	104	46	50	json	[{"pk": 46, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		46
2895	104	68	50	json	[{"pk": 68, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		68
2896	104	47	14	json	[{"pk": 47, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.186", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00020001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	47	47
2897	104	69	39	json	[{"pk": 69, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 4, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/e7/b4/e7b4fae2-1e3b-484c-b1a9-24d62c7aa6b3/timeline_3.jpg)	69
2898	104	48	14	json	[{"pk": 48, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.228", "language": "en", "parent": 46, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00020002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	48	48
2899	104	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2900	104	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2901	104	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2904	104	41	39	json	[{"pk": 41, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 5, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/51/1b/511b2f7a-2e29-486a-a8ba-dabe4915687f/timeline_4.jpg)	41
2905	104	42	64	json	[{"pk": 42, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2020<br>\\nNext milestone\\u2026</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>"}}]	2020 Next milestone…...	42
2906	104	50	39	json	[{"pk": 50, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 2, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/94/1c/941c3dcc-336e-4ffb-9aa9-19645b892598/timeline_2.jpg)	50
2907	104	46	14	json	[{"pk": 46, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:39.214", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:39.162", "depth": 2, "position": null, "path": "000C0002", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	46	46
2908	104	47	39	json	[{"pk": 47, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 3, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/21/d9/21d9c539-b384-45ae-bbe1-ec207ea83883/timeline_1.jpg)	47
2909	104	48	64	json	[{"pk": 48, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	48
2910	104	49	50	json	[{"pk": 49, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		49
2911	104	50	14	json	[{"pk": 50, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:59.352", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00030001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	50	50
2912	104	51	14	json	[{"pk": 51, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:56:25.844", "language": "en", "parent": 49, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00030002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	51	51
2913	104	70	64	json	[{"pk": 70, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h3>2001<br>\\nEverything started</h3>\\n\\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>\\n"}}]	2001 Everything started...	70
2914	104	68	14	json	[{"pk": 68, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:57:30.803", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:57:30.754", "depth": 2, "position": null, "path": "000C0004", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	68	68
2915	104	69	14	json	[{"pk": 69, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:58:38.499", "language": "en", "parent": 68, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00040001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	69	69
2916	104	70	14	json	[{"pk": 70, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:57:30.816", "language": "en", "parent": 68, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00040002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	70	70
2917	104	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2918	104	49	14	json	[{"pk": 49, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:44.678", "language": "en", "parent": 39, "numchild": 0, "creation_date": "2015-05-22T12:55:44.617", "depth": 2, "position": null, "path": "000C0003", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	49	49
2919	104	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
2920	104	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2921	104	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:55:18.808", "language": "en", "parent": null, "numchild": 4, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2922	104	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 2, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2923	104	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:58:57.177", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2924	104	42	14	json	[{"pk": 42, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T12:58:13.299", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T12:55:01.417", "depth": 3, "position": 1, "path": "000C00010002", "placeholder": 7, "plugin_type": "TextPlugin"}}]	42	42
2950	105	27	64	json	[{"pk": 27, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_28\\" title=\\"Icon - fa-thumb-tack\\"></p>\\n\\n<h3>Believe in yourself</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Believe in yourself...	27
2925	105	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "tpl_home.html", "placeholders": [2, 3], "changed_date": "2015-05-22T12:59:30.116", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
2926	105	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
2927	105	3	14	json	[{"pk": 3, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:21.519", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:58:07.414", "depth": 1, "position": 2, "path": "0002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	3	3
2928	105	4	45	json	[{"pk": 4, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	1 column	4
2929	105	5	46	json	[{"pk": 5, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 24, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": null, "lg_pull": null, "xs_pull": null}}]	col-md-24 	5
2930	105	6	44	json	[{"pk": 6, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	6
2931	105	1	25	json	[{"pk": 1, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-visual", "padding_bottom": null, "additional_class_names": "", "label": "Visual", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Visual”: feature-visual	1
2932	105	8	25	json	[{"pk": 8, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "container", "padding_bottom": null, "additional_class_names": "", "label": "Grid", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Grid”: container	8
2933	105	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
2934	105	23	14	json	[{"pk": 23, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.089", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.085", "depth": 3, "position": 2, "path": "000500070003", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	23	23
2935	105	12	14	json	[{"pk": 12, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:03:47.125", "language": "en", "parent": null, "numchild": 8, "creation_date": "2015-05-22T11:03:41.457", "depth": 1, "position": 0, "path": "0005", "placeholder": 3, "plugin_type": "StylePlugin"}}]	12	12
2936	105	2	14	json	[{"pk": 2, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:57:32.263", "language": "en", "parent": 1, "numchild": 0, "creation_date": "2015-05-22T10:56:32.155", "depth": 2, "position": 0, "path": "00010001", "placeholder": 2, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	2	2
2937	105	14	44	json	[{"pk": 14, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	14
2938	105	15	64	json	[{"pk": 15, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>The Next Giant Leap For Mankind</h1>\\n\\n<p class=\\"lead\\">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	The Next Giant...	15
2939	105	16	64	json	[{"pk": 16, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<hr>"}}]		16
2940	105	24	14	json	[{"pk": 24, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.097", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.094", "depth": 3, "position": 3, "path": "000500070004", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	24	24
2941	105	18	64	json	[{"pk": 18, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>How do you reach new limits?</h2>\\n"}}]	How do you...	18
2942	105	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
2943	105	20	45	json	[{"pk": 20, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	4 columns	20
2944	105	21	46	json	[{"pk": 21, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	21
2945	105	22	46	json	[{"pk": 22, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	22
2946	105	23	46	json	[{"pk": 23, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	23
2947	105	24	46	json	[{"pk": 24, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	24
2948	105	25	64	json	[{"pk": 25, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_26\\" title=\\"Icon - fa-crosshairs\\"></p>\\n\\n<h3>Set your goals</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Set your goals...	25
2952	105	26	14	json	[{"pk": 26, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:12.797", "language": "en", "parent": 25, "numchild": 0, "creation_date": "2015-05-22T11:06:50.389", "depth": 5, "position": 0, "path": "00050007000100010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	26	26
2953	105	30	35	json	[{"pk": 30, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-calendar"}}]	fa-calendar	30
2954	105	5	14	json	[{"pk": 5, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.635", "language": "en", "parent": 4, "numchild": 2, "creation_date": "2015-05-22T10:59:10.499", "depth": 4, "position": 0, "path": "0002000200010001", "placeholder": 2, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	5	5
2955	105	32	35	json	[{"pk": 32, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-rocket"}}]	fa-rocket	32
2956	105	33	44	json	[{"pk": 33, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	33
2957	105	34	25	json	[{"pk": 34, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "section-cyan", "padding_bottom": null, "additional_class_names": "text-center", "label": "Section", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Section”: section-cyan (text-center)	34
2958	105	27	14	json	[{"pk": 27, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:12.441", "language": "en", "parent": 22, "numchild": 1, "creation_date": "2015-05-22T11:07:50.132", "depth": 4, "position": 0, "path": "0005000700020001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	27	27
2959	105	1	14	json	[{"pk": 1, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:31.719", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:56:01.162", "depth": 1, "position": 0, "path": "0001", "placeholder": 2, "plugin_type": "StylePlugin"}}]	1	1
2960	105	6	14	json	[{"pk": 6, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.638", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T10:59:50.854", "depth": 5, "position": 0, "path": "00020002000100010001", "placeholder": 2, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	6	6
2961	105	35	64	json	[{"pk": 35, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>We fly you to new limits</h2>\\n\\n<h3>Build Your Mission</h3>\\n\\n<p>Lorem ipsum dolor sit amet, ius inani verear ut, eu pri nostro vulputate. In choro graece mea, vidisse molestie mei ea</p>\\n\\n<h3>Maintain Your Project</h3>\\n\\n<p>Lorem ipsum dolor sit amet, ius inani verear ut, eu pri nostro vulputate. In choro graece mea, vidisse molestie mei ea</p>\\n\\n<h3>You Make It Happen</h3>\\n\\n<p>Lorem ipsum dolor sit amet, ius inani verear ut, eu pri nostro vulputate. In choro graece mea, vidisse molestie mei ea</p>\\n"}}]	We fly you...	35
2962	105	31	64	json	[{"pk": 31, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_32\\" title=\\"Icon - fa-rocket\\"></p>\\n\\n<h3>Launch it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Launch it Curabitur...	31
2963	105	28	14	json	[{"pk": 28, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:10.963", "language": "en", "parent": 27, "numchild": 0, "creation_date": "2015-05-22T11:08:02.785", "depth": 5, "position": 0, "path": "00050007000200010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	28	28
2964	105	7	14	json	[{"pk": 7, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.642", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T11:00:04.937", "depth": 5, "position": 1, "path": "00020002000100010002", "placeholder": 2, "plugin_type": "TextPlugin"}}]	7	7
2965	105	29	64	json	[{"pk": 29, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_30\\" title=\\"Icon - fa-calendar\\"></p>\\n\\n<h3>Schedule it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Schedule it Curabitur...	29
2966	105	8	14	json	[{"pk": 8, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:22.155", "language": "en", "parent": 3, "numchild": 1, "creation_date": "2015-05-22T11:01:16.060", "depth": 2, "position": 1, "path": "00020002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	8	8
2967	105	30	14	json	[{"pk": 30, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:46.762", "language": "en", "parent": 29, "numchild": 0, "creation_date": "2015-05-22T11:08:35.830", "depth": 5, "position": 0, "path": "00050007000300010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	30	30
2968	105	31	14	json	[{"pk": 31, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:21.189", "language": "en", "parent": 24, "numchild": 1, "creation_date": "2015-05-22T11:09:03.312", "depth": 4, "position": 0, "path": "0005000700040001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	31	31
2969	105	13	44	json	[{"pk": 13, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	13
2970	105	19	44	json	[{"pk": 19, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	19
2971	105	32	14	json	[{"pk": 32, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:19.976", "language": "en", "parent": 31, "numchild": 0, "creation_date": "2015-05-22T11:09:13.485", "depth": 5, "position": 0, "path": "00050007000400010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	32	32
2972	105	2	39	json	[{"pk": 2, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 1, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg)	2
2973	105	33	14	json	[{"pk": 33, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:14:41.317", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:09:38.604", "depth": 1, "position": 21, "path": "0007", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	33	33
2974	105	12	25	json	[{"pk": 12, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	12
2098	72	33	44	json	[{"pk": 33, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	33
2975	105	34	14	json	[{"pk": 34, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:15:42.211", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:14:56.992", "depth": 1, "position": 22, "path": "0008", "placeholder": 3, "plugin_type": "StylePlugin"}}]	34	34
2976	105	13	14	json	[{"pk": 13, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.655", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:01.806", "depth": 2, "position": 0, "path": "00050001", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	13	13
2977	105	22	14	json	[{"pk": 22, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.080", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.076", "depth": 3, "position": 1, "path": "000500070002", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	22	22
2978	105	35	14	json	[{"pk": 35, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:15:26.376", "language": "en", "parent": 34, "numchild": 0, "creation_date": "2015-05-22T11:15:21.507", "depth": 2, "position": 0, "path": "00080001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	35	35
2979	105	14	14	json	[{"pk": 14, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.669", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:16.457", "depth": 2, "position": 2, "path": "00050002", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	14	14
2980	105	7	64	json	[{"pk": 7, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Explore your limits</h1>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada.<br>\\nNulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	Explore your limits...	7
2981	105	15	14	json	[{"pk": 15, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.662", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:28.907", "depth": 2, "position": 1, "path": "00050003", "placeholder": 3, "plugin_type": "TextPlugin"}}]	15	15
2982	105	3	25	json	[{"pk": 3, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-content", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: feature-content	3
2983	105	16	14	json	[{"pk": 16, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.676", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:47.410", "depth": 2, "position": 3, "path": "00050004", "placeholder": 3, "plugin_type": "TextPlugin"}}]	16	16
2984	105	17	44	json	[{"pk": 17, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	17
2985	105	17	14	json	[{"pk": 17, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.691", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:12.306", "depth": 2, "position": 4, "path": "00050008", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	17	17
2986	105	29	14	json	[{"pk": 29, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:48.535", "language": "en", "parent": 23, "numchild": 1, "creation_date": "2015-05-22T11:08:25.281", "depth": 4, "position": 0, "path": "0005000700030001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	29	29
2987	105	18	14	json	[{"pk": 18, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.683", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:30.146", "depth": 2, "position": 5, "path": "00050005", "placeholder": 3, "plugin_type": "TextPlugin"}}]	18	18
2988	105	19	14	json	[{"pk": 19, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.699", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:45.474", "depth": 2, "position": 6, "path": "00050006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	19	19
2989	105	25	14	json	[{"pk": 25, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:17.127", "language": "en", "parent": 21, "numchild": 1, "creation_date": "2015-05-22T11:06:36.687", "depth": 4, "position": 0, "path": "0005000700010001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	25	25
2990	105	20	14	json	[{"pk": 20, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.708", "language": "en", "parent": 12, "numchild": 4, "creation_date": "2015-05-22T11:06:05.640", "depth": 2, "position": 7, "path": "00050007", "placeholder": 3, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	20	20
2991	105	4	14	json	[{"pk": 4, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.651", "language": "en", "parent": 8, "numchild": 1, "creation_date": "2015-05-22T10:58:44.225", "depth": 3, "position": 0, "path": "000200020001", "placeholder": 2, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	4	4
2992	105	21	14	json	[{"pk": 21, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.070", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.067", "depth": 3, "position": 0, "path": "000500070001", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	21	21
2993	106	15	13	json	[{"pk": 15, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	15
2994	106	5	11	json	[{"pk": 5, "model": "cms.page", "fields": {"navigation_extenders": "", "site": 1, "application_namespace": null, "path": "00050001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [14, 15], "changed_date": "2015-05-22T13:00:27.863", "limit_visibility_in_menu": null, "parent": 4, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:20.596", "creation_date": "2015-05-22T10:53:46.745", "application_urls": "", "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 2, "revision_id": 0}}]	Impressum	5
2995	106	14	13	json	[{"pk": 14, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	14
2996	106	5	19	json	[{"pk": 5, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Impressum", "has_url_overwrite": false, "redirect": "/en/about/", "page": 5, "published": true, "path": "footer/impressum", "creation_date": "2015-05-22T10:53:46.838", "slug": "impressum"}}]	Impressum (impressum, en)	5
2997	107	16	13	json	[{"pk": 16, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	16
2998	107	17	13	json	[{"pk": 17, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	17
2999	107	6	19	json	[{"pk": 6, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Terms", "has_url_overwrite": false, "redirect": "/en/about/", "page": 6, "published": true, "path": "footer/terms", "creation_date": "2015-05-22T10:53:57.996", "slug": "terms"}}]	Terms (terms, en)	6
3000	107	6	11	json	[{"pk": 6, "model": "cms.page", "fields": {"navigation_extenders": "", "site": 1, "application_namespace": null, "path": "00050002", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [16, 17], "changed_date": "2015-05-22T13:00:40.151", "limit_visibility_in_menu": null, "parent": 4, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:55:17.729", "creation_date": "2015-05-22T10:53:57.911", "application_urls": "", "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 2, "revision_id": 0}}]	Terms	6
3009	110	11	19	json	[{"pk": 11, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Content", "has_url_overwrite": false, "redirect": null, "page": 11, "published": false, "path": "content", "creation_date": "2015-05-22T13:03:07.323", "slug": "content"}}]	Content (content, en)	11
3010	110	27	13	json	[{"pk": 27, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	27
3011	110	26	13	json	[{"pk": 26, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	26
3012	110	11	11	json	[{"pk": 11, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0007", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [26, 27], "changed_date": "2015-05-22T13:03:07.329", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": null, "creation_date": "2015-05-22T13:03:07.236", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Content	11
3013	111	11	11	json	[{"pk": 11, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0007", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [26, 27], "changed_date": "2015-05-22T13:03:07.513", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": null, "creation_date": "2015-05-22T13:03:07.236", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Content	11
3014	111	11	19	json	[{"pk": 11, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Content", "has_url_overwrite": false, "redirect": null, "page": 11, "published": false, "path": "content", "creation_date": "2015-05-22T13:03:07.323", "slug": "content"}}]	Content (content, en)	11
3015	111	26	13	json	[{"pk": 26, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	26
3016	111	27	13	json	[{"pk": 27, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	27
3017	111	135	14	json	[{"pk": 135, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:03:20.345", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T13:03:20.341", "depth": 1, "position": 0, "path": "000R", "placeholder": 27, "plugin_type": "StylePlugin"}}]	135	135
3024	113	11	19	json	[{"pk": 11, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Content", "has_url_overwrite": false, "redirect": null, "page": 11, "published": false, "path": "content", "creation_date": "2015-05-22T13:03:07.323", "slug": "content"}}]	Content (content, en)	11
3025	113	135	25	json	[{"pk": 135, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	135
3026	113	136	14	json	[{"pk": 136, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:03:35.223", "language": "en", "parent": 135, "numchild": 0, "creation_date": "2015-05-22T13:03:35.217", "depth": 2, "position": 0, "path": "000R0001", "placeholder": 27, "plugin_type": "TextPlugin"}}]	136	136
3001	108	5	19	json	[{"pk": 5, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Impressum", "has_url_overwrite": false, "redirect": "/en/about/", "page": 5, "published": true, "path": "footer/impressum", "creation_date": "2015-05-22T10:53:46.838", "slug": "impressum"}}]	Impressum (impressum, en)	5
3002	108	5	11	json	[{"pk": 5, "model": "cms.page", "fields": {"navigation_extenders": "", "site": 1, "application_namespace": null, "path": "00050001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [14, 15], "changed_date": "2015-05-22T13:00:45.584", "limit_visibility_in_menu": null, "parent": 4, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:20.596", "creation_date": "2015-05-22T10:53:46.745", "application_urls": "", "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 2, "revision_id": 0}}]	Impressum	5
3003	108	14	13	json	[{"pk": 14, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	14
3004	108	15	13	json	[{"pk": 15, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	15
3018	112	11	19	json	[{"pk": 11, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Content", "has_url_overwrite": false, "redirect": null, "page": 11, "published": false, "path": "content", "creation_date": "2015-05-22T13:03:07.323", "slug": "content"}}]	Content (content, en)	11
3019	112	135	25	json	[{"pk": 135, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	135
3061	117	136	14	json	[{"pk": 136, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:03:39.264", "language": "en", "parent": 135, "numchild": 0, "creation_date": "2015-05-22T13:03:35.217", "depth": 2, "position": 0, "path": "000R0001", "placeholder": 27, "plugin_type": "TextPlugin"}}]	136	136
3020	112	11	11	json	[{"pk": 11, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0007", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [26, 27], "changed_date": "2015-05-22T13:03:20.378", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": null, "creation_date": "2015-05-22T13:03:07.236", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Content	11
3021	112	26	13	json	[{"pk": 26, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	26
3022	112	27	13	json	[{"pk": 27, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	27
3023	112	135	14	json	[{"pk": 135, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:03:27.064", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T13:03:20.341", "depth": 1, "position": 0, "path": "000R", "placeholder": 27, "plugin_type": "StylePlugin"}}]	135	135
3027	113	11	11	json	[{"pk": 11, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0007", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [26, 27], "changed_date": "2015-05-22T13:03:27.121", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": null, "creation_date": "2015-05-22T13:03:07.236", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Content	11
3028	113	26	13	json	[{"pk": 26, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	26
3029	113	27	13	json	[{"pk": 27, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	27
3030	113	135	14	json	[{"pk": 135, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:03:27.064", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T13:03:20.341", "depth": 1, "position": 0, "path": "000R", "placeholder": 27, "plugin_type": "StylePlugin"}}]	135	135
3005	109	16	13	json	[{"pk": 16, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	16
3006	109	17	13	json	[{"pk": 17, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	17
3007	109	6	19	json	[{"pk": 6, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Terms", "has_url_overwrite": false, "redirect": "/en/about/", "page": 6, "published": true, "path": "footer/terms", "creation_date": "2015-05-22T10:53:57.996", "slug": "terms"}}]	Terms (terms, en)	6
3008	109	6	11	json	[{"pk": 6, "model": "cms.page", "fields": {"navigation_extenders": "", "site": 1, "application_namespace": null, "path": "00050002", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [16, 17], "changed_date": "2015-05-22T13:00:51.575", "limit_visibility_in_menu": null, "parent": 4, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:55:17.729", "creation_date": "2015-05-22T10:53:57.911", "application_urls": "", "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 2, "revision_id": 0}}]	Terms	6
3031	114	11	19	json	[{"pk": 11, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Content", "has_url_overwrite": false, "redirect": null, "page": 11, "published": false, "path": "content", "creation_date": "2015-05-22T13:03:07.323", "slug": "content"}}]	Content (content, en)	11
3032	114	135	14	json	[{"pk": 135, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:03:27.064", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T13:03:20.341", "depth": 1, "position": 0, "path": "000R", "placeholder": 27, "plugin_type": "StylePlugin"}}]	135	135
3033	114	136	64	json	[{"pk": 136, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>This is a Content page</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	This is a...	136
3034	114	11	11	json	[{"pk": 11, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0007", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [26, 27], "changed_date": "2015-05-22T13:03:35.259", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": null, "creation_date": "2015-05-22T13:03:07.236", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Content	11
3035	114	136	14	json	[{"pk": 136, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:03:39.264", "language": "en", "parent": 135, "numchild": 0, "creation_date": "2015-05-22T13:03:35.217", "depth": 2, "position": 0, "path": "000R0001", "placeholder": 27, "plugin_type": "TextPlugin"}}]	136	136
3036	114	26	13	json	[{"pk": 26, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	26
3037	114	27	13	json	[{"pk": 27, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	27
3038	114	135	25	json	[{"pk": 135, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	135
3039	115	11	19	json	[{"pk": 11, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Content", "has_url_overwrite": false, "redirect": null, "page": 11, "published": false, "path": "content", "creation_date": "2015-05-22T13:03:07.323", "slug": "content"}}]	Content (content, en)	11
3040	115	135	14	json	[{"pk": 135, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:03:27.064", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T13:03:20.341", "depth": 1, "position": 0, "path": "000R", "placeholder": 27, "plugin_type": "StylePlugin"}}]	135	135
3062	117	26	13	json	[{"pk": 26, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	26
3041	115	136	64	json	[{"pk": 136, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>This is a Content page</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	This is a...	136
3042	115	137	14	json	[{"pk": 137, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:03:46.728", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T13:03:46.724", "depth": 1, "position": 2, "path": "000S", "placeholder": 27, "plugin_type": "StylePlugin"}}]	137	137
3043	115	11	11	json	[{"pk": 11, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0007", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [26, 27], "changed_date": "2015-05-22T13:03:39.323", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": null, "creation_date": "2015-05-22T13:03:07.236", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Content	11
3044	115	136	14	json	[{"pk": 136, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:03:39.264", "language": "en", "parent": 135, "numchild": 0, "creation_date": "2015-05-22T13:03:35.217", "depth": 2, "position": 0, "path": "000R0001", "placeholder": 27, "plugin_type": "TextPlugin"}}]	136	136
3045	115	26	13	json	[{"pk": 26, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	26
3046	115	27	13	json	[{"pk": 27, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	27
3047	115	135	25	json	[{"pk": 135, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	135
3048	116	11	19	json	[{"pk": 11, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Content", "has_url_overwrite": false, "redirect": null, "page": 11, "published": false, "path": "content", "creation_date": "2015-05-22T13:03:07.323", "slug": "content"}}]	Content (content, en)	11
3049	116	135	14	json	[{"pk": 135, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:03:27.064", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T13:03:20.341", "depth": 1, "position": 0, "path": "000R", "placeholder": 27, "plugin_type": "StylePlugin"}}]	135	135
3050	116	136	64	json	[{"pk": 136, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>This is a Content page</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	This is a...	136
3051	116	11	11	json	[{"pk": 11, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0007", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [26, 27], "changed_date": "2015-05-22T13:04:58.021", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": null, "creation_date": "2015-05-22T13:03:07.236", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Content	11
3052	116	136	14	json	[{"pk": 136, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:03:39.264", "language": "en", "parent": 135, "numchild": 0, "creation_date": "2015-05-22T13:03:35.217", "depth": 2, "position": 0, "path": "000R0001", "placeholder": 27, "plugin_type": "TextPlugin"}}]	136	136
3053	116	26	13	json	[{"pk": 26, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	26
3054	116	27	13	json	[{"pk": 27, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	27
3055	116	135	25	json	[{"pk": 135, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	135
3056	117	11	19	json	[{"pk": 11, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Content", "has_url_overwrite": false, "redirect": null, "page": 11, "published": false, "path": "content", "creation_date": "2015-05-22T13:03:07.323", "slug": "content"}}]	Content (content, en)	11
3057	117	135	14	json	[{"pk": 135, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:03:27.064", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T13:03:20.341", "depth": 1, "position": 0, "path": "000R", "placeholder": 27, "plugin_type": "StylePlugin"}}]	135	135
3058	117	136	64	json	[{"pk": 136, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>This is a Content page</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	This is a...	136
3059	117	138	14	json	[{"pk": 138, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:05:09.137", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T13:05:09.132", "depth": 1, "position": 2, "path": "000S", "placeholder": 27, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	138	138
3060	117	11	11	json	[{"pk": 11, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0007", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [26, 27], "changed_date": "2015-05-22T13:04:58.143", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": null, "creation_date": "2015-05-22T13:03:07.236", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Content	11
3063	117	27	13	json	[{"pk": 27, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	27
2218	74	20	45	json	[{"pk": 20, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	4 columns	20
3064	117	135	25	json	[{"pk": 135, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	135
3065	118	11	19	json	[{"pk": 11, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Content", "has_url_overwrite": false, "redirect": null, "page": 11, "published": false, "path": "content", "creation_date": "2015-05-22T13:03:07.323", "slug": "content"}}]	Content (content, en)	11
3066	118	135	14	json	[{"pk": 135, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:03:27.064", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T13:03:20.341", "depth": 1, "position": 0, "path": "000R", "placeholder": 27, "plugin_type": "StylePlugin"}}]	135	135
3067	118	136	64	json	[{"pk": 136, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>This is a Content page</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	This is a...	136
3068	118	138	44	json	[{"pk": 138, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	138
3069	118	11	11	json	[{"pk": 11, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0007", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [26, 27], "changed_date": "2015-05-22T13:05:09.175", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": null, "creation_date": "2015-05-22T13:03:07.236", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Content	11
3070	118	136	14	json	[{"pk": 136, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:03:39.264", "language": "en", "parent": 135, "numchild": 0, "creation_date": "2015-05-22T13:03:35.217", "depth": 2, "position": 0, "path": "000R0001", "placeholder": 27, "plugin_type": "TextPlugin"}}]	136	136
3071	118	26	13	json	[{"pk": 26, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	26
3072	118	27	13	json	[{"pk": 27, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	27
3073	118	135	25	json	[{"pk": 135, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	135
3074	118	138	14	json	[{"pk": 138, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:05:12.367", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T13:05:09.132", "depth": 1, "position": 2, "path": "000S", "placeholder": 27, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	138	138
3075	119	139	25	json	[{"pk": 139, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	139
3076	119	140	64	json	[{"pk": 140, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>This is a Content page</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	This is a...	140
3077	119	139	14	json	[{"pk": 139, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:05:46.617", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T13:03:20.341", "depth": 1, "position": 0, "path": "000T", "placeholder": 31, "plugin_type": "StylePlugin"}}]	139	139
3078	119	140	14	json	[{"pk": 140, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:05:46.650", "language": "en", "parent": 139, "numchild": 0, "creation_date": "2015-05-22T13:03:35.217", "depth": 2, "position": 0, "path": "000T0001", "placeholder": 31, "plugin_type": "TextPlugin"}}]	140	140
3079	119	13	11	json	[{"pk": 13, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "00080001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": null, "publication_end_date": null, "template": "INHERIT", "placeholders": [30, 31], "changed_date": "2015-05-22T13:05:46.521", "limit_visibility_in_menu": null, "parent": 12, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": null, "creation_date": "2015-05-22T13:05:46.465", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 2, "revision_id": 0}}]	Content	13
3080	119	141	14	json	[{"pk": 141, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T13:05:46.641", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T13:05:09.132", "depth": 1, "position": 2, "path": "000U", "placeholder": 31, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	141	141
3081	119	141	44	json	[{"pk": 141, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	141
3082	119	13	19	json	[{"pk": 13, "model": "cms.title", "fields": {"menu_title": null, "meta_description": null, "page_title": null, "language": "en", "title": "Content", "has_url_overwrite": false, "redirect": null, "page": 13, "published": false, "path": "page_types/content", "creation_date": "2015-05-22T13:05:46.655", "slug": "content"}}]	Content (content, en)	13
3083	119	30	13	json	[{"pk": 30, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	30
3084	119	31	13	json	[{"pk": 31, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	31
1629	65	6	44	json	[{"pk": 6, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	6
1701	66	18	64	json	[{"pk": 18, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>How do you reach new limits?</h2>\\n"}}]	How do you...	18
1702	66	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
1447	62	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "tpl_home.html", "placeholders": [2, 3], "changed_date": "2015-05-22T11:08:47.011", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
1448	62	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
1449	62	3	14	json	[{"pk": 3, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:21.519", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:58:07.414", "depth": 1, "position": 2, "path": "0002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	3	3
1450	62	4	45	json	[{"pk": 4, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	1 column	4
1451	62	5	46	json	[{"pk": 5, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 24, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": null, "lg_pull": null, "xs_pull": null}}]	col-md-24 	5
1452	62	6	44	json	[{"pk": 6, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	6
1453	62	1	25	json	[{"pk": 1, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-visual", "padding_bottom": null, "additional_class_names": "", "label": "Visual", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Visual”: feature-visual	1
1454	62	8	25	json	[{"pk": 8, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "container", "padding_bottom": null, "additional_class_names": "", "label": "Grid", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Grid”: container	8
1455	62	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
1456	62	23	14	json	[{"pk": 23, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.089", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.085", "depth": 3, "position": 2, "path": "000500070003", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	23	23
1457	62	12	14	json	[{"pk": 12, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:03:47.125", "language": "en", "parent": null, "numchild": 7, "creation_date": "2015-05-22T11:03:41.457", "depth": 1, "position": 0, "path": "0005", "placeholder": 3, "plugin_type": "StylePlugin"}}]	12	12
1458	62	2	14	json	[{"pk": 2, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:57:32.263", "language": "en", "parent": 1, "numchild": 0, "creation_date": "2015-05-22T10:56:32.155", "depth": 2, "position": 0, "path": "00010001", "placeholder": 2, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	2	2
1459	62	14	44	json	[{"pk": 14, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	14
1460	62	15	64	json	[{"pk": 15, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>The Next Giant Leap For Mankind</h1>\\n\\n<p class=\\"lead\\">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	The Next Giant...	15
1461	62	16	64	json	[{"pk": 16, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<hr>"}}]		16
1462	62	24	14	json	[{"pk": 24, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.097", "language": "en", "parent": 20, "numchild": 0, "creation_date": "2015-05-22T11:06:23.094", "depth": 3, "position": 3, "path": "000500070004", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	24	24
1463	62	18	64	json	[{"pk": 18, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>How do you reach new limits?</h2>\\n"}}]	How do you...	18
1464	62	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
1465	62	20	45	json	[{"pk": 20, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	4 columns	20
1466	62	21	46	json	[{"pk": 21, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	21
1727	66	19	44	json	[{"pk": 19, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	19
1467	62	22	46	json	[{"pk": 22, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	22
1468	62	23	46	json	[{"pk": 23, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	23
1469	62	24	46	json	[{"pk": 24, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	24
2145	73	14	44	json	[{"pk": 14, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	14
1470	62	25	64	json	[{"pk": 25, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_26\\" title=\\"Icon - fa-crosshairs\\"></p>\\n\\n<h3>Set your goals</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Set your goals...	25
1471	62	26	35	json	[{"pk": 26, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-crosshairs"}}]	fa-crosshairs	26
1472	62	27	64	json	[{"pk": 27, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_28\\" title=\\"Icon - fa-thumb-tack\\"></p>\\n\\n<h3>Believe in yourself</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Believe in yourself...	27
1473	62	28	35	json	[{"pk": 28, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-thumb-tack"}}]	fa-thumb-tack	28
1474	62	26	14	json	[{"pk": 26, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:12.797", "language": "en", "parent": 25, "numchild": 0, "creation_date": "2015-05-22T11:06:50.389", "depth": 5, "position": 0, "path": "00050007000100010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	26	26
1475	62	30	35	json	[{"pk": 30, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-calendar"}}]	fa-calendar	30
1476	62	5	14	json	[{"pk": 5, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.635", "language": "en", "parent": 4, "numchild": 2, "creation_date": "2015-05-22T10:59:10.499", "depth": 4, "position": 0, "path": "0002000200010001", "placeholder": 2, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	5	5
1477	62	27	14	json	[{"pk": 27, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:12.441", "language": "en", "parent": 22, "numchild": 1, "creation_date": "2015-05-22T11:07:50.132", "depth": 4, "position": 0, "path": "0005000700020001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	27	27
1478	62	1	14	json	[{"pk": 1, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:31.719", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:56:01.162", "depth": 1, "position": 0, "path": "0001", "placeholder": 2, "plugin_type": "StylePlugin"}}]	1	1
1479	62	6	14	json	[{"pk": 6, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.638", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T10:59:50.854", "depth": 5, "position": 0, "path": "00020002000100010001", "placeholder": 2, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	6	6
1480	62	28	14	json	[{"pk": 28, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:10.963", "language": "en", "parent": 27, "numchild": 0, "creation_date": "2015-05-22T11:08:02.785", "depth": 5, "position": 0, "path": "00050007000200010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	28	28
1481	62	7	14	json	[{"pk": 7, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.642", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T11:00:04.937", "depth": 5, "position": 1, "path": "00020002000100010002", "placeholder": 2, "plugin_type": "TextPlugin"}}]	7	7
1482	62	29	64	json	[{"pk": 29, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_30\\" title=\\"Icon - fa-calendar\\"></p>\\n\\n<h3>Schedule it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Schedule it Curabitur...	29
1483	62	8	14	json	[{"pk": 8, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:22.155", "language": "en", "parent": 3, "numchild": 1, "creation_date": "2015-05-22T11:01:16.060", "depth": 2, "position": 1, "path": "00020002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	8	8
1484	62	30	14	json	[{"pk": 30, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:46.762", "language": "en", "parent": 29, "numchild": 0, "creation_date": "2015-05-22T11:08:35.830", "depth": 5, "position": 0, "path": "00050007000300010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	30	30
1485	62	13	44	json	[{"pk": 13, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	13
1486	62	19	44	json	[{"pk": 19, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	19
1487	62	2	39	json	[{"pk": 2, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 1, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg)	2
1488	62	12	25	json	[{"pk": 12, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	12
1489	62	13	14	json	[{"pk": 13, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.850", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:01.806", "depth": 2, "position": 0, "path": "00050001", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	13	13
1490	62	22	14	json	[{"pk": 22, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.080", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.076", "depth": 3, "position": 1, "path": "000500070002", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	22	22
1491	62	14	14	json	[{"pk": 14, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.856", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:16.457", "depth": 2, "position": 2, "path": "00050002", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	14	14
1492	62	7	64	json	[{"pk": 7, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Explore your limits</h1>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada.<br>\\nNulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	Explore your limits...	7
1493	62	15	14	json	[{"pk": 15, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.863", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:28.907", "depth": 2, "position": 1, "path": "00050003", "placeholder": 3, "plugin_type": "TextPlugin"}}]	15	15
1494	62	3	25	json	[{"pk": 3, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-content", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: feature-content	3
1495	62	16	14	json	[{"pk": 16, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.869", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:47.410", "depth": 2, "position": 3, "path": "00050004", "placeholder": 3, "plugin_type": "TextPlugin"}}]	16	16
1496	62	17	44	json	[{"pk": 17, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	17
1497	62	17	14	json	[{"pk": 17, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:15.334", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:05:12.306", "depth": 1, "position": 5, "path": "0006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	17	17
1498	62	29	14	json	[{"pk": 29, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:48.535", "language": "en", "parent": 23, "numchild": 1, "creation_date": "2015-05-22T11:08:25.281", "depth": 4, "position": 0, "path": "0005000700030001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	29	29
1499	62	18	14	json	[{"pk": 18, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:33.733", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:30.146", "depth": 2, "position": 4, "path": "00050005", "placeholder": 3, "plugin_type": "TextPlugin"}}]	18	18
1500	62	19	14	json	[{"pk": 19, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:51.317", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:45.474", "depth": 2, "position": 5, "path": "00050006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	19	19
1501	62	25	14	json	[{"pk": 25, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:17.127", "language": "en", "parent": 21, "numchild": 1, "creation_date": "2015-05-22T11:06:36.687", "depth": 4, "position": 0, "path": "0005000700010001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	25	25
1502	62	20	14	json	[{"pk": 20, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.061", "language": "en", "parent": 12, "numchild": 4, "creation_date": "2015-05-22T11:06:05.640", "depth": 2, "position": 6, "path": "00050007", "placeholder": 3, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	20	20
1503	62	4	14	json	[{"pk": 4, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.651", "language": "en", "parent": 8, "numchild": 1, "creation_date": "2015-05-22T10:58:44.225", "depth": 3, "position": 0, "path": "000200020001", "placeholder": 2, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	4	4
1504	62	21	14	json	[{"pk": 21, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.070", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.067", "depth": 3, "position": 0, "path": "000500070001", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	21	21
1505	63	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "tpl_home.html", "placeholders": [2, 3], "changed_date": "2015-05-22T11:08:48.726", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
1506	63	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
1507	63	3	14	json	[{"pk": 3, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:21.519", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:58:07.414", "depth": 1, "position": 2, "path": "0002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	3	3
1508	63	4	45	json	[{"pk": 4, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	1 column	4
1509	63	5	46	json	[{"pk": 5, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 24, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": null, "lg_pull": null, "xs_pull": null}}]	col-md-24 	5
1510	63	6	44	json	[{"pk": 6, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	6
1511	63	1	25	json	[{"pk": 1, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-visual", "padding_bottom": null, "additional_class_names": "", "label": "Visual", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Visual”: feature-visual	1
1892	69	20	45	json	[{"pk": 20, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	4 columns	20
1512	63	8	25	json	[{"pk": 8, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "container", "padding_bottom": null, "additional_class_names": "", "label": "Grid", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Grid”: container	8
1513	63	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
1514	63	23	14	json	[{"pk": 23, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.089", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.085", "depth": 3, "position": 2, "path": "000500070003", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	23	23
1515	63	12	14	json	[{"pk": 12, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:03:47.125", "language": "en", "parent": null, "numchild": 7, "creation_date": "2015-05-22T11:03:41.457", "depth": 1, "position": 0, "path": "0005", "placeholder": 3, "plugin_type": "StylePlugin"}}]	12	12
1516	63	2	14	json	[{"pk": 2, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:57:32.263", "language": "en", "parent": 1, "numchild": 0, "creation_date": "2015-05-22T10:56:32.155", "depth": 2, "position": 0, "path": "00010001", "placeholder": 2, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	2	2
1517	63	14	44	json	[{"pk": 14, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	14
1518	63	15	64	json	[{"pk": 15, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>The Next Giant Leap For Mankind</h1>\\n\\n<p class=\\"lead\\">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	The Next Giant...	15
1519	63	16	64	json	[{"pk": 16, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<hr>"}}]		16
1520	63	24	14	json	[{"pk": 24, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.097", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.094", "depth": 3, "position": 3, "path": "000500070004", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	24	24
1521	63	18	64	json	[{"pk": 18, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>How do you reach new limits?</h2>\\n"}}]	How do you...	18
1522	63	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
1523	63	20	45	json	[{"pk": 20, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	4 columns	20
1524	63	21	46	json	[{"pk": 21, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	21
1525	63	22	46	json	[{"pk": 22, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	22
1526	63	23	46	json	[{"pk": 23, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	23
1527	63	24	46	json	[{"pk": 24, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	24
1528	63	25	64	json	[{"pk": 25, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_26\\" title=\\"Icon - fa-crosshairs\\"></p>\\n\\n<h3>Set your goals</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Set your goals...	25
1529	63	26	35	json	[{"pk": 26, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-crosshairs"}}]	fa-crosshairs	26
1530	63	27	64	json	[{"pk": 27, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_28\\" title=\\"Icon - fa-thumb-tack\\"></p>\\n\\n<h3>Believe in yourself</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Believe in yourself...	27
1531	63	28	35	json	[{"pk": 28, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-thumb-tack"}}]	fa-thumb-tack	28
1532	63	26	14	json	[{"pk": 26, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:12.797", "language": "en", "parent": 25, "numchild": 0, "creation_date": "2015-05-22T11:06:50.389", "depth": 5, "position": 0, "path": "00050007000100010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	26	26
1533	63	30	35	json	[{"pk": 30, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-calendar"}}]	fa-calendar	30
1534	63	5	14	json	[{"pk": 5, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.635", "language": "en", "parent": 4, "numchild": 2, "creation_date": "2015-05-22T10:59:10.499", "depth": 4, "position": 0, "path": "0002000200010001", "placeholder": 2, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	5	5
1535	63	27	14	json	[{"pk": 27, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:12.441", "language": "en", "parent": 22, "numchild": 1, "creation_date": "2015-05-22T11:07:50.132", "depth": 4, "position": 0, "path": "0005000700020001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	27	27
1536	63	1	14	json	[{"pk": 1, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:31.719", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:56:01.162", "depth": 1, "position": 0, "path": "0001", "placeholder": 2, "plugin_type": "StylePlugin"}}]	1	1
1537	63	6	14	json	[{"pk": 6, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.638", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T10:59:50.854", "depth": 5, "position": 0, "path": "00020002000100010001", "placeholder": 2, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	6	6
1538	63	28	14	json	[{"pk": 28, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:10.963", "language": "en", "parent": 27, "numchild": 0, "creation_date": "2015-05-22T11:08:02.785", "depth": 5, "position": 0, "path": "00050007000200010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	28	28
1539	63	7	14	json	[{"pk": 7, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.642", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T11:00:04.937", "depth": 5, "position": 1, "path": "00020002000100010002", "placeholder": 2, "plugin_type": "TextPlugin"}}]	7	7
1540	63	29	64	json	[{"pk": 29, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_30\\" title=\\"Icon - fa-calendar\\"></p>\\n\\n<h3>Schedule it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Schedule it Curabitur...	29
1541	63	8	14	json	[{"pk": 8, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:22.155", "language": "en", "parent": 3, "numchild": 1, "creation_date": "2015-05-22T11:01:16.060", "depth": 2, "position": 1, "path": "00020002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	8	8
1542	63	30	14	json	[{"pk": 30, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:46.762", "language": "en", "parent": 29, "numchild": 0, "creation_date": "2015-05-22T11:08:35.830", "depth": 5, "position": 0, "path": "00050007000300010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	30	30
1543	63	31	14	json	[{"pk": 31, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:03.319", "language": "en", "parent": 24, "numchild": 0, "creation_date": "2015-05-22T11:09:03.312", "depth": 4, "position": 0, "path": "0005000700040001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	31	31
1544	63	13	44	json	[{"pk": 13, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	13
1545	63	19	44	json	[{"pk": 19, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	19
1546	63	2	39	json	[{"pk": 2, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 1, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg)	2
1547	63	12	25	json	[{"pk": 12, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	12
1548	63	13	14	json	[{"pk": 13, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.850", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:01.806", "depth": 2, "position": 0, "path": "00050001", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	13	13
1549	63	22	14	json	[{"pk": 22, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.080", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.076", "depth": 3, "position": 1, "path": "000500070002", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	22	22
1550	63	14	14	json	[{"pk": 14, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.856", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:16.457", "depth": 2, "position": 2, "path": "00050002", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	14	14
1551	63	7	64	json	[{"pk": 7, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Explore your limits</h1>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada.<br>\\nNulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	Explore your limits...	7
1552	63	15	14	json	[{"pk": 15, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.863", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:28.907", "depth": 2, "position": 1, "path": "00050003", "placeholder": 3, "plugin_type": "TextPlugin"}}]	15	15
1553	63	3	25	json	[{"pk": 3, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-content", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: feature-content	3
1554	63	16	14	json	[{"pk": 16, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.869", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:47.410", "depth": 2, "position": 3, "path": "00050004", "placeholder": 3, "plugin_type": "TextPlugin"}}]	16	16
1555	63	17	44	json	[{"pk": 17, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	17
1556	63	17	14	json	[{"pk": 17, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:15.334", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:05:12.306", "depth": 1, "position": 5, "path": "0006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	17	17
1557	63	29	14	json	[{"pk": 29, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:48.535", "language": "en", "parent": 23, "numchild": 1, "creation_date": "2015-05-22T11:08:25.281", "depth": 4, "position": 0, "path": "0005000700030001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	29	29
1558	63	18	14	json	[{"pk": 18, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:33.733", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:30.146", "depth": 2, "position": 4, "path": "00050005", "placeholder": 3, "plugin_type": "TextPlugin"}}]	18	18
1559	63	19	14	json	[{"pk": 19, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:51.317", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:45.474", "depth": 2, "position": 5, "path": "00050006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	19	19
1560	63	25	14	json	[{"pk": 25, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:17.127", "language": "en", "parent": 21, "numchild": 1, "creation_date": "2015-05-22T11:06:36.687", "depth": 4, "position": 0, "path": "0005000700010001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	25	25
1561	63	20	14	json	[{"pk": 20, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.061", "language": "en", "parent": 12, "numchild": 4, "creation_date": "2015-05-22T11:06:05.640", "depth": 2, "position": 6, "path": "00050007", "placeholder": 3, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	20	20
1562	63	4	14	json	[{"pk": 4, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.651", "language": "en", "parent": 8, "numchild": 1, "creation_date": "2015-05-22T10:58:44.225", "depth": 3, "position": 0, "path": "000200020001", "placeholder": 2, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	4	4
1563	63	21	14	json	[{"pk": 21, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.070", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.067", "depth": 3, "position": 0, "path": "000500070001", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	21	21
1564	64	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "tpl_home.html", "placeholders": [2, 3], "changed_date": "2015-05-22T11:09:03.491", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
1565	64	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
1566	64	3	14	json	[{"pk": 3, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:21.519", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:58:07.414", "depth": 1, "position": 2, "path": "0002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	3	3
1567	64	4	45	json	[{"pk": 4, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	1 column	4
1568	64	5	46	json	[{"pk": 5, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 24, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": null, "lg_pull": null, "xs_pull": null}}]	col-md-24 	5
1569	64	6	44	json	[{"pk": 6, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	6
1570	64	1	25	json	[{"pk": 1, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-visual", "padding_bottom": null, "additional_class_names": "", "label": "Visual", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Visual”: feature-visual	1
1571	64	8	25	json	[{"pk": 8, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "container", "padding_bottom": null, "additional_class_names": "", "label": "Grid", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Grid”: container	8
1572	64	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
1573	64	23	14	json	[{"pk": 23, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.089", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.085", "depth": 3, "position": 2, "path": "000500070003", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	23	23
1574	64	12	14	json	[{"pk": 12, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:03:47.125", "language": "en", "parent": null, "numchild": 7, "creation_date": "2015-05-22T11:03:41.457", "depth": 1, "position": 0, "path": "0005", "placeholder": 3, "plugin_type": "StylePlugin"}}]	12	12
1575	64	2	14	json	[{"pk": 2, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:57:32.263", "language": "en", "parent": 1, "numchild": 0, "creation_date": "2015-05-22T10:56:32.155", "depth": 2, "position": 0, "path": "00010001", "placeholder": 2, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	2	2
1576	64	14	44	json	[{"pk": 14, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	14
1577	64	15	64	json	[{"pk": 15, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>The Next Giant Leap For Mankind</h1>\\n\\n<p class=\\"lead\\">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	The Next Giant...	15
1578	64	16	64	json	[{"pk": 16, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<hr>"}}]		16
1579	64	24	14	json	[{"pk": 24, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.097", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.094", "depth": 3, "position": 3, "path": "000500070004", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	24	24
1580	64	18	64	json	[{"pk": 18, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>How do you reach new limits?</h2>\\n"}}]	How do you...	18
1581	64	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
1582	64	20	45	json	[{"pk": 20, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	4 columns	20
1583	64	21	46	json	[{"pk": 21, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	21
1916	69	13	44	json	[{"pk": 13, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	13
1584	64	22	46	json	[{"pk": 22, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	22
1585	64	23	46	json	[{"pk": 23, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	23
1586	64	24	46	json	[{"pk": 24, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	24
1587	64	25	64	json	[{"pk": 25, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_26\\" title=\\"Icon - fa-crosshairs\\"></p>\\n\\n<h3>Set your goals</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Set your goals...	25
1588	64	26	35	json	[{"pk": 26, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-crosshairs"}}]	fa-crosshairs	26
1589	64	27	64	json	[{"pk": 27, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_28\\" title=\\"Icon - fa-thumb-tack\\"></p>\\n\\n<h3>Believe in yourself</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Believe in yourself...	27
1590	64	28	35	json	[{"pk": 28, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-thumb-tack"}}]	fa-thumb-tack	28
1591	64	26	14	json	[{"pk": 26, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:12.797", "language": "en", "parent": 25, "numchild": 0, "creation_date": "2015-05-22T11:06:50.389", "depth": 5, "position": 0, "path": "00050007000100010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	26	26
1592	64	30	35	json	[{"pk": 30, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-calendar"}}]	fa-calendar	30
1593	64	5	14	json	[{"pk": 5, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.635", "language": "en", "parent": 4, "numchild": 2, "creation_date": "2015-05-22T10:59:10.499", "depth": 4, "position": 0, "path": "0002000200010001", "placeholder": 2, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	5	5
1594	64	32	14	json	[{"pk": 32, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:13.493", "language": "en", "parent": 31, "numchild": 0, "creation_date": "2015-05-22T11:09:13.485", "depth": 5, "position": 0, "path": "00050007000400010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	32	32
1595	64	27	14	json	[{"pk": 27, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:12.441", "language": "en", "parent": 22, "numchild": 1, "creation_date": "2015-05-22T11:07:50.132", "depth": 4, "position": 0, "path": "0005000700020001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	27	27
1596	64	1	14	json	[{"pk": 1, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:31.719", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:56:01.162", "depth": 1, "position": 0, "path": "0001", "placeholder": 2, "plugin_type": "StylePlugin"}}]	1	1
1597	64	6	14	json	[{"pk": 6, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.638", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T10:59:50.854", "depth": 5, "position": 0, "path": "00020002000100010001", "placeholder": 2, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	6	6
1598	64	28	14	json	[{"pk": 28, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:10.963", "language": "en", "parent": 27, "numchild": 0, "creation_date": "2015-05-22T11:08:02.785", "depth": 5, "position": 0, "path": "00050007000200010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	28	28
1599	64	7	14	json	[{"pk": 7, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.642", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T11:00:04.937", "depth": 5, "position": 1, "path": "00020002000100010002", "placeholder": 2, "plugin_type": "TextPlugin"}}]	7	7
1600	64	29	64	json	[{"pk": 29, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_30\\" title=\\"Icon - fa-calendar\\"></p>\\n\\n<h3>Schedule it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Schedule it Curabitur...	29
1601	64	8	14	json	[{"pk": 8, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:22.155", "language": "en", "parent": 3, "numchild": 1, "creation_date": "2015-05-22T11:01:16.060", "depth": 2, "position": 1, "path": "00020002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	8	8
1602	64	30	14	json	[{"pk": 30, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:46.762", "language": "en", "parent": 29, "numchild": 0, "creation_date": "2015-05-22T11:08:35.830", "depth": 5, "position": 0, "path": "00050007000300010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	30	30
1603	64	31	14	json	[{"pk": 31, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:03.319", "language": "en", "parent": 24, "numchild": 1, "creation_date": "2015-05-22T11:09:03.312", "depth": 4, "position": 0, "path": "0005000700040001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	31	31
1604	64	13	44	json	[{"pk": 13, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	13
1605	64	19	44	json	[{"pk": 19, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	19
1606	64	2	39	json	[{"pk": 2, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 1, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg)	2
1607	64	12	25	json	[{"pk": 12, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	12
1608	64	13	14	json	[{"pk": 13, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.850", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:01.806", "depth": 2, "position": 0, "path": "00050001", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	13	13
1609	64	22	14	json	[{"pk": 22, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.080", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.076", "depth": 3, "position": 1, "path": "000500070002", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	22	22
1610	64	14	14	json	[{"pk": 14, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.856", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:16.457", "depth": 2, "position": 2, "path": "00050002", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	14	14
1611	64	7	64	json	[{"pk": 7, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Explore your limits</h1>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada.<br>\\nNulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	Explore your limits...	7
1612	64	15	14	json	[{"pk": 15, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.863", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:28.907", "depth": 2, "position": 1, "path": "00050003", "placeholder": 3, "plugin_type": "TextPlugin"}}]	15	15
1613	64	3	25	json	[{"pk": 3, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-content", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: feature-content	3
1614	64	16	14	json	[{"pk": 16, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.869", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:47.410", "depth": 2, "position": 3, "path": "00050004", "placeholder": 3, "plugin_type": "TextPlugin"}}]	16	16
1615	64	17	44	json	[{"pk": 17, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	17
1616	64	17	14	json	[{"pk": 17, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:15.334", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:05:12.306", "depth": 1, "position": 5, "path": "0006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	17	17
1617	64	29	14	json	[{"pk": 29, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:48.535", "language": "en", "parent": 23, "numchild": 1, "creation_date": "2015-05-22T11:08:25.281", "depth": 4, "position": 0, "path": "0005000700030001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	29	29
1618	64	18	14	json	[{"pk": 18, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:33.733", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:30.146", "depth": 2, "position": 4, "path": "00050005", "placeholder": 3, "plugin_type": "TextPlugin"}}]	18	18
1619	64	19	14	json	[{"pk": 19, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:51.317", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:45.474", "depth": 2, "position": 5, "path": "00050006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	19	19
1620	64	25	14	json	[{"pk": 25, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:17.127", "language": "en", "parent": 21, "numchild": 1, "creation_date": "2015-05-22T11:06:36.687", "depth": 4, "position": 0, "path": "0005000700010001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	25	25
1621	64	20	14	json	[{"pk": 20, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.061", "language": "en", "parent": 12, "numchild": 4, "creation_date": "2015-05-22T11:06:05.640", "depth": 2, "position": 6, "path": "00050007", "placeholder": 3, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	20	20
1622	64	4	14	json	[{"pk": 4, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.651", "language": "en", "parent": 8, "numchild": 1, "creation_date": "2015-05-22T10:58:44.225", "depth": 3, "position": 0, "path": "000200020001", "placeholder": 2, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	4	4
1623	64	21	14	json	[{"pk": 21, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.070", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.067", "depth": 3, "position": 0, "path": "000500070001", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	21	21
1624	65	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "tpl_home.html", "placeholders": [2, 3], "changed_date": "2015-05-22T11:09:13.672", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
1625	65	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
1626	65	3	14	json	[{"pk": 3, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:21.519", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:58:07.414", "depth": 1, "position": 2, "path": "0002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	3	3
1627	65	4	45	json	[{"pk": 4, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	1 column	4
1628	65	5	46	json	[{"pk": 5, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 24, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": null, "lg_pull": null, "xs_pull": null}}]	col-md-24 	5
1630	65	1	25	json	[{"pk": 1, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-visual", "padding_bottom": null, "additional_class_names": "", "label": "Visual", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Visual”: feature-visual	1
1631	65	8	25	json	[{"pk": 8, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "container", "padding_bottom": null, "additional_class_names": "", "label": "Grid", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Grid”: container	8
1632	65	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
1633	65	23	14	json	[{"pk": 23, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.089", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.085", "depth": 3, "position": 2, "path": "000500070003", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	23	23
1634	65	12	14	json	[{"pk": 12, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:03:47.125", "language": "en", "parent": null, "numchild": 7, "creation_date": "2015-05-22T11:03:41.457", "depth": 1, "position": 0, "path": "0005", "placeholder": 3, "plugin_type": "StylePlugin"}}]	12	12
1635	65	2	14	json	[{"pk": 2, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:57:32.263", "language": "en", "parent": 1, "numchild": 0, "creation_date": "2015-05-22T10:56:32.155", "depth": 2, "position": 0, "path": "00010001", "placeholder": 2, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	2	2
1636	65	14	44	json	[{"pk": 14, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	14
1637	65	15	64	json	[{"pk": 15, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>The Next Giant Leap For Mankind</h1>\\n\\n<p class=\\"lead\\">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	The Next Giant...	15
1638	65	16	64	json	[{"pk": 16, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<hr>"}}]		16
1639	65	24	14	json	[{"pk": 24, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.097", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.094", "depth": 3, "position": 3, "path": "000500070004", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	24	24
1640	65	18	64	json	[{"pk": 18, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>How do you reach new limits?</h2>\\n"}}]	How do you...	18
1641	65	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
1642	65	20	45	json	[{"pk": 20, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	4 columns	20
1643	65	21	46	json	[{"pk": 21, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	21
1644	65	22	46	json	[{"pk": 22, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	22
1645	65	23	46	json	[{"pk": 23, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	23
1646	65	24	46	json	[{"pk": 24, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	24
1647	65	25	64	json	[{"pk": 25, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_26\\" title=\\"Icon - fa-crosshairs\\"></p>\\n\\n<h3>Set your goals</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Set your goals...	25
1648	65	26	35	json	[{"pk": 26, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-crosshairs"}}]	fa-crosshairs	26
1649	65	27	64	json	[{"pk": 27, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_28\\" title=\\"Icon - fa-thumb-tack\\"></p>\\n\\n<h3>Believe in yourself</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Believe in yourself...	27
1650	65	28	35	json	[{"pk": 28, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-thumb-tack"}}]	fa-thumb-tack	28
1651	65	26	14	json	[{"pk": 26, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:12.797", "language": "en", "parent": 25, "numchild": 0, "creation_date": "2015-05-22T11:06:50.389", "depth": 5, "position": 0, "path": "00050007000100010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	26	26
1652	65	30	35	json	[{"pk": 30, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-calendar"}}]	fa-calendar	30
1653	65	5	14	json	[{"pk": 5, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.635", "language": "en", "parent": 4, "numchild": 2, "creation_date": "2015-05-22T10:59:10.499", "depth": 4, "position": 0, "path": "0002000200010001", "placeholder": 2, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	5	5
1654	65	32	35	json	[{"pk": 32, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-rocket"}}]	fa-rocket	32
1655	65	27	14	json	[{"pk": 27, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:12.441", "language": "en", "parent": 22, "numchild": 1, "creation_date": "2015-05-22T11:07:50.132", "depth": 4, "position": 0, "path": "0005000700020001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	27	27
1656	65	1	14	json	[{"pk": 1, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:31.719", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:56:01.162", "depth": 1, "position": 0, "path": "0001", "placeholder": 2, "plugin_type": "StylePlugin"}}]	1	1
1657	65	6	14	json	[{"pk": 6, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.638", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T10:59:50.854", "depth": 5, "position": 0, "path": "00020002000100010001", "placeholder": 2, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	6	6
1658	65	28	14	json	[{"pk": 28, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:10.963", "language": "en", "parent": 27, "numchild": 0, "creation_date": "2015-05-22T11:08:02.785", "depth": 5, "position": 0, "path": "00050007000200010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	28	28
1659	65	7	14	json	[{"pk": 7, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.642", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T11:00:04.937", "depth": 5, "position": 1, "path": "00020002000100010002", "placeholder": 2, "plugin_type": "TextPlugin"}}]	7	7
1660	65	29	64	json	[{"pk": 29, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_30\\" title=\\"Icon - fa-calendar\\"></p>\\n\\n<h3>Schedule it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Schedule it Curabitur...	29
1661	65	8	14	json	[{"pk": 8, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:22.155", "language": "en", "parent": 3, "numchild": 1, "creation_date": "2015-05-22T11:01:16.060", "depth": 2, "position": 1, "path": "00020002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	8	8
1662	65	30	14	json	[{"pk": 30, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:46.762", "language": "en", "parent": 29, "numchild": 0, "creation_date": "2015-05-22T11:08:35.830", "depth": 5, "position": 0, "path": "00050007000300010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	30	30
1663	65	31	14	json	[{"pk": 31, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:03.319", "language": "en", "parent": 24, "numchild": 1, "creation_date": "2015-05-22T11:09:03.312", "depth": 4, "position": 0, "path": "0005000700040001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	31	31
1664	65	13	44	json	[{"pk": 13, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	13
1665	65	19	44	json	[{"pk": 19, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	19
1666	65	32	14	json	[{"pk": 32, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:19.976", "language": "en", "parent": 31, "numchild": 0, "creation_date": "2015-05-22T11:09:13.485", "depth": 5, "position": 0, "path": "00050007000400010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	32	32
1667	65	2	39	json	[{"pk": 2, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 1, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg)	2
1668	65	12	25	json	[{"pk": 12, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	12
1669	65	13	14	json	[{"pk": 13, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.850", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:01.806", "depth": 2, "position": 0, "path": "00050001", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	13	13
1670	65	22	14	json	[{"pk": 22, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.080", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.076", "depth": 3, "position": 1, "path": "000500070002", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	22	22
1671	65	14	14	json	[{"pk": 14, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.856", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:16.457", "depth": 2, "position": 2, "path": "00050002", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	14	14
1672	65	7	64	json	[{"pk": 7, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Explore your limits</h1>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada.<br>\\nNulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	Explore your limits...	7
1673	65	15	14	json	[{"pk": 15, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.863", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:28.907", "depth": 2, "position": 1, "path": "00050003", "placeholder": 3, "plugin_type": "TextPlugin"}}]	15	15
1674	65	3	25	json	[{"pk": 3, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-content", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: feature-content	3
1675	65	16	14	json	[{"pk": 16, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.869", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:47.410", "depth": 2, "position": 3, "path": "00050004", "placeholder": 3, "plugin_type": "TextPlugin"}}]	16	16
1676	65	17	44	json	[{"pk": 17, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	17
1677	65	17	14	json	[{"pk": 17, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:15.334", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:05:12.306", "depth": 1, "position": 5, "path": "0006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	17	17
1678	65	29	14	json	[{"pk": 29, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:48.535", "language": "en", "parent": 23, "numchild": 1, "creation_date": "2015-05-22T11:08:25.281", "depth": 4, "position": 0, "path": "0005000700030001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	29	29
1679	65	18	14	json	[{"pk": 18, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:33.733", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:30.146", "depth": 2, "position": 4, "path": "00050005", "placeholder": 3, "plugin_type": "TextPlugin"}}]	18	18
1680	65	19	14	json	[{"pk": 19, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:51.317", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:45.474", "depth": 2, "position": 5, "path": "00050006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	19	19
1681	65	25	14	json	[{"pk": 25, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:17.127", "language": "en", "parent": 21, "numchild": 1, "creation_date": "2015-05-22T11:06:36.687", "depth": 4, "position": 0, "path": "0005000700010001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	25	25
1682	65	20	14	json	[{"pk": 20, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.061", "language": "en", "parent": 12, "numchild": 4, "creation_date": "2015-05-22T11:06:05.640", "depth": 2, "position": 6, "path": "00050007", "placeholder": 3, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	20	20
1683	65	4	14	json	[{"pk": 4, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.651", "language": "en", "parent": 8, "numchild": 1, "creation_date": "2015-05-22T10:58:44.225", "depth": 3, "position": 0, "path": "000200020001", "placeholder": 2, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	4	4
1684	65	21	14	json	[{"pk": 21, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.070", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.067", "depth": 3, "position": 0, "path": "000500070001", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	21	21
1685	66	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "tpl_home.html", "placeholders": [2, 3], "changed_date": "2015-05-22T11:09:20.160", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
1686	66	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
1687	66	3	14	json	[{"pk": 3, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:21.519", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:58:07.414", "depth": 1, "position": 2, "path": "0002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	3	3
1688	66	4	45	json	[{"pk": 4, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	1 column	4
1689	66	5	46	json	[{"pk": 5, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 24, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": null, "lg_pull": null, "xs_pull": null}}]	col-md-24 	5
1690	66	6	44	json	[{"pk": 6, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	6
1691	66	1	25	json	[{"pk": 1, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-visual", "padding_bottom": null, "additional_class_names": "", "label": "Visual", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Visual”: feature-visual	1
1692	66	8	25	json	[{"pk": 8, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "container", "padding_bottom": null, "additional_class_names": "", "label": "Grid", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Grid”: container	8
1693	66	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
1694	66	23	14	json	[{"pk": 23, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.089", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.085", "depth": 3, "position": 2, "path": "000500070003", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	23	23
1695	66	12	14	json	[{"pk": 12, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:03:47.125", "language": "en", "parent": null, "numchild": 7, "creation_date": "2015-05-22T11:03:41.457", "depth": 1, "position": 0, "path": "0005", "placeholder": 3, "plugin_type": "StylePlugin"}}]	12	12
1696	66	2	14	json	[{"pk": 2, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:57:32.263", "language": "en", "parent": 1, "numchild": 0, "creation_date": "2015-05-22T10:56:32.155", "depth": 2, "position": 0, "path": "00010001", "placeholder": 2, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	2	2
1697	66	14	44	json	[{"pk": 14, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	14
1698	66	15	64	json	[{"pk": 15, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>The Next Giant Leap For Mankind</h1>\\n\\n<p class=\\"lead\\">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	The Next Giant...	15
1699	66	16	64	json	[{"pk": 16, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<hr>"}}]		16
1700	66	24	14	json	[{"pk": 24, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.097", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.094", "depth": 3, "position": 3, "path": "000500070004", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	24	24
1704	66	21	46	json	[{"pk": 21, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	21
1705	66	22	46	json	[{"pk": 22, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	22
1706	66	23	46	json	[{"pk": 23, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	23
1707	66	24	46	json	[{"pk": 24, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	24
1708	66	25	64	json	[{"pk": 25, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_26\\" title=\\"Icon - fa-crosshairs\\"></p>\\n\\n<h3>Set your goals</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Set your goals...	25
1709	66	26	35	json	[{"pk": 26, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-crosshairs"}}]	fa-crosshairs	26
1710	66	27	64	json	[{"pk": 27, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_28\\" title=\\"Icon - fa-thumb-tack\\"></p>\\n\\n<h3>Believe in yourself</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Believe in yourself...	27
1711	66	28	35	json	[{"pk": 28, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-thumb-tack"}}]	fa-thumb-tack	28
1712	66	26	14	json	[{"pk": 26, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:12.797", "language": "en", "parent": 25, "numchild": 0, "creation_date": "2015-05-22T11:06:50.389", "depth": 5, "position": 0, "path": "00050007000100010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	26	26
1713	66	30	35	json	[{"pk": 30, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-calendar"}}]	fa-calendar	30
1714	66	5	14	json	[{"pk": 5, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.635", "language": "en", "parent": 4, "numchild": 2, "creation_date": "2015-05-22T10:59:10.499", "depth": 4, "position": 0, "path": "0002000200010001", "placeholder": 2, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	5	5
1715	66	32	35	json	[{"pk": 32, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-rocket"}}]	fa-rocket	32
1716	66	27	14	json	[{"pk": 27, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:12.441", "language": "en", "parent": 22, "numchild": 1, "creation_date": "2015-05-22T11:07:50.132", "depth": 4, "position": 0, "path": "0005000700020001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	27	27
1717	66	1	14	json	[{"pk": 1, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:31.719", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:56:01.162", "depth": 1, "position": 0, "path": "0001", "placeholder": 2, "plugin_type": "StylePlugin"}}]	1	1
1718	66	6	14	json	[{"pk": 6, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.638", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T10:59:50.854", "depth": 5, "position": 0, "path": "00020002000100010001", "placeholder": 2, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	6	6
1719	66	31	64	json	[{"pk": 31, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_32\\" title=\\"Icon - fa-rocket\\"></p>\\n\\n<h3>Launch it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Launch it Curabitur...	31
1720	66	28	14	json	[{"pk": 28, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:10.963", "language": "en", "parent": 27, "numchild": 0, "creation_date": "2015-05-22T11:08:02.785", "depth": 5, "position": 0, "path": "00050007000200010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	28	28
1721	66	7	14	json	[{"pk": 7, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.642", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T11:00:04.937", "depth": 5, "position": 1, "path": "00020002000100010002", "placeholder": 2, "plugin_type": "TextPlugin"}}]	7	7
1722	66	29	64	json	[{"pk": 29, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_30\\" title=\\"Icon - fa-calendar\\"></p>\\n\\n<h3>Schedule it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Schedule it Curabitur...	29
1723	66	8	14	json	[{"pk": 8, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:22.155", "language": "en", "parent": 3, "numchild": 1, "creation_date": "2015-05-22T11:01:16.060", "depth": 2, "position": 1, "path": "00020002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	8	8
1724	66	30	14	json	[{"pk": 30, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:46.762", "language": "en", "parent": 29, "numchild": 0, "creation_date": "2015-05-22T11:08:35.830", "depth": 5, "position": 0, "path": "00050007000300010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	30	30
1725	66	31	14	json	[{"pk": 31, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:21.189", "language": "en", "parent": 24, "numchild": 1, "creation_date": "2015-05-22T11:09:03.312", "depth": 4, "position": 0, "path": "0005000700040001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	31	31
1726	66	13	44	json	[{"pk": 13, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	13
1728	66	32	14	json	[{"pk": 32, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:19.976", "language": "en", "parent": 31, "numchild": 0, "creation_date": "2015-05-22T11:09:13.485", "depth": 5, "position": 0, "path": "00050007000400010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	32	32
1729	66	2	39	json	[{"pk": 2, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 1, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg)	2
1730	66	12	25	json	[{"pk": 12, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	12
1731	66	13	14	json	[{"pk": 13, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.850", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:01.806", "depth": 2, "position": 0, "path": "00050001", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	13	13
1732	66	22	14	json	[{"pk": 22, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.080", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.076", "depth": 3, "position": 1, "path": "000500070002", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	22	22
1733	66	14	14	json	[{"pk": 14, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.856", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:16.457", "depth": 2, "position": 2, "path": "00050002", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	14	14
1734	66	7	64	json	[{"pk": 7, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Explore your limits</h1>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada.<br>\\nNulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	Explore your limits...	7
1735	66	15	14	json	[{"pk": 15, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.863", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:28.907", "depth": 2, "position": 1, "path": "00050003", "placeholder": 3, "plugin_type": "TextPlugin"}}]	15	15
1736	66	3	25	json	[{"pk": 3, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-content", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: feature-content	3
1737	66	16	14	json	[{"pk": 16, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.869", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:47.410", "depth": 2, "position": 3, "path": "00050004", "placeholder": 3, "plugin_type": "TextPlugin"}}]	16	16
1738	66	17	44	json	[{"pk": 17, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	17
1739	66	17	14	json	[{"pk": 17, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:15.334", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:05:12.306", "depth": 1, "position": 5, "path": "0006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	17	17
1740	66	29	14	json	[{"pk": 29, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:48.535", "language": "en", "parent": 23, "numchild": 1, "creation_date": "2015-05-22T11:08:25.281", "depth": 4, "position": 0, "path": "0005000700030001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	29	29
1741	66	18	14	json	[{"pk": 18, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:33.733", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:30.146", "depth": 2, "position": 4, "path": "00050005", "placeholder": 3, "plugin_type": "TextPlugin"}}]	18	18
1742	66	19	14	json	[{"pk": 19, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:51.317", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:45.474", "depth": 2, "position": 5, "path": "00050006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	19	19
1743	66	25	14	json	[{"pk": 25, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:17.127", "language": "en", "parent": 21, "numchild": 1, "creation_date": "2015-05-22T11:06:36.687", "depth": 4, "position": 0, "path": "0005000700010001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	25	25
1744	66	20	14	json	[{"pk": 20, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.061", "language": "en", "parent": 12, "numchild": 4, "creation_date": "2015-05-22T11:06:05.640", "depth": 2, "position": 6, "path": "00050007", "placeholder": 3, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	20	20
1745	66	4	14	json	[{"pk": 4, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.651", "language": "en", "parent": 8, "numchild": 1, "creation_date": "2015-05-22T10:58:44.225", "depth": 3, "position": 0, "path": "000200020001", "placeholder": 2, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	4	4
1746	66	21	14	json	[{"pk": 21, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.070", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.067", "depth": 3, "position": 0, "path": "000500070001", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	21	21
1747	67	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "tpl_home.html", "placeholders": [2, 3], "changed_date": "2015-05-22T11:09:21.381", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
1748	67	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
1917	69	19	44	json	[{"pk": 19, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	19
1749	67	3	14	json	[{"pk": 3, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:21.519", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:58:07.414", "depth": 1, "position": 2, "path": "0002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	3	3
1750	67	4	45	json	[{"pk": 4, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	1 column	4
1751	67	5	46	json	[{"pk": 5, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 24, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": null, "lg_pull": null, "xs_pull": null}}]	col-md-24 	5
1752	67	6	44	json	[{"pk": 6, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	6
1753	67	1	25	json	[{"pk": 1, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-visual", "padding_bottom": null, "additional_class_names": "", "label": "Visual", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Visual”: feature-visual	1
1754	67	8	25	json	[{"pk": 8, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "container", "padding_bottom": null, "additional_class_names": "", "label": "Grid", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Grid”: container	8
1755	67	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
1756	67	23	14	json	[{"pk": 23, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.089", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.085", "depth": 3, "position": 2, "path": "000500070003", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	23	23
1757	67	12	14	json	[{"pk": 12, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:03:47.125", "language": "en", "parent": null, "numchild": 7, "creation_date": "2015-05-22T11:03:41.457", "depth": 1, "position": 0, "path": "0005", "placeholder": 3, "plugin_type": "StylePlugin"}}]	12	12
1758	67	2	14	json	[{"pk": 2, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:57:32.263", "language": "en", "parent": 1, "numchild": 0, "creation_date": "2015-05-22T10:56:32.155", "depth": 2, "position": 0, "path": "00010001", "placeholder": 2, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	2	2
1759	67	14	44	json	[{"pk": 14, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	14
1760	67	15	64	json	[{"pk": 15, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>The Next Giant Leap For Mankind</h1>\\n\\n<p class=\\"lead\\">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	The Next Giant...	15
1761	67	16	64	json	[{"pk": 16, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<hr>"}}]		16
1762	67	24	14	json	[{"pk": 24, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.097", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.094", "depth": 3, "position": 3, "path": "000500070004", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	24	24
1763	67	18	64	json	[{"pk": 18, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>How do you reach new limits?</h2>\\n"}}]	How do you...	18
1764	67	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
1765	67	20	45	json	[{"pk": 20, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	4 columns	20
1766	67	21	46	json	[{"pk": 21, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	21
1767	67	22	46	json	[{"pk": 22, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	22
1768	67	23	46	json	[{"pk": 23, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	23
1769	67	24	46	json	[{"pk": 24, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	24
1770	67	25	64	json	[{"pk": 25, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_26\\" title=\\"Icon - fa-crosshairs\\"></p>\\n\\n<h3>Set your goals</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Set your goals...	25
1771	67	26	35	json	[{"pk": 26, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-crosshairs"}}]	fa-crosshairs	26
1772	67	27	64	json	[{"pk": 27, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_28\\" title=\\"Icon - fa-thumb-tack\\"></p>\\n\\n<h3>Believe in yourself</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Believe in yourself...	27
1773	67	28	35	json	[{"pk": 28, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-thumb-tack"}}]	fa-thumb-tack	28
1774	67	26	14	json	[{"pk": 26, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:12.797", "language": "en", "parent": 25, "numchild": 0, "creation_date": "2015-05-22T11:06:50.389", "depth": 5, "position": 0, "path": "00050007000100010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	26	26
1775	67	30	35	json	[{"pk": 30, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-calendar"}}]	fa-calendar	30
1776	67	5	14	json	[{"pk": 5, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.635", "language": "en", "parent": 4, "numchild": 2, "creation_date": "2015-05-22T10:59:10.499", "depth": 4, "position": 0, "path": "0002000200010001", "placeholder": 2, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	5	5
1777	67	32	35	json	[{"pk": 32, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-rocket"}}]	fa-rocket	32
1778	67	33	14	json	[{"pk": 33, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:38.610", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:09:38.604", "depth": 1, "position": 21, "path": "0007", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	33	33
1779	67	27	14	json	[{"pk": 27, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:12.441", "language": "en", "parent": 22, "numchild": 1, "creation_date": "2015-05-22T11:07:50.132", "depth": 4, "position": 0, "path": "0005000700020001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	27	27
1780	67	1	14	json	[{"pk": 1, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:31.719", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:56:01.162", "depth": 1, "position": 0, "path": "0001", "placeholder": 2, "plugin_type": "StylePlugin"}}]	1	1
1781	67	6	14	json	[{"pk": 6, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.638", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T10:59:50.854", "depth": 5, "position": 0, "path": "00020002000100010001", "placeholder": 2, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	6	6
1782	67	31	64	json	[{"pk": 31, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_32\\" title=\\"Icon - fa-rocket\\"></p>\\n\\n<h3>Launch it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Launch it Curabitur...	31
1783	67	28	14	json	[{"pk": 28, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:10.963", "language": "en", "parent": 27, "numchild": 0, "creation_date": "2015-05-22T11:08:02.785", "depth": 5, "position": 0, "path": "00050007000200010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	28	28
1784	67	7	14	json	[{"pk": 7, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.642", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T11:00:04.937", "depth": 5, "position": 1, "path": "00020002000100010002", "placeholder": 2, "plugin_type": "TextPlugin"}}]	7	7
1785	67	29	64	json	[{"pk": 29, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_30\\" title=\\"Icon - fa-calendar\\"></p>\\n\\n<h3>Schedule it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Schedule it Curabitur...	29
1786	67	8	14	json	[{"pk": 8, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:22.155", "language": "en", "parent": 3, "numchild": 1, "creation_date": "2015-05-22T11:01:16.060", "depth": 2, "position": 1, "path": "00020002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	8	8
1787	67	30	14	json	[{"pk": 30, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:46.762", "language": "en", "parent": 29, "numchild": 0, "creation_date": "2015-05-22T11:08:35.830", "depth": 5, "position": 0, "path": "00050007000300010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	30	30
1788	67	31	14	json	[{"pk": 31, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:21.189", "language": "en", "parent": 24, "numchild": 1, "creation_date": "2015-05-22T11:09:03.312", "depth": 4, "position": 0, "path": "0005000700040001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	31	31
1789	67	13	44	json	[{"pk": 13, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	13
1790	67	19	44	json	[{"pk": 19, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	19
1791	67	32	14	json	[{"pk": 32, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:19.976", "language": "en", "parent": 31, "numchild": 0, "creation_date": "2015-05-22T11:09:13.485", "depth": 5, "position": 0, "path": "00050007000400010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	32	32
1792	67	2	39	json	[{"pk": 2, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 1, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg)	2
1793	67	12	25	json	[{"pk": 12, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	12
1794	67	13	14	json	[{"pk": 13, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.850", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:01.806", "depth": 2, "position": 0, "path": "00050001", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	13	13
1795	67	22	14	json	[{"pk": 22, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.080", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.076", "depth": 3, "position": 1, "path": "000500070002", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	22	22
1796	67	14	14	json	[{"pk": 14, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.856", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:16.457", "depth": 2, "position": 2, "path": "00050002", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	14	14
1939	70	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
1797	67	7	64	json	[{"pk": 7, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Explore your limits</h1>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada.<br>\\nNulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	Explore your limits...	7
1798	67	15	14	json	[{"pk": 15, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.863", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:28.907", "depth": 2, "position": 1, "path": "00050003", "placeholder": 3, "plugin_type": "TextPlugin"}}]	15	15
1799	67	3	25	json	[{"pk": 3, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-content", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: feature-content	3
1800	67	16	14	json	[{"pk": 16, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.869", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:47.410", "depth": 2, "position": 3, "path": "00050004", "placeholder": 3, "plugin_type": "TextPlugin"}}]	16	16
1801	67	17	44	json	[{"pk": 17, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	17
1802	67	17	14	json	[{"pk": 17, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:15.334", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:05:12.306", "depth": 1, "position": 5, "path": "0006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	17	17
1803	67	29	14	json	[{"pk": 29, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:48.535", "language": "en", "parent": 23, "numchild": 1, "creation_date": "2015-05-22T11:08:25.281", "depth": 4, "position": 0, "path": "0005000700030001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	29	29
1804	67	18	14	json	[{"pk": 18, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:33.733", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:30.146", "depth": 2, "position": 4, "path": "00050005", "placeholder": 3, "plugin_type": "TextPlugin"}}]	18	18
1805	67	19	14	json	[{"pk": 19, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:51.317", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:45.474", "depth": 2, "position": 5, "path": "00050006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	19	19
1806	67	25	14	json	[{"pk": 25, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:17.127", "language": "en", "parent": 21, "numchild": 1, "creation_date": "2015-05-22T11:06:36.687", "depth": 4, "position": 0, "path": "0005000700010001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	25	25
1807	67	20	14	json	[{"pk": 20, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.061", "language": "en", "parent": 12, "numchild": 4, "creation_date": "2015-05-22T11:06:05.640", "depth": 2, "position": 6, "path": "00050007", "placeholder": 3, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	20	20
1808	67	4	14	json	[{"pk": 4, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.651", "language": "en", "parent": 8, "numchild": 1, "creation_date": "2015-05-22T10:58:44.225", "depth": 3, "position": 0, "path": "000200020001", "placeholder": 2, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	4	4
1809	67	21	14	json	[{"pk": 21, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.070", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.067", "depth": 3, "position": 0, "path": "000500070001", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	21	21
1810	68	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "tpl_home.html", "placeholders": [2, 3], "changed_date": "2015-05-22T11:09:38.776", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
1811	68	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
1812	68	3	14	json	[{"pk": 3, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:21.519", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:58:07.414", "depth": 1, "position": 2, "path": "0002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	3	3
1813	68	4	45	json	[{"pk": 4, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	1 column	4
1814	68	5	46	json	[{"pk": 5, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 24, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": null, "lg_pull": null, "xs_pull": null}}]	col-md-24 	5
1815	68	6	44	json	[{"pk": 6, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	6
1816	68	1	25	json	[{"pk": 1, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-visual", "padding_bottom": null, "additional_class_names": "", "label": "Visual", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Visual”: feature-visual	1
1817	68	8	25	json	[{"pk": 8, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "container", "padding_bottom": null, "additional_class_names": "", "label": "Grid", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Grid”: container	8
1818	68	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
2083	72	18	64	json	[{"pk": 18, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>How do you reach new limits?</h2>\\n"}}]	How do you...	18
1819	68	23	14	json	[{"pk": 23, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.089", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.085", "depth": 3, "position": 2, "path": "000500070003", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	23	23
1820	68	12	14	json	[{"pk": 12, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:03:47.125", "language": "en", "parent": null, "numchild": 7, "creation_date": "2015-05-22T11:03:41.457", "depth": 1, "position": 0, "path": "0005", "placeholder": 3, "plugin_type": "StylePlugin"}}]	12	12
1821	68	2	14	json	[{"pk": 2, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:57:32.263", "language": "en", "parent": 1, "numchild": 0, "creation_date": "2015-05-22T10:56:32.155", "depth": 2, "position": 0, "path": "00010001", "placeholder": 2, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	2	2
1822	68	14	44	json	[{"pk": 14, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	14
1823	68	15	64	json	[{"pk": 15, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>The Next Giant Leap For Mankind</h1>\\n\\n<p class=\\"lead\\">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	The Next Giant...	15
1824	68	16	64	json	[{"pk": 16, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<hr>"}}]		16
1825	68	24	14	json	[{"pk": 24, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.097", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.094", "depth": 3, "position": 3, "path": "000500070004", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	24	24
1826	68	18	64	json	[{"pk": 18, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>How do you reach new limits?</h2>\\n"}}]	How do you...	18
1827	68	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
1829	68	21	46	json	[{"pk": 21, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	21
1830	68	22	46	json	[{"pk": 22, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	22
1831	68	23	46	json	[{"pk": 23, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	23
1832	68	24	46	json	[{"pk": 24, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	24
1833	68	25	64	json	[{"pk": 25, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_26\\" title=\\"Icon - fa-crosshairs\\"></p>\\n\\n<h3>Set your goals</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Set your goals...	25
1834	68	26	35	json	[{"pk": 26, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-crosshairs"}}]	fa-crosshairs	26
1835	68	27	64	json	[{"pk": 27, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_28\\" title=\\"Icon - fa-thumb-tack\\"></p>\\n\\n<h3>Believe in yourself</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Believe in yourself...	27
1836	68	28	35	json	[{"pk": 28, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-thumb-tack"}}]	fa-thumb-tack	28
1837	68	26	14	json	[{"pk": 26, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:12.797", "language": "en", "parent": 25, "numchild": 0, "creation_date": "2015-05-22T11:06:50.389", "depth": 5, "position": 0, "path": "00050007000100010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	26	26
1838	68	30	35	json	[{"pk": 30, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-calendar"}}]	fa-calendar	30
1839	68	5	14	json	[{"pk": 5, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.635", "language": "en", "parent": 4, "numchild": 2, "creation_date": "2015-05-22T10:59:10.499", "depth": 4, "position": 0, "path": "0002000200010001", "placeholder": 2, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	5	5
1840	68	32	35	json	[{"pk": 32, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-rocket"}}]	fa-rocket	32
1841	68	33	44	json	[{"pk": 33, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	33
1842	68	27	14	json	[{"pk": 27, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:12.441", "language": "en", "parent": 22, "numchild": 1, "creation_date": "2015-05-22T11:07:50.132", "depth": 4, "position": 0, "path": "0005000700020001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	27	27
1843	68	1	14	json	[{"pk": 1, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:31.719", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:56:01.162", "depth": 1, "position": 0, "path": "0001", "placeholder": 2, "plugin_type": "StylePlugin"}}]	1	1
1844	68	6	14	json	[{"pk": 6, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.638", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T10:59:50.854", "depth": 5, "position": 0, "path": "00020002000100010001", "placeholder": 2, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	6	6
1845	68	31	64	json	[{"pk": 31, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_32\\" title=\\"Icon - fa-rocket\\"></p>\\n\\n<h3>Launch it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Launch it Curabitur...	31
1846	68	28	14	json	[{"pk": 28, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:10.963", "language": "en", "parent": 27, "numchild": 0, "creation_date": "2015-05-22T11:08:02.785", "depth": 5, "position": 0, "path": "00050007000200010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	28	28
1847	68	7	14	json	[{"pk": 7, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.642", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T11:00:04.937", "depth": 5, "position": 1, "path": "00020002000100010002", "placeholder": 2, "plugin_type": "TextPlugin"}}]	7	7
1848	68	29	64	json	[{"pk": 29, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_30\\" title=\\"Icon - fa-calendar\\"></p>\\n\\n<h3>Schedule it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Schedule it Curabitur...	29
1849	68	8	14	json	[{"pk": 8, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:22.155", "language": "en", "parent": 3, "numchild": 1, "creation_date": "2015-05-22T11:01:16.060", "depth": 2, "position": 1, "path": "00020002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	8	8
1850	68	30	14	json	[{"pk": 30, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:46.762", "language": "en", "parent": 29, "numchild": 0, "creation_date": "2015-05-22T11:08:35.830", "depth": 5, "position": 0, "path": "00050007000300010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	30	30
1851	68	31	14	json	[{"pk": 31, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:21.189", "language": "en", "parent": 24, "numchild": 1, "creation_date": "2015-05-22T11:09:03.312", "depth": 4, "position": 0, "path": "0005000700040001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	31	31
1852	68	13	44	json	[{"pk": 13, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	13
1853	68	19	44	json	[{"pk": 19, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	19
1854	68	32	14	json	[{"pk": 32, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:19.976", "language": "en", "parent": 31, "numchild": 0, "creation_date": "2015-05-22T11:09:13.485", "depth": 5, "position": 0, "path": "00050007000400010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	32	32
1855	68	2	39	json	[{"pk": 2, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 1, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg)	2
1856	68	33	14	json	[{"pk": 33, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:42.411", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:09:38.604", "depth": 1, "position": 21, "path": "0007", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	33	33
1857	68	12	25	json	[{"pk": 12, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	12
1858	68	13	14	json	[{"pk": 13, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.850", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:01.806", "depth": 2, "position": 0, "path": "00050001", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	13	13
1859	68	22	14	json	[{"pk": 22, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.080", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.076", "depth": 3, "position": 1, "path": "000500070002", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	22	22
1860	68	14	14	json	[{"pk": 14, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.856", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:16.457", "depth": 2, "position": 2, "path": "00050002", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	14	14
1861	68	7	64	json	[{"pk": 7, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Explore your limits</h1>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada.<br>\\nNulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	Explore your limits...	7
1862	68	15	14	json	[{"pk": 15, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.863", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:28.907", "depth": 2, "position": 1, "path": "00050003", "placeholder": 3, "plugin_type": "TextPlugin"}}]	15	15
1863	68	3	25	json	[{"pk": 3, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-content", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: feature-content	3
1864	68	16	14	json	[{"pk": 16, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:04:57.869", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:47.410", "depth": 2, "position": 3, "path": "00050004", "placeholder": 3, "plugin_type": "TextPlugin"}}]	16	16
1865	68	17	44	json	[{"pk": 17, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	17
1866	68	17	14	json	[{"pk": 17, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:15.334", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:05:12.306", "depth": 1, "position": 5, "path": "0006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	17	17
1867	68	29	14	json	[{"pk": 29, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:48.535", "language": "en", "parent": 23, "numchild": 1, "creation_date": "2015-05-22T11:08:25.281", "depth": 4, "position": 0, "path": "0005000700030001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	29	29
1868	68	18	14	json	[{"pk": 18, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:33.733", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:30.146", "depth": 2, "position": 4, "path": "00050005", "placeholder": 3, "plugin_type": "TextPlugin"}}]	18	18
1869	68	19	14	json	[{"pk": 19, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:05:51.317", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:45.474", "depth": 2, "position": 5, "path": "00050006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	19	19
1870	68	25	14	json	[{"pk": 25, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:17.127", "language": "en", "parent": 21, "numchild": 1, "creation_date": "2015-05-22T11:06:36.687", "depth": 4, "position": 0, "path": "0005000700010001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	25	25
1871	68	20	14	json	[{"pk": 20, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.061", "language": "en", "parent": 12, "numchild": 4, "creation_date": "2015-05-22T11:06:05.640", "depth": 2, "position": 6, "path": "00050007", "placeholder": 3, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	20	20
1872	68	4	14	json	[{"pk": 4, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.651", "language": "en", "parent": 8, "numchild": 1, "creation_date": "2015-05-22T10:58:44.225", "depth": 3, "position": 0, "path": "000200020001", "placeholder": 2, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	4	4
1873	68	21	14	json	[{"pk": 21, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.070", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.067", "depth": 3, "position": 0, "path": "000500070001", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	21	21
1874	69	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "tpl_home.html", "placeholders": [2, 3], "changed_date": "2015-05-22T11:09:42.598", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
1875	69	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
1876	69	3	14	json	[{"pk": 3, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:21.519", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:58:07.414", "depth": 1, "position": 2, "path": "0002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	3	3
1877	69	4	45	json	[{"pk": 4, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	1 column	4
1878	69	5	46	json	[{"pk": 5, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 24, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": null, "lg_pull": null, "xs_pull": null}}]	col-md-24 	5
1879	69	6	44	json	[{"pk": 6, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	6
1880	69	1	25	json	[{"pk": 1, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-visual", "padding_bottom": null, "additional_class_names": "", "label": "Visual", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Visual”: feature-visual	1
1881	69	8	25	json	[{"pk": 8, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "container", "padding_bottom": null, "additional_class_names": "", "label": "Grid", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Grid”: container	8
1882	69	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
1883	69	23	14	json	[{"pk": 23, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.089", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.085", "depth": 3, "position": 2, "path": "000500070003", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	23	23
1884	69	12	14	json	[{"pk": 12, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:03:47.125", "language": "en", "parent": null, "numchild": 8, "creation_date": "2015-05-22T11:03:41.457", "depth": 1, "position": 0, "path": "0005", "placeholder": 3, "plugin_type": "StylePlugin"}}]	12	12
1885	69	2	14	json	[{"pk": 2, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:57:32.263", "language": "en", "parent": 1, "numchild": 0, "creation_date": "2015-05-22T10:56:32.155", "depth": 2, "position": 0, "path": "00010001", "placeholder": 2, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	2	2
1886	69	14	44	json	[{"pk": 14, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	14
1887	69	15	64	json	[{"pk": 15, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>The Next Giant Leap For Mankind</h1>\\n\\n<p class=\\"lead\\">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	The Next Giant...	15
1888	69	16	64	json	[{"pk": 16, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<hr>"}}]		16
1889	69	24	14	json	[{"pk": 24, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.097", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.094", "depth": 3, "position": 3, "path": "000500070004", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	24	24
1890	69	18	64	json	[{"pk": 18, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>How do you reach new limits?</h2>\\n"}}]	How do you...	18
1891	69	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
1893	69	21	46	json	[{"pk": 21, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	21
1894	69	22	46	json	[{"pk": 22, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	22
1895	69	23	46	json	[{"pk": 23, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	23
1896	69	24	46	json	[{"pk": 24, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	24
1897	69	25	64	json	[{"pk": 25, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_26\\" title=\\"Icon - fa-crosshairs\\"></p>\\n\\n<h3>Set your goals</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Set your goals...	25
1898	69	26	35	json	[{"pk": 26, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-crosshairs"}}]	fa-crosshairs	26
1899	69	27	64	json	[{"pk": 27, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_28\\" title=\\"Icon - fa-thumb-tack\\"></p>\\n\\n<h3>Believe in yourself</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Believe in yourself...	27
1900	69	28	35	json	[{"pk": 28, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-thumb-tack"}}]	fa-thumb-tack	28
1901	69	26	14	json	[{"pk": 26, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:12.797", "language": "en", "parent": 25, "numchild": 0, "creation_date": "2015-05-22T11:06:50.389", "depth": 5, "position": 0, "path": "00050007000100010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	26	26
1903	69	5	14	json	[{"pk": 5, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.635", "language": "en", "parent": 4, "numchild": 2, "creation_date": "2015-05-22T10:59:10.499", "depth": 4, "position": 0, "path": "0002000200010001", "placeholder": 2, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	5	5
1904	69	32	35	json	[{"pk": 32, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-rocket"}}]	fa-rocket	32
1905	69	33	44	json	[{"pk": 33, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	33
1906	69	27	14	json	[{"pk": 27, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:12.441", "language": "en", "parent": 22, "numchild": 1, "creation_date": "2015-05-22T11:07:50.132", "depth": 4, "position": 0, "path": "0005000700020001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	27	27
1907	69	1	14	json	[{"pk": 1, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:31.719", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:56:01.162", "depth": 1, "position": 0, "path": "0001", "placeholder": 2, "plugin_type": "StylePlugin"}}]	1	1
1908	69	6	14	json	[{"pk": 6, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.638", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T10:59:50.854", "depth": 5, "position": 0, "path": "00020002000100010001", "placeholder": 2, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	6	6
1909	69	31	64	json	[{"pk": 31, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_32\\" title=\\"Icon - fa-rocket\\"></p>\\n\\n<h3>Launch it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Launch it Curabitur...	31
1910	69	28	14	json	[{"pk": 28, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:10.963", "language": "en", "parent": 27, "numchild": 0, "creation_date": "2015-05-22T11:08:02.785", "depth": 5, "position": 0, "path": "00050007000200010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	28	28
1911	69	7	14	json	[{"pk": 7, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.642", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T11:00:04.937", "depth": 5, "position": 1, "path": "00020002000100010002", "placeholder": 2, "plugin_type": "TextPlugin"}}]	7	7
1912	69	29	64	json	[{"pk": 29, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_30\\" title=\\"Icon - fa-calendar\\"></p>\\n\\n<h3>Schedule it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Schedule it Curabitur...	29
1913	69	8	14	json	[{"pk": 8, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:22.155", "language": "en", "parent": 3, "numchild": 1, "creation_date": "2015-05-22T11:01:16.060", "depth": 2, "position": 1, "path": "00020002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	8	8
1914	69	30	14	json	[{"pk": 30, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:46.762", "language": "en", "parent": 29, "numchild": 0, "creation_date": "2015-05-22T11:08:35.830", "depth": 5, "position": 0, "path": "00050007000300010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	30	30
1915	69	31	14	json	[{"pk": 31, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:21.189", "language": "en", "parent": 24, "numchild": 1, "creation_date": "2015-05-22T11:09:03.312", "depth": 4, "position": 0, "path": "0005000700040001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	31	31
2084	72	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
1918	69	32	14	json	[{"pk": 32, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:19.976", "language": "en", "parent": 31, "numchild": 0, "creation_date": "2015-05-22T11:09:13.485", "depth": 5, "position": 0, "path": "00050007000400010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	32	32
1919	69	2	39	json	[{"pk": 2, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 1, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg)	2
1920	69	33	14	json	[{"pk": 33, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:42.411", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:09:38.604", "depth": 1, "position": 21, "path": "0007", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	33	33
1921	69	12	25	json	[{"pk": 12, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	12
1922	69	13	14	json	[{"pk": 13, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.655", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:01.806", "depth": 2, "position": 0, "path": "00050001", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	13	13
1923	69	22	14	json	[{"pk": 22, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.080", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.076", "depth": 3, "position": 1, "path": "000500070002", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	22	22
1924	69	14	14	json	[{"pk": 14, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.669", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:16.457", "depth": 2, "position": 2, "path": "00050002", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	14	14
1925	69	7	64	json	[{"pk": 7, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Explore your limits</h1>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada.<br>\\nNulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	Explore your limits...	7
1926	69	15	14	json	[{"pk": 15, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.662", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:28.907", "depth": 2, "position": 1, "path": "00050003", "placeholder": 3, "plugin_type": "TextPlugin"}}]	15	15
1927	69	3	25	json	[{"pk": 3, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-content", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: feature-content	3
1928	69	16	14	json	[{"pk": 16, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.676", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:47.410", "depth": 2, "position": 3, "path": "00050004", "placeholder": 3, "plugin_type": "TextPlugin"}}]	16	16
1929	69	17	44	json	[{"pk": 17, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	17
1930	69	17	14	json	[{"pk": 17, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.691", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:12.306", "depth": 2, "position": 4, "path": "00050008", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	17	17
1931	69	29	14	json	[{"pk": 29, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:48.535", "language": "en", "parent": 23, "numchild": 1, "creation_date": "2015-05-22T11:08:25.281", "depth": 4, "position": 0, "path": "0005000700030001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	29	29
1932	69	18	14	json	[{"pk": 18, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.683", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:30.146", "depth": 2, "position": 5, "path": "00050005", "placeholder": 3, "plugin_type": "TextPlugin"}}]	18	18
1933	69	19	14	json	[{"pk": 19, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.699", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:45.474", "depth": 2, "position": 6, "path": "00050006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	19	19
1934	69	25	14	json	[{"pk": 25, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:17.127", "language": "en", "parent": 21, "numchild": 1, "creation_date": "2015-05-22T11:06:36.687", "depth": 4, "position": 0, "path": "0005000700010001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	25	25
1935	69	20	14	json	[{"pk": 20, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.708", "language": "en", "parent": 12, "numchild": 4, "creation_date": "2015-05-22T11:06:05.640", "depth": 2, "position": 7, "path": "00050007", "placeholder": 3, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	20	20
1936	69	4	14	json	[{"pk": 4, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.651", "language": "en", "parent": 8, "numchild": 1, "creation_date": "2015-05-22T10:58:44.225", "depth": 3, "position": 0, "path": "000200020001", "placeholder": 2, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	4	4
1937	69	21	14	json	[{"pk": 21, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.070", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.067", "depth": 3, "position": 0, "path": "000500070001", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	21	21
1938	70	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "tpl_home.html", "placeholders": [2, 3], "changed_date": "2015-05-22T11:09:53.949", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
1940	70	3	14	json	[{"pk": 3, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:21.519", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:58:07.414", "depth": 1, "position": 2, "path": "0002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	3	3
1941	70	4	45	json	[{"pk": 4, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	1 column	4
1942	70	5	46	json	[{"pk": 5, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 24, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": null, "lg_pull": null, "xs_pull": null}}]	col-md-24 	5
1943	70	6	44	json	[{"pk": 6, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	6
1944	70	1	25	json	[{"pk": 1, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-visual", "padding_bottom": null, "additional_class_names": "", "label": "Visual", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Visual”: feature-visual	1
1945	70	8	25	json	[{"pk": 8, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "container", "padding_bottom": null, "additional_class_names": "", "label": "Grid", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Grid”: container	8
1946	70	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
1947	70	23	14	json	[{"pk": 23, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.089", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.085", "depth": 3, "position": 2, "path": "000500070003", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	23	23
1948	70	12	14	json	[{"pk": 12, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:03:47.125", "language": "en", "parent": null, "numchild": 8, "creation_date": "2015-05-22T11:03:41.457", "depth": 1, "position": 0, "path": "0005", "placeholder": 3, "plugin_type": "StylePlugin"}}]	12	12
1949	70	2	14	json	[{"pk": 2, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:57:32.263", "language": "en", "parent": 1, "numchild": 0, "creation_date": "2015-05-22T10:56:32.155", "depth": 2, "position": 0, "path": "00010001", "placeholder": 2, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	2	2
1950	70	14	44	json	[{"pk": 14, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	14
1951	70	15	64	json	[{"pk": 15, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>The Next Giant Leap For Mankind</h1>\\n\\n<p class=\\"lead\\">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	The Next Giant...	15
1952	70	16	64	json	[{"pk": 16, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<hr>"}}]		16
1953	70	24	14	json	[{"pk": 24, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.097", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.094", "depth": 3, "position": 3, "path": "000500070004", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	24	24
1954	70	18	64	json	[{"pk": 18, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>How do you reach new limits?</h2>\\n"}}]	How do you...	18
1955	70	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
1956	70	20	45	json	[{"pk": 20, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	4 columns	20
1957	70	21	46	json	[{"pk": 21, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	21
1958	70	22	46	json	[{"pk": 22, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	22
1959	70	23	46	json	[{"pk": 23, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	23
1960	70	24	46	json	[{"pk": 24, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	24
1961	70	25	64	json	[{"pk": 25, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_26\\" title=\\"Icon - fa-crosshairs\\"></p>\\n\\n<h3>Set your goals</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Set your goals...	25
1962	70	26	35	json	[{"pk": 26, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-crosshairs"}}]	fa-crosshairs	26
1963	70	27	64	json	[{"pk": 27, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_28\\" title=\\"Icon - fa-thumb-tack\\"></p>\\n\\n<h3>Believe in yourself</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Believe in yourself...	27
1964	70	28	35	json	[{"pk": 28, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-thumb-tack"}}]	fa-thumb-tack	28
1965	70	26	14	json	[{"pk": 26, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:12.797", "language": "en", "parent": 25, "numchild": 0, "creation_date": "2015-05-22T11:06:50.389", "depth": 5, "position": 0, "path": "00050007000100010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	26	26
1966	70	30	35	json	[{"pk": 30, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-calendar"}}]	fa-calendar	30
1967	70	5	14	json	[{"pk": 5, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.635", "language": "en", "parent": 4, "numchild": 2, "creation_date": "2015-05-22T10:59:10.499", "depth": 4, "position": 0, "path": "0002000200010001", "placeholder": 2, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	5	5
1968	70	32	35	json	[{"pk": 32, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-rocket"}}]	fa-rocket	32
1969	70	33	44	json	[{"pk": 33, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	33
1970	70	27	14	json	[{"pk": 27, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:12.441", "language": "en", "parent": 22, "numchild": 1, "creation_date": "2015-05-22T11:07:50.132", "depth": 4, "position": 0, "path": "0005000700020001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	27	27
1971	70	1	14	json	[{"pk": 1, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:31.719", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:56:01.162", "depth": 1, "position": 0, "path": "0001", "placeholder": 2, "plugin_type": "StylePlugin"}}]	1	1
1972	70	6	14	json	[{"pk": 6, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.638", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T10:59:50.854", "depth": 5, "position": 0, "path": "00020002000100010001", "placeholder": 2, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	6	6
1973	70	31	64	json	[{"pk": 31, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_32\\" title=\\"Icon - fa-rocket\\"></p>\\n\\n<h3>Launch it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Launch it Curabitur...	31
1974	70	28	14	json	[{"pk": 28, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:10.963", "language": "en", "parent": 27, "numchild": 0, "creation_date": "2015-05-22T11:08:02.785", "depth": 5, "position": 0, "path": "00050007000200010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	28	28
1975	70	7	14	json	[{"pk": 7, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.642", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T11:00:04.937", "depth": 5, "position": 1, "path": "00020002000100010002", "placeholder": 2, "plugin_type": "TextPlugin"}}]	7	7
1976	70	29	64	json	[{"pk": 29, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_30\\" title=\\"Icon - fa-calendar\\"></p>\\n\\n<h3>Schedule it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Schedule it Curabitur...	29
1977	70	8	14	json	[{"pk": 8, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:22.155", "language": "en", "parent": 3, "numchild": 1, "creation_date": "2015-05-22T11:01:16.060", "depth": 2, "position": 1, "path": "00020002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	8	8
1978	70	30	14	json	[{"pk": 30, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:46.762", "language": "en", "parent": 29, "numchild": 0, "creation_date": "2015-05-22T11:08:35.830", "depth": 5, "position": 0, "path": "00050007000300010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	30	30
1979	70	31	14	json	[{"pk": 31, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:21.189", "language": "en", "parent": 24, "numchild": 1, "creation_date": "2015-05-22T11:09:03.312", "depth": 4, "position": 0, "path": "0005000700040001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	31	31
1980	70	13	44	json	[{"pk": 13, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	13
1981	70	19	44	json	[{"pk": 19, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	19
1982	70	32	14	json	[{"pk": 32, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:19.976", "language": "en", "parent": 31, "numchild": 0, "creation_date": "2015-05-22T11:09:13.485", "depth": 5, "position": 0, "path": "00050007000400010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	32	32
1983	70	2	39	json	[{"pk": 2, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 1, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg)	2
1984	70	33	14	json	[{"pk": 33, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:14:41.317", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:09:38.604", "depth": 1, "position": 21, "path": "0007", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	33	33
1985	70	12	25	json	[{"pk": 12, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	12
1986	70	13	14	json	[{"pk": 13, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.655", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:01.806", "depth": 2, "position": 0, "path": "00050001", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	13	13
1987	70	22	14	json	[{"pk": 22, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.080", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.076", "depth": 3, "position": 1, "path": "000500070002", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	22	22
1988	70	14	14	json	[{"pk": 14, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.669", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:16.457", "depth": 2, "position": 2, "path": "00050002", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	14	14
1989	70	7	64	json	[{"pk": 7, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Explore your limits</h1>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada.<br>\\nNulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	Explore your limits...	7
1990	70	15	14	json	[{"pk": 15, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.662", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:28.907", "depth": 2, "position": 1, "path": "00050003", "placeholder": 3, "plugin_type": "TextPlugin"}}]	15	15
1991	70	3	25	json	[{"pk": 3, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-content", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: feature-content	3
1992	70	16	14	json	[{"pk": 16, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.676", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:47.410", "depth": 2, "position": 3, "path": "00050004", "placeholder": 3, "plugin_type": "TextPlugin"}}]	16	16
1993	70	17	44	json	[{"pk": 17, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	17
1994	70	17	14	json	[{"pk": 17, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.691", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:12.306", "depth": 2, "position": 4, "path": "00050008", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	17	17
1995	70	29	14	json	[{"pk": 29, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:48.535", "language": "en", "parent": 23, "numchild": 1, "creation_date": "2015-05-22T11:08:25.281", "depth": 4, "position": 0, "path": "0005000700030001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	29	29
1996	70	18	14	json	[{"pk": 18, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.683", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:30.146", "depth": 2, "position": 5, "path": "00050005", "placeholder": 3, "plugin_type": "TextPlugin"}}]	18	18
1997	70	19	14	json	[{"pk": 19, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.699", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:45.474", "depth": 2, "position": 6, "path": "00050006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	19	19
1998	70	25	14	json	[{"pk": 25, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:17.127", "language": "en", "parent": 21, "numchild": 1, "creation_date": "2015-05-22T11:06:36.687", "depth": 4, "position": 0, "path": "0005000700010001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	25	25
1999	70	20	14	json	[{"pk": 20, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.708", "language": "en", "parent": 12, "numchild": 4, "creation_date": "2015-05-22T11:06:05.640", "depth": 2, "position": 7, "path": "00050007", "placeholder": 3, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	20	20
2000	70	4	14	json	[{"pk": 4, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.651", "language": "en", "parent": 8, "numchild": 1, "creation_date": "2015-05-22T10:58:44.225", "depth": 3, "position": 0, "path": "000200020001", "placeholder": 2, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	4	4
2001	70	21	14	json	[{"pk": 21, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.070", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.067", "depth": 3, "position": 0, "path": "000500070001", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	21	21
2002	71	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "tpl_home.html", "placeholders": [2, 3], "changed_date": "2015-05-22T11:14:41.516", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
2003	71	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
2004	71	3	14	json	[{"pk": 3, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:21.519", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:58:07.414", "depth": 1, "position": 2, "path": "0002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	3	3
2005	71	4	45	json	[{"pk": 4, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	1 column	4
2006	71	5	46	json	[{"pk": 5, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 24, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": null, "lg_pull": null, "xs_pull": null}}]	col-md-24 	5
2007	71	6	44	json	[{"pk": 6, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	6
2008	71	1	25	json	[{"pk": 1, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-visual", "padding_bottom": null, "additional_class_names": "", "label": "Visual", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Visual”: feature-visual	1
2009	71	8	25	json	[{"pk": 8, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "container", "padding_bottom": null, "additional_class_names": "", "label": "Grid", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Grid”: container	8
2010	71	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
2085	72	20	45	json	[{"pk": 20, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	4 columns	20
2011	71	23	14	json	[{"pk": 23, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.089", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.085", "depth": 3, "position": 2, "path": "000500070003", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	23	23
2012	71	12	14	json	[{"pk": 12, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:03:47.125", "language": "en", "parent": null, "numchild": 8, "creation_date": "2015-05-22T11:03:41.457", "depth": 1, "position": 0, "path": "0005", "placeholder": 3, "plugin_type": "StylePlugin"}}]	12	12
2013	71	2	14	json	[{"pk": 2, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:57:32.263", "language": "en", "parent": 1, "numchild": 0, "creation_date": "2015-05-22T10:56:32.155", "depth": 2, "position": 0, "path": "00010001", "placeholder": 2, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	2	2
2014	71	14	44	json	[{"pk": 14, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	14
2015	71	15	64	json	[{"pk": 15, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>The Next Giant Leap For Mankind</h1>\\n\\n<p class=\\"lead\\">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	The Next Giant...	15
2016	71	16	64	json	[{"pk": 16, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<hr>"}}]		16
2017	71	24	14	json	[{"pk": 24, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.097", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.094", "depth": 3, "position": 3, "path": "000500070004", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	24	24
2018	71	18	64	json	[{"pk": 18, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>How do you reach new limits?</h2>\\n"}}]	How do you...	18
2019	71	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
2020	71	20	45	json	[{"pk": 20, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	4 columns	20
2021	71	21	46	json	[{"pk": 21, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	21
2022	71	22	46	json	[{"pk": 22, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	22
2023	71	23	46	json	[{"pk": 23, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	23
2024	71	24	46	json	[{"pk": 24, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	24
2025	71	25	64	json	[{"pk": 25, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_26\\" title=\\"Icon - fa-crosshairs\\"></p>\\n\\n<h3>Set your goals</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Set your goals...	25
2026	71	26	35	json	[{"pk": 26, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-crosshairs"}}]	fa-crosshairs	26
2027	71	27	64	json	[{"pk": 27, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_28\\" title=\\"Icon - fa-thumb-tack\\"></p>\\n\\n<h3>Believe in yourself</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Believe in yourself...	27
2028	71	28	35	json	[{"pk": 28, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-thumb-tack"}}]	fa-thumb-tack	28
2029	71	26	14	json	[{"pk": 26, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:12.797", "language": "en", "parent": 25, "numchild": 0, "creation_date": "2015-05-22T11:06:50.389", "depth": 5, "position": 0, "path": "00050007000100010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	26	26
2030	71	30	35	json	[{"pk": 30, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-calendar"}}]	fa-calendar	30
2031	71	5	14	json	[{"pk": 5, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.635", "language": "en", "parent": 4, "numchild": 2, "creation_date": "2015-05-22T10:59:10.499", "depth": 4, "position": 0, "path": "0002000200010001", "placeholder": 2, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	5	5
2032	71	32	35	json	[{"pk": 32, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-rocket"}}]	fa-rocket	32
2033	71	33	44	json	[{"pk": 33, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	33
2034	71	34	14	json	[{"pk": 34, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:14:56.996", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:14:56.992", "depth": 1, "position": 22, "path": "0008", "placeholder": 3, "plugin_type": "StylePlugin"}}]	34	34
2035	71	27	14	json	[{"pk": 27, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:12.441", "language": "en", "parent": 22, "numchild": 1, "creation_date": "2015-05-22T11:07:50.132", "depth": 4, "position": 0, "path": "0005000700020001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	27	27
2036	71	1	14	json	[{"pk": 1, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:31.719", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:56:01.162", "depth": 1, "position": 0, "path": "0001", "placeholder": 2, "plugin_type": "StylePlugin"}}]	1	1
2037	71	6	14	json	[{"pk": 6, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.638", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T10:59:50.854", "depth": 5, "position": 0, "path": "00020002000100010001", "placeholder": 2, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	6	6
2038	71	31	64	json	[{"pk": 31, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_32\\" title=\\"Icon - fa-rocket\\"></p>\\n\\n<h3>Launch it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Launch it Curabitur...	31
2039	71	28	14	json	[{"pk": 28, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:10.963", "language": "en", "parent": 27, "numchild": 0, "creation_date": "2015-05-22T11:08:02.785", "depth": 5, "position": 0, "path": "00050007000200010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	28	28
2040	71	7	14	json	[{"pk": 7, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.642", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T11:00:04.937", "depth": 5, "position": 1, "path": "00020002000100010002", "placeholder": 2, "plugin_type": "TextPlugin"}}]	7	7
2041	71	29	64	json	[{"pk": 29, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_30\\" title=\\"Icon - fa-calendar\\"></p>\\n\\n<h3>Schedule it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Schedule it Curabitur...	29
2042	71	8	14	json	[{"pk": 8, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:22.155", "language": "en", "parent": 3, "numchild": 1, "creation_date": "2015-05-22T11:01:16.060", "depth": 2, "position": 1, "path": "00020002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	8	8
2043	71	30	14	json	[{"pk": 30, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:46.762", "language": "en", "parent": 29, "numchild": 0, "creation_date": "2015-05-22T11:08:35.830", "depth": 5, "position": 0, "path": "00050007000300010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	30	30
2044	71	31	14	json	[{"pk": 31, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:21.189", "language": "en", "parent": 24, "numchild": 1, "creation_date": "2015-05-22T11:09:03.312", "depth": 4, "position": 0, "path": "0005000700040001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	31	31
2045	71	13	44	json	[{"pk": 13, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	13
2046	71	19	44	json	[{"pk": 19, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	19
2047	71	32	14	json	[{"pk": 32, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:19.976", "language": "en", "parent": 31, "numchild": 0, "creation_date": "2015-05-22T11:09:13.485", "depth": 5, "position": 0, "path": "00050007000400010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	32	32
2048	71	2	39	json	[{"pk": 2, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 1, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg)	2
2049	71	33	14	json	[{"pk": 33, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:14:41.317", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:09:38.604", "depth": 1, "position": 21, "path": "0007", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	33	33
2050	71	12	25	json	[{"pk": 12, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	12
2051	71	13	14	json	[{"pk": 13, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.655", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:01.806", "depth": 2, "position": 0, "path": "00050001", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	13	13
2052	71	22	14	json	[{"pk": 22, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.080", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.076", "depth": 3, "position": 1, "path": "000500070002", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	22	22
2053	71	14	14	json	[{"pk": 14, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.669", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:16.457", "depth": 2, "position": 2, "path": "00050002", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	14	14
2054	71	7	64	json	[{"pk": 7, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Explore your limits</h1>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada.<br>\\nNulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	Explore your limits...	7
2055	71	15	14	json	[{"pk": 15, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.662", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:28.907", "depth": 2, "position": 1, "path": "00050003", "placeholder": 3, "plugin_type": "TextPlugin"}}]	15	15
2056	71	3	25	json	[{"pk": 3, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-content", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: feature-content	3
2057	71	16	14	json	[{"pk": 16, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.676", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:47.410", "depth": 2, "position": 3, "path": "00050004", "placeholder": 3, "plugin_type": "TextPlugin"}}]	16	16
2058	71	17	44	json	[{"pk": 17, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	17
2059	71	17	14	json	[{"pk": 17, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.691", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:12.306", "depth": 2, "position": 4, "path": "00050008", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	17	17
2060	71	29	14	json	[{"pk": 29, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:48.535", "language": "en", "parent": 23, "numchild": 1, "creation_date": "2015-05-22T11:08:25.281", "depth": 4, "position": 0, "path": "0005000700030001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	29	29
2061	71	18	14	json	[{"pk": 18, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.683", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:30.146", "depth": 2, "position": 5, "path": "00050005", "placeholder": 3, "plugin_type": "TextPlugin"}}]	18	18
2062	71	19	14	json	[{"pk": 19, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.699", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:45.474", "depth": 2, "position": 6, "path": "00050006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	19	19
2063	71	25	14	json	[{"pk": 25, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:17.127", "language": "en", "parent": 21, "numchild": 1, "creation_date": "2015-05-22T11:06:36.687", "depth": 4, "position": 0, "path": "0005000700010001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	25	25
2064	71	20	14	json	[{"pk": 20, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.708", "language": "en", "parent": 12, "numchild": 4, "creation_date": "2015-05-22T11:06:05.640", "depth": 2, "position": 7, "path": "00050007", "placeholder": 3, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	20	20
2065	71	4	14	json	[{"pk": 4, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.651", "language": "en", "parent": 8, "numchild": 1, "creation_date": "2015-05-22T10:58:44.225", "depth": 3, "position": 0, "path": "000200020001", "placeholder": 2, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	4	4
2066	71	21	14	json	[{"pk": 21, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.070", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.067", "depth": 3, "position": 0, "path": "000500070001", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	21	21
2067	72	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "tpl_home.html", "placeholders": [2, 3], "changed_date": "2015-05-22T11:14:57.204", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
2068	72	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
2069	72	3	14	json	[{"pk": 3, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:21.519", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:58:07.414", "depth": 1, "position": 2, "path": "0002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	3	3
2070	72	4	45	json	[{"pk": 4, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	1 column	4
2192	73	17	14	json	[{"pk": 17, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.691", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:12.306", "depth": 2, "position": 4, "path": "00050008", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	17	17
2071	72	5	46	json	[{"pk": 5, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 24, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": null, "lg_pull": null, "xs_pull": null}}]	col-md-24 	5
2072	72	6	44	json	[{"pk": 6, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	6
2073	72	1	25	json	[{"pk": 1, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-visual", "padding_bottom": null, "additional_class_names": "", "label": "Visual", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Visual”: feature-visual	1
2074	72	8	25	json	[{"pk": 8, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "container", "padding_bottom": null, "additional_class_names": "", "label": "Grid", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Grid”: container	8
2075	72	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
2076	72	23	14	json	[{"pk": 23, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.089", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.085", "depth": 3, "position": 2, "path": "000500070003", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	23	23
2077	72	12	14	json	[{"pk": 12, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:03:47.125", "language": "en", "parent": null, "numchild": 8, "creation_date": "2015-05-22T11:03:41.457", "depth": 1, "position": 0, "path": "0005", "placeholder": 3, "plugin_type": "StylePlugin"}}]	12	12
2078	72	2	14	json	[{"pk": 2, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:57:32.263", "language": "en", "parent": 1, "numchild": 0, "creation_date": "2015-05-22T10:56:32.155", "depth": 2, "position": 0, "path": "00010001", "placeholder": 2, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	2	2
2079	72	14	44	json	[{"pk": 14, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	14
2080	72	15	64	json	[{"pk": 15, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>The Next Giant Leap For Mankind</h1>\\n\\n<p class=\\"lead\\">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	The Next Giant...	15
2081	72	16	64	json	[{"pk": 16, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<hr>"}}]		16
2082	72	24	14	json	[{"pk": 24, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.097", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.094", "depth": 3, "position": 3, "path": "000500070004", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	24	24
2086	72	21	46	json	[{"pk": 21, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	21
2087	72	22	46	json	[{"pk": 22, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	22
2088	72	23	46	json	[{"pk": 23, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	23
2089	72	24	46	json	[{"pk": 24, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	24
2090	72	25	64	json	[{"pk": 25, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_26\\" title=\\"Icon - fa-crosshairs\\"></p>\\n\\n<h3>Set your goals</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Set your goals...	25
2091	72	26	35	json	[{"pk": 26, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-crosshairs"}}]	fa-crosshairs	26
2092	72	27	64	json	[{"pk": 27, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_28\\" title=\\"Icon - fa-thumb-tack\\"></p>\\n\\n<h3>Believe in yourself</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Believe in yourself...	27
2093	72	28	35	json	[{"pk": 28, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-thumb-tack"}}]	fa-thumb-tack	28
2094	72	26	14	json	[{"pk": 26, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:12.797", "language": "en", "parent": 25, "numchild": 0, "creation_date": "2015-05-22T11:06:50.389", "depth": 5, "position": 0, "path": "00050007000100010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	26	26
2095	72	30	35	json	[{"pk": 30, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-calendar"}}]	fa-calendar	30
2096	72	5	14	json	[{"pk": 5, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.635", "language": "en", "parent": 4, "numchild": 2, "creation_date": "2015-05-22T10:59:10.499", "depth": 4, "position": 0, "path": "0002000200010001", "placeholder": 2, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	5	5
2097	72	32	35	json	[{"pk": 32, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-rocket"}}]	fa-rocket	32
2099	72	34	25	json	[{"pk": 34, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "section-cyan", "padding_bottom": null, "additional_class_names": "", "label": "Section", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Section”: section-cyan	34
2100	72	27	14	json	[{"pk": 27, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:12.441", "language": "en", "parent": 22, "numchild": 1, "creation_date": "2015-05-22T11:07:50.132", "depth": 4, "position": 0, "path": "0005000700020001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	27	27
2101	72	1	14	json	[{"pk": 1, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:31.719", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:56:01.162", "depth": 1, "position": 0, "path": "0001", "placeholder": 2, "plugin_type": "StylePlugin"}}]	1	1
2102	72	6	14	json	[{"pk": 6, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.638", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T10:59:50.854", "depth": 5, "position": 0, "path": "00020002000100010001", "placeholder": 2, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	6	6
2103	72	31	64	json	[{"pk": 31, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_32\\" title=\\"Icon - fa-rocket\\"></p>\\n\\n<h3>Launch it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Launch it Curabitur...	31
2104	72	28	14	json	[{"pk": 28, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:10.963", "language": "en", "parent": 27, "numchild": 0, "creation_date": "2015-05-22T11:08:02.785", "depth": 5, "position": 0, "path": "00050007000200010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	28	28
2105	72	7	14	json	[{"pk": 7, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.642", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T11:00:04.937", "depth": 5, "position": 1, "path": "00020002000100010002", "placeholder": 2, "plugin_type": "TextPlugin"}}]	7	7
2106	72	29	64	json	[{"pk": 29, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_30\\" title=\\"Icon - fa-calendar\\"></p>\\n\\n<h3>Schedule it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Schedule it Curabitur...	29
2107	72	8	14	json	[{"pk": 8, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:22.155", "language": "en", "parent": 3, "numchild": 1, "creation_date": "2015-05-22T11:01:16.060", "depth": 2, "position": 1, "path": "00020002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	8	8
2108	72	30	14	json	[{"pk": 30, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:46.762", "language": "en", "parent": 29, "numchild": 0, "creation_date": "2015-05-22T11:08:35.830", "depth": 5, "position": 0, "path": "00050007000300010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	30	30
2109	72	31	14	json	[{"pk": 31, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:21.189", "language": "en", "parent": 24, "numchild": 1, "creation_date": "2015-05-22T11:09:03.312", "depth": 4, "position": 0, "path": "0005000700040001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	31	31
2110	72	13	44	json	[{"pk": 13, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	13
2111	72	19	44	json	[{"pk": 19, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	19
2112	72	32	14	json	[{"pk": 32, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:19.976", "language": "en", "parent": 31, "numchild": 0, "creation_date": "2015-05-22T11:09:13.485", "depth": 5, "position": 0, "path": "00050007000400010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	32	32
2113	72	2	39	json	[{"pk": 2, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 1, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg)	2
2114	72	33	14	json	[{"pk": 33, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:14:41.317", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:09:38.604", "depth": 1, "position": 21, "path": "0007", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	33	33
2115	72	12	25	json	[{"pk": 12, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	12
2116	72	34	14	json	[{"pk": 34, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:15:03.949", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:14:56.992", "depth": 1, "position": 22, "path": "0008", "placeholder": 3, "plugin_type": "StylePlugin"}}]	34	34
2117	72	13	14	json	[{"pk": 13, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.655", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:01.806", "depth": 2, "position": 0, "path": "00050001", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	13	13
2118	72	22	14	json	[{"pk": 22, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.080", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.076", "depth": 3, "position": 1, "path": "000500070002", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	22	22
2119	72	14	14	json	[{"pk": 14, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.669", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:16.457", "depth": 2, "position": 2, "path": "00050002", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	14	14
2120	72	7	64	json	[{"pk": 7, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Explore your limits</h1>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada.<br>\\nNulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	Explore your limits...	7
2121	72	15	14	json	[{"pk": 15, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.662", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:28.907", "depth": 2, "position": 1, "path": "00050003", "placeholder": 3, "plugin_type": "TextPlugin"}}]	15	15
2122	72	3	25	json	[{"pk": 3, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-content", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: feature-content	3
2123	72	16	14	json	[{"pk": 16, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.676", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:47.410", "depth": 2, "position": 3, "path": "00050004", "placeholder": 3, "plugin_type": "TextPlugin"}}]	16	16
2124	72	17	44	json	[{"pk": 17, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	17
2125	72	17	14	json	[{"pk": 17, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.691", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:12.306", "depth": 2, "position": 4, "path": "00050008", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	17	17
2126	72	29	14	json	[{"pk": 29, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:48.535", "language": "en", "parent": 23, "numchild": 1, "creation_date": "2015-05-22T11:08:25.281", "depth": 4, "position": 0, "path": "0005000700030001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	29	29
2127	72	18	14	json	[{"pk": 18, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.683", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:30.146", "depth": 2, "position": 5, "path": "00050005", "placeholder": 3, "plugin_type": "TextPlugin"}}]	18	18
2128	72	19	14	json	[{"pk": 19, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.699", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:45.474", "depth": 2, "position": 6, "path": "00050006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	19	19
2129	72	25	14	json	[{"pk": 25, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:17.127", "language": "en", "parent": 21, "numchild": 1, "creation_date": "2015-05-22T11:06:36.687", "depth": 4, "position": 0, "path": "0005000700010001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	25	25
2130	72	20	14	json	[{"pk": 20, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.708", "language": "en", "parent": 12, "numchild": 4, "creation_date": "2015-05-22T11:06:05.640", "depth": 2, "position": 7, "path": "00050007", "placeholder": 3, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	20	20
2131	72	4	14	json	[{"pk": 4, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.651", "language": "en", "parent": 8, "numchild": 1, "creation_date": "2015-05-22T10:58:44.225", "depth": 3, "position": 0, "path": "000200020001", "placeholder": 2, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	4	4
2132	72	21	14	json	[{"pk": 21, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.070", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.067", "depth": 3, "position": 0, "path": "000500070001", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	21	21
2133	73	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "tpl_home.html", "placeholders": [2, 3], "changed_date": "2015-05-22T11:15:04.140", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
2134	73	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
2135	73	3	14	json	[{"pk": 3, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:21.519", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:58:07.414", "depth": 1, "position": 2, "path": "0002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	3	3
2136	73	4	45	json	[{"pk": 4, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	1 column	4
2137	73	5	46	json	[{"pk": 5, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 24, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": null, "lg_pull": null, "xs_pull": null}}]	col-md-24 	5
2138	73	6	44	json	[{"pk": 6, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	6
2139	73	1	25	json	[{"pk": 1, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-visual", "padding_bottom": null, "additional_class_names": "", "label": "Visual", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Visual”: feature-visual	1
2140	73	8	25	json	[{"pk": 8, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "container", "padding_bottom": null, "additional_class_names": "", "label": "Grid", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Grid”: container	8
2141	73	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
2142	73	23	14	json	[{"pk": 23, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.089", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.085", "depth": 3, "position": 2, "path": "000500070003", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	23	23
2143	73	12	14	json	[{"pk": 12, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:03:47.125", "language": "en", "parent": null, "numchild": 8, "creation_date": "2015-05-22T11:03:41.457", "depth": 1, "position": 0, "path": "0005", "placeholder": 3, "plugin_type": "StylePlugin"}}]	12	12
2144	73	2	14	json	[{"pk": 2, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:57:32.263", "language": "en", "parent": 1, "numchild": 0, "creation_date": "2015-05-22T10:56:32.155", "depth": 2, "position": 0, "path": "00010001", "placeholder": 2, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	2	2
2146	73	15	64	json	[{"pk": 15, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>The Next Giant Leap For Mankind</h1>\\n\\n<p class=\\"lead\\">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	The Next Giant...	15
2147	73	16	64	json	[{"pk": 16, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<hr>"}}]		16
2148	73	24	14	json	[{"pk": 24, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.097", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.094", "depth": 3, "position": 3, "path": "000500070004", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	24	24
2149	73	18	64	json	[{"pk": 18, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>How do you reach new limits?</h2>\\n"}}]	How do you...	18
2150	73	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
2151	73	20	45	json	[{"pk": 20, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	4 columns	20
2152	73	21	46	json	[{"pk": 21, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	21
2153	73	22	46	json	[{"pk": 22, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	22
2154	73	23	46	json	[{"pk": 23, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	23
2270	75	3	14	json	[{"pk": 3, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:21.519", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:58:07.414", "depth": 1, "position": 2, "path": "0002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	3	3
2155	73	24	46	json	[{"pk": 24, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	24
2156	73	25	64	json	[{"pk": 25, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_26\\" title=\\"Icon - fa-crosshairs\\"></p>\\n\\n<h3>Set your goals</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Set your goals...	25
2157	73	26	35	json	[{"pk": 26, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-crosshairs"}}]	fa-crosshairs	26
2158	73	27	64	json	[{"pk": 27, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_28\\" title=\\"Icon - fa-thumb-tack\\"></p>\\n\\n<h3>Believe in yourself</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Believe in yourself...	27
2159	73	28	35	json	[{"pk": 28, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-thumb-tack"}}]	fa-thumb-tack	28
2160	73	26	14	json	[{"pk": 26, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:12.797", "language": "en", "parent": 25, "numchild": 0, "creation_date": "2015-05-22T11:06:50.389", "depth": 5, "position": 0, "path": "00050007000100010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	26	26
2161	73	30	35	json	[{"pk": 30, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-calendar"}}]	fa-calendar	30
2162	73	5	14	json	[{"pk": 5, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.635", "language": "en", "parent": 4, "numchild": 2, "creation_date": "2015-05-22T10:59:10.499", "depth": 4, "position": 0, "path": "0002000200010001", "placeholder": 2, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	5	5
2163	73	32	35	json	[{"pk": 32, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-rocket"}}]	fa-rocket	32
2164	73	33	44	json	[{"pk": 33, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	33
2165	73	34	25	json	[{"pk": 34, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "section-cyan", "padding_bottom": null, "additional_class_names": "", "label": "Section", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Section”: section-cyan	34
2166	73	27	14	json	[{"pk": 27, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:12.441", "language": "en", "parent": 22, "numchild": 1, "creation_date": "2015-05-22T11:07:50.132", "depth": 4, "position": 0, "path": "0005000700020001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	27	27
2167	73	1	14	json	[{"pk": 1, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:31.719", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:56:01.162", "depth": 1, "position": 0, "path": "0001", "placeholder": 2, "plugin_type": "StylePlugin"}}]	1	1
2168	73	6	14	json	[{"pk": 6, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.638", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T10:59:50.854", "depth": 5, "position": 0, "path": "00020002000100010001", "placeholder": 2, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	6	6
2169	73	31	64	json	[{"pk": 31, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_32\\" title=\\"Icon - fa-rocket\\"></p>\\n\\n<h3>Launch it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Launch it Curabitur...	31
2193	73	29	14	json	[{"pk": 29, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:48.535", "language": "en", "parent": 23, "numchild": 1, "creation_date": "2015-05-22T11:08:25.281", "depth": 4, "position": 0, "path": "0005000700030001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	29	29
2170	73	28	14	json	[{"pk": 28, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:10.963", "language": "en", "parent": 27, "numchild": 0, "creation_date": "2015-05-22T11:08:02.785", "depth": 5, "position": 0, "path": "00050007000200010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	28	28
2171	73	7	14	json	[{"pk": 7, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.642", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T11:00:04.937", "depth": 5, "position": 1, "path": "00020002000100010002", "placeholder": 2, "plugin_type": "TextPlugin"}}]	7	7
2172	73	29	64	json	[{"pk": 29, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_30\\" title=\\"Icon - fa-calendar\\"></p>\\n\\n<h3>Schedule it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Schedule it Curabitur...	29
2173	73	8	14	json	[{"pk": 8, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:22.155", "language": "en", "parent": 3, "numchild": 1, "creation_date": "2015-05-22T11:01:16.060", "depth": 2, "position": 1, "path": "00020002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	8	8
2174	73	30	14	json	[{"pk": 30, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:46.762", "language": "en", "parent": 29, "numchild": 0, "creation_date": "2015-05-22T11:08:35.830", "depth": 5, "position": 0, "path": "00050007000300010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	30	30
2175	73	31	14	json	[{"pk": 31, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:21.189", "language": "en", "parent": 24, "numchild": 1, "creation_date": "2015-05-22T11:09:03.312", "depth": 4, "position": 0, "path": "0005000700040001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	31	31
2176	73	13	44	json	[{"pk": 13, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	13
2177	73	19	44	json	[{"pk": 19, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	19
2178	73	32	14	json	[{"pk": 32, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:19.976", "language": "en", "parent": 31, "numchild": 0, "creation_date": "2015-05-22T11:09:13.485", "depth": 5, "position": 0, "path": "00050007000400010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	32	32
2223	74	25	64	json	[{"pk": 25, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_26\\" title=\\"Icon - fa-crosshairs\\"></p>\\n\\n<h3>Set your goals</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Set your goals...	25
2179	73	2	39	json	[{"pk": 2, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 1, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg)	2
2180	73	33	14	json	[{"pk": 33, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:14:41.317", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:09:38.604", "depth": 1, "position": 21, "path": "0007", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	33	33
2181	73	12	25	json	[{"pk": 12, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	12
2182	73	34	14	json	[{"pk": 34, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:15:03.949", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:14:56.992", "depth": 1, "position": 22, "path": "0008", "placeholder": 3, "plugin_type": "StylePlugin"}}]	34	34
2183	73	13	14	json	[{"pk": 13, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.655", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:01.806", "depth": 2, "position": 0, "path": "00050001", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	13	13
2184	73	22	14	json	[{"pk": 22, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.080", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.076", "depth": 3, "position": 1, "path": "000500070002", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	22	22
2185	73	35	14	json	[{"pk": 35, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:15:21.515", "language": "en", "parent": 34, "numchild": 0, "creation_date": "2015-05-22T11:15:21.507", "depth": 2, "position": 0, "path": "00080001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	35	35
2186	73	14	14	json	[{"pk": 14, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.669", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:16.457", "depth": 2, "position": 2, "path": "00050002", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	14	14
2187	73	7	64	json	[{"pk": 7, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Explore your limits</h1>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada.<br>\\nNulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	Explore your limits...	7
2188	73	15	14	json	[{"pk": 15, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.662", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:28.907", "depth": 2, "position": 1, "path": "00050003", "placeholder": 3, "plugin_type": "TextPlugin"}}]	15	15
2189	73	3	25	json	[{"pk": 3, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-content", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: feature-content	3
2190	73	16	14	json	[{"pk": 16, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.676", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:47.410", "depth": 2, "position": 3, "path": "00050004", "placeholder": 3, "plugin_type": "TextPlugin"}}]	16	16
2191	73	17	44	json	[{"pk": 17, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	17
2217	74	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
2194	73	18	14	json	[{"pk": 18, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.683", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:30.146", "depth": 2, "position": 5, "path": "00050005", "placeholder": 3, "plugin_type": "TextPlugin"}}]	18	18
2195	73	19	14	json	[{"pk": 19, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.699", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:45.474", "depth": 2, "position": 6, "path": "00050006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	19	19
2196	73	25	14	json	[{"pk": 25, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:17.127", "language": "en", "parent": 21, "numchild": 1, "creation_date": "2015-05-22T11:06:36.687", "depth": 4, "position": 0, "path": "0005000700010001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	25	25
2197	73	20	14	json	[{"pk": 20, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.708", "language": "en", "parent": 12, "numchild": 4, "creation_date": "2015-05-22T11:06:05.640", "depth": 2, "position": 7, "path": "00050007", "placeholder": 3, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	20	20
2198	73	4	14	json	[{"pk": 4, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.651", "language": "en", "parent": 8, "numchild": 1, "creation_date": "2015-05-22T10:58:44.225", "depth": 3, "position": 0, "path": "000200020001", "placeholder": 2, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	4	4
2199	73	21	14	json	[{"pk": 21, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.070", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.067", "depth": 3, "position": 0, "path": "000500070001", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	21	21
2224	74	26	35	json	[{"pk": 26, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-crosshairs"}}]	fa-crosshairs	26
2271	75	4	45	json	[{"pk": 4, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	1 column	4
2200	74	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "tpl_home.html", "placeholders": [2, 3], "changed_date": "2015-05-22T11:15:21.684", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
2201	74	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
2202	74	3	14	json	[{"pk": 3, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:21.519", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:58:07.414", "depth": 1, "position": 2, "path": "0002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	3	3
2203	74	4	45	json	[{"pk": 4, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	1 column	4
2204	74	5	46	json	[{"pk": 5, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 24, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": null, "lg_pull": null, "xs_pull": null}}]	col-md-24 	5
2205	74	6	44	json	[{"pk": 6, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	6
2206	74	1	25	json	[{"pk": 1, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-visual", "padding_bottom": null, "additional_class_names": "", "label": "Visual", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Visual”: feature-visual	1
2207	74	8	25	json	[{"pk": 8, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "container", "padding_bottom": null, "additional_class_names": "", "label": "Grid", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Grid”: container	8
2208	74	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
2209	74	23	14	json	[{"pk": 23, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.089", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.085", "depth": 3, "position": 2, "path": "000500070003", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	23	23
2210	74	12	14	json	[{"pk": 12, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:03:47.125", "language": "en", "parent": null, "numchild": 8, "creation_date": "2015-05-22T11:03:41.457", "depth": 1, "position": 0, "path": "0005", "placeholder": 3, "plugin_type": "StylePlugin"}}]	12	12
2211	74	2	14	json	[{"pk": 2, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:57:32.263", "language": "en", "parent": 1, "numchild": 0, "creation_date": "2015-05-22T10:56:32.155", "depth": 2, "position": 0, "path": "00010001", "placeholder": 2, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	2	2
2212	74	14	44	json	[{"pk": 14, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	14
2213	74	15	64	json	[{"pk": 15, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>The Next Giant Leap For Mankind</h1>\\n\\n<p class=\\"lead\\">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	The Next Giant...	15
2214	74	16	64	json	[{"pk": 16, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<hr>"}}]		16
2215	74	24	14	json	[{"pk": 24, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.097", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.094", "depth": 3, "position": 3, "path": "000500070004", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	24	24
2216	74	18	64	json	[{"pk": 18, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>How do you reach new limits?</h2>\\n"}}]	How do you...	18
2219	74	21	46	json	[{"pk": 21, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	21
2220	74	22	46	json	[{"pk": 22, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	22
2221	74	23	46	json	[{"pk": 23, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	23
2222	74	24	46	json	[{"pk": 24, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	24
2225	74	27	64	json	[{"pk": 27, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_28\\" title=\\"Icon - fa-thumb-tack\\"></p>\\n\\n<h3>Believe in yourself</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Believe in yourself...	27
2226	74	28	35	json	[{"pk": 28, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-thumb-tack"}}]	fa-thumb-tack	28
2227	74	26	14	json	[{"pk": 26, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:12.797", "language": "en", "parent": 25, "numchild": 0, "creation_date": "2015-05-22T11:06:50.389", "depth": 5, "position": 0, "path": "00050007000100010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	26	26
2228	74	30	35	json	[{"pk": 30, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-calendar"}}]	fa-calendar	30
2229	74	5	14	json	[{"pk": 5, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.635", "language": "en", "parent": 4, "numchild": 2, "creation_date": "2015-05-22T10:59:10.499", "depth": 4, "position": 0, "path": "0002000200010001", "placeholder": 2, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	5	5
2230	74	32	35	json	[{"pk": 32, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-rocket"}}]	fa-rocket	32
2231	74	33	44	json	[{"pk": 33, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	33
2232	74	34	25	json	[{"pk": 34, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "section-cyan", "padding_bottom": null, "additional_class_names": "", "label": "Section", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Section”: section-cyan	34
2233	74	27	14	json	[{"pk": 27, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:12.441", "language": "en", "parent": 22, "numchild": 1, "creation_date": "2015-05-22T11:07:50.132", "depth": 4, "position": 0, "path": "0005000700020001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	27	27
2234	74	1	14	json	[{"pk": 1, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:31.719", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:56:01.162", "depth": 1, "position": 0, "path": "0001", "placeholder": 2, "plugin_type": "StylePlugin"}}]	1	1
2235	74	6	14	json	[{"pk": 6, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.638", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T10:59:50.854", "depth": 5, "position": 0, "path": "00020002000100010001", "placeholder": 2, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	6	6
2236	74	35	64	json	[{"pk": 35, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>We fly you to new limits</h2>\\n\\n<h3>Build Your Mission</h3>\\n\\n<p>Lorem ipsum dolor sit amet, ius inani verear ut, eu pri nostro vulputate. In choro graece mea, vidisse molestie mei ea</p>\\n\\n<h3>Maintain Your Project</h3>\\n\\n<p>Lorem ipsum dolor sit amet, ius inani verear ut, eu pri nostro vulputate. In choro graece mea, vidisse molestie mei ea</p>\\n\\n<h3>You Make It Happen</h3>\\n\\n<p>Lorem ipsum dolor sit amet, ius inani verear ut, eu pri nostro vulputate. In choro graece mea, vidisse molestie mei ea</p>\\n"}}]	We fly you...	35
2237	74	31	64	json	[{"pk": 31, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_32\\" title=\\"Icon - fa-rocket\\"></p>\\n\\n<h3>Launch it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Launch it Curabitur...	31
2238	74	28	14	json	[{"pk": 28, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:10.963", "language": "en", "parent": 27, "numchild": 0, "creation_date": "2015-05-22T11:08:02.785", "depth": 5, "position": 0, "path": "00050007000200010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	28	28
2239	74	7	14	json	[{"pk": 7, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.642", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T11:00:04.937", "depth": 5, "position": 1, "path": "00020002000100010002", "placeholder": 2, "plugin_type": "TextPlugin"}}]	7	7
2240	74	29	64	json	[{"pk": 29, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_30\\" title=\\"Icon - fa-calendar\\"></p>\\n\\n<h3>Schedule it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Schedule it Curabitur...	29
2241	74	8	14	json	[{"pk": 8, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:22.155", "language": "en", "parent": 3, "numchild": 1, "creation_date": "2015-05-22T11:01:16.060", "depth": 2, "position": 1, "path": "00020002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	8	8
2242	74	30	14	json	[{"pk": 30, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:46.762", "language": "en", "parent": 29, "numchild": 0, "creation_date": "2015-05-22T11:08:35.830", "depth": 5, "position": 0, "path": "00050007000300010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	30	30
2243	74	31	14	json	[{"pk": 31, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:21.189", "language": "en", "parent": 24, "numchild": 1, "creation_date": "2015-05-22T11:09:03.312", "depth": 4, "position": 0, "path": "0005000700040001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	31	31
2244	74	13	44	json	[{"pk": 13, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	13
2245	74	19	44	json	[{"pk": 19, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	19
2246	74	32	14	json	[{"pk": 32, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:19.976", "language": "en", "parent": 31, "numchild": 0, "creation_date": "2015-05-22T11:09:13.485", "depth": 5, "position": 0, "path": "00050007000400010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	32	32
2247	74	2	39	json	[{"pk": 2, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 1, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg)	2
2248	74	33	14	json	[{"pk": 33, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:14:41.317", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:09:38.604", "depth": 1, "position": 21, "path": "0007", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	33	33
2249	74	12	25	json	[{"pk": 12, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	12
2250	74	34	14	json	[{"pk": 34, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:15:03.949", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:14:56.992", "depth": 1, "position": 22, "path": "0008", "placeholder": 3, "plugin_type": "StylePlugin"}}]	34	34
2251	74	13	14	json	[{"pk": 13, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.655", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:01.806", "depth": 2, "position": 0, "path": "00050001", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	13	13
2252	74	22	14	json	[{"pk": 22, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.080", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.076", "depth": 3, "position": 1, "path": "000500070002", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	22	22
2253	74	35	14	json	[{"pk": 35, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:15:26.376", "language": "en", "parent": 34, "numchild": 0, "creation_date": "2015-05-22T11:15:21.507", "depth": 2, "position": 0, "path": "00080001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	35	35
2254	74	14	14	json	[{"pk": 14, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.669", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:16.457", "depth": 2, "position": 2, "path": "00050002", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	14	14
2255	74	7	64	json	[{"pk": 7, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Explore your limits</h1>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada.<br>\\nNulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	Explore your limits...	7
2256	74	15	14	json	[{"pk": 15, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.662", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:28.907", "depth": 2, "position": 1, "path": "00050003", "placeholder": 3, "plugin_type": "TextPlugin"}}]	15	15
2257	74	3	25	json	[{"pk": 3, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-content", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: feature-content	3
2258	74	16	14	json	[{"pk": 16, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.676", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:47.410", "depth": 2, "position": 3, "path": "00050004", "placeholder": 3, "plugin_type": "TextPlugin"}}]	16	16
2259	74	17	44	json	[{"pk": 17, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	17
2260	74	17	14	json	[{"pk": 17, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.691", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:12.306", "depth": 2, "position": 4, "path": "00050008", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	17	17
2261	74	29	14	json	[{"pk": 29, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:48.535", "language": "en", "parent": 23, "numchild": 1, "creation_date": "2015-05-22T11:08:25.281", "depth": 4, "position": 0, "path": "0005000700030001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	29	29
2262	74	18	14	json	[{"pk": 18, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.683", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:30.146", "depth": 2, "position": 5, "path": "00050005", "placeholder": 3, "plugin_type": "TextPlugin"}}]	18	18
2263	74	19	14	json	[{"pk": 19, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.699", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:45.474", "depth": 2, "position": 6, "path": "00050006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	19	19
2264	74	25	14	json	[{"pk": 25, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:17.127", "language": "en", "parent": 21, "numchild": 1, "creation_date": "2015-05-22T11:06:36.687", "depth": 4, "position": 0, "path": "0005000700010001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	25	25
2265	74	20	14	json	[{"pk": 20, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.708", "language": "en", "parent": 12, "numchild": 4, "creation_date": "2015-05-22T11:06:05.640", "depth": 2, "position": 7, "path": "00050007", "placeholder": 3, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	20	20
2266	74	4	14	json	[{"pk": 4, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.651", "language": "en", "parent": 8, "numchild": 1, "creation_date": "2015-05-22T10:58:44.225", "depth": 3, "position": 0, "path": "000200020001", "placeholder": 2, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	4	4
2267	74	21	14	json	[{"pk": 21, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.070", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.067", "depth": 3, "position": 0, "path": "000500070001", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	21	21
2268	75	1	11	json	[{"pk": 1, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0001", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "tpl_home.html", "placeholders": [2, 3], "changed_date": "2015-05-22T11:15:26.567", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": true, "publication_date": "2015-05-22T10:53:16.088", "creation_date": "2015-05-22T10:53:15.887", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	Home	1
2269	75	2	13	json	[{"pk": 2, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	2
2272	75	5	46	json	[{"pk": 5, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 24, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": null, "lg_pull": null, "xs_pull": null}}]	col-md-24 	5
2273	75	6	44	json	[{"pk": 6, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	6
2274	75	1	25	json	[{"pk": 1, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-visual", "padding_bottom": null, "additional_class_names": "", "label": "Visual", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Visual”: feature-visual	1
2275	75	8	25	json	[{"pk": 8, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "container", "padding_bottom": null, "additional_class_names": "", "label": "Grid", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Grid”: container	8
2276	75	1	19	json	[{"pk": 1, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "Home", "has_url_overwrite": false, "redirect": null, "page": 1, "published": true, "path": "", "creation_date": "2015-05-22T10:53:15.998", "slug": "home"}}]	Home (home, en)	1
2277	75	23	14	json	[{"pk": 23, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.089", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.085", "depth": 3, "position": 2, "path": "000500070003", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	23	23
2278	75	12	14	json	[{"pk": 12, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:03:47.125", "language": "en", "parent": null, "numchild": 8, "creation_date": "2015-05-22T11:03:41.457", "depth": 1, "position": 0, "path": "0005", "placeholder": 3, "plugin_type": "StylePlugin"}}]	12	12
2279	75	2	14	json	[{"pk": 2, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:57:32.263", "language": "en", "parent": 1, "numchild": 0, "creation_date": "2015-05-22T10:56:32.155", "depth": 2, "position": 0, "path": "00010001", "placeholder": 2, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	2	2
2280	75	14	44	json	[{"pk": 14, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	14
2281	75	15	64	json	[{"pk": 15, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>The Next Giant Leap For Mankind</h1>\\n\\n<p class=\\"lead\\">Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	The Next Giant...	15
2282	75	16	64	json	[{"pk": 16, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<hr>"}}]		16
2283	75	24	14	json	[{"pk": 24, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.097", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.094", "depth": 3, "position": 3, "path": "000500070004", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	24	24
2284	75	18	64	json	[{"pk": 18, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>How do you reach new limits?</h2>\\n"}}]	How do you...	18
2285	75	3	13	json	[{"pk": 3, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	3
2286	75	20	45	json	[{"pk": 20, "model": "aldryn_bootstrap3.bootstrap3rowplugin", "fields": {"classes": ""}}]	4 columns	20
2287	75	21	46	json	[{"pk": 21, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	21
2288	75	22	46	json	[{"pk": 22, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	22
2289	75	23	46	json	[{"pk": 23, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	23
2290	75	24	46	json	[{"pk": 24, "model": "aldryn_bootstrap3.bootstrap3columnplugin", "fields": {"md_push": null, "md_pull": null, "lg_col": null, "xs_offset": null, "lg_push": null, "xs_push": null, "sm_offset": null, "tag": "div", "md_col": 6, "lg_offset": null, "classes": "", "sm_push": null, "md_offset": null, "xs_col": null, "sm_pull": null, "sm_col": 12, "lg_pull": null, "xs_pull": null}}]	col-sm-12 col-md-6 	24
2291	75	25	64	json	[{"pk": 25, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_26\\" title=\\"Icon - fa-crosshairs\\"></p>\\n\\n<h3>Set your goals</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Set your goals...	25
2292	75	26	35	json	[{"pk": 26, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-crosshairs"}}]	fa-crosshairs	26
2293	75	27	64	json	[{"pk": 27, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_28\\" title=\\"Icon - fa-thumb-tack\\"></p>\\n\\n<h3>Believe in yourself</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Believe in yourself...	27
2294	75	28	35	json	[{"pk": 28, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-thumb-tack"}}]	fa-thumb-tack	28
2295	75	26	14	json	[{"pk": 26, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:12.797", "language": "en", "parent": 25, "numchild": 0, "creation_date": "2015-05-22T11:06:50.389", "depth": 5, "position": 0, "path": "00050007000100010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	26	26
2296	75	30	35	json	[{"pk": 30, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-calendar"}}]	fa-calendar	30
2297	75	5	14	json	[{"pk": 5, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.635", "language": "en", "parent": 4, "numchild": 2, "creation_date": "2015-05-22T10:59:10.499", "depth": 4, "position": 0, "path": "0002000200010001", "placeholder": 2, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	5	5
2298	75	32	35	json	[{"pk": 32, "model": "aldryn_bootstrap3.boostrap3iconplugin", "fields": {"classes": "", "icon": "fa-rocket"}}]	fa-rocket	32
2299	75	33	44	json	[{"pk": 33, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	33
2300	75	34	25	json	[{"pk": 34, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "section-cyan", "padding_bottom": null, "additional_class_names": "text-center", "label": "Section", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Section”: section-cyan (text-center)	34
2301	75	27	14	json	[{"pk": 27, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:12.441", "language": "en", "parent": 22, "numchild": 1, "creation_date": "2015-05-22T11:07:50.132", "depth": 4, "position": 0, "path": "0005000700020001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	27	27
2302	75	1	14	json	[{"pk": 1, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T10:58:31.719", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T10:56:01.162", "depth": 1, "position": 0, "path": "0001", "placeholder": 2, "plugin_type": "StylePlugin"}}]	1	1
2303	75	6	14	json	[{"pk": 6, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.638", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T10:59:50.854", "depth": 5, "position": 0, "path": "00020002000100010001", "placeholder": 2, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	6	6
2304	75	35	64	json	[{"pk": 35, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h2>We fly you to new limits</h2>\\n\\n<h3>Build Your Mission</h3>\\n\\n<p>Lorem ipsum dolor sit amet, ius inani verear ut, eu pri nostro vulputate. In choro graece mea, vidisse molestie mei ea</p>\\n\\n<h3>Maintain Your Project</h3>\\n\\n<p>Lorem ipsum dolor sit amet, ius inani verear ut, eu pri nostro vulputate. In choro graece mea, vidisse molestie mei ea</p>\\n\\n<h3>You Make It Happen</h3>\\n\\n<p>Lorem ipsum dolor sit amet, ius inani verear ut, eu pri nostro vulputate. In choro graece mea, vidisse molestie mei ea</p>\\n"}}]	We fly you...	35
2305	75	31	64	json	[{"pk": 31, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_32\\" title=\\"Icon - fa-rocket\\"></p>\\n\\n<h3>Launch it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Launch it Curabitur...	31
2306	75	28	14	json	[{"pk": 28, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:10.963", "language": "en", "parent": 27, "numchild": 0, "creation_date": "2015-05-22T11:08:02.785", "depth": 5, "position": 0, "path": "00050007000200010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	28	28
2307	75	7	14	json	[{"pk": 7, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.642", "language": "en", "parent": 5, "numchild": 0, "creation_date": "2015-05-22T11:00:04.937", "depth": 5, "position": 1, "path": "00020002000100010002", "placeholder": 2, "plugin_type": "TextPlugin"}}]	7	7
2308	75	29	64	json	[{"pk": 29, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<p class=\\"icon-rounded\\"><img alt=\\"Icon\\" id=\\"plugin_obj_30\\" title=\\"Icon - fa-calendar\\"></p>\\n\\n<h3>Schedule it</h3>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.</p>\\n"}}]	Schedule it Curabitur...	29
2309	75	8	14	json	[{"pk": 8, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:22.155", "language": "en", "parent": 3, "numchild": 1, "creation_date": "2015-05-22T11:01:16.060", "depth": 2, "position": 1, "path": "00020002", "placeholder": 2, "plugin_type": "StylePlugin"}}]	8	8
2310	75	30	14	json	[{"pk": 30, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:46.762", "language": "en", "parent": 29, "numchild": 0, "creation_date": "2015-05-22T11:08:35.830", "depth": 5, "position": 0, "path": "00050007000300010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	30	30
2311	75	31	14	json	[{"pk": 31, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:21.189", "language": "en", "parent": 24, "numchild": 1, "creation_date": "2015-05-22T11:09:03.312", "depth": 4, "position": 0, "path": "0005000700040001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	31	31
2312	75	13	44	json	[{"pk": 13, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	13
2313	75	19	44	json	[{"pk": 19, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "md"}}]	size-md 	19
2314	75	32	14	json	[{"pk": 32, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:19.976", "language": "en", "parent": 31, "numchild": 0, "creation_date": "2015-05-22T11:09:13.485", "depth": 5, "position": 0, "path": "00050007000400010001", "placeholder": 3, "plugin_type": "Bootstrap3IconCMSPlugin"}}]	32	32
2315	75	2	39	json	[{"pk": 2, "model": "aldryn_bootstrap3.boostrap3imageplugin", "fields": {"title": "", "img_responsive": true, "shape": "", "classes": "", "file": 1, "aspect_ratio": "", "alt": "", "thumbnail": false}}]	Image (http://media.us-iad-rs.aldryn.net/media/1enaEFsxqEVsHSwYhK8cvsfURp0TCnvovCrOA0a6VHlQlimwOgsVUqiDlChBu9Ez/filer_public/c6/61/c661b99a-7c2d-480d-a9ed-f5cb5755e228/feature-default.jpg)	2
2316	75	33	14	json	[{"pk": 33, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:14:41.317", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:09:38.604", "depth": 1, "position": 21, "path": "0007", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	33	33
2317	75	12	25	json	[{"pk": 12, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: text-center	12
2318	75	34	14	json	[{"pk": 34, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:15:42.211", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:14:56.992", "depth": 1, "position": 22, "path": "0008", "placeholder": 3, "plugin_type": "StylePlugin"}}]	34	34
2319	75	13	14	json	[{"pk": 13, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.655", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:01.806", "depth": 2, "position": 0, "path": "00050001", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	13	13
2320	75	22	14	json	[{"pk": 22, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.080", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.076", "depth": 3, "position": 1, "path": "000500070002", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	22	22
2321	75	35	14	json	[{"pk": 35, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:15:26.376", "language": "en", "parent": 34, "numchild": 0, "creation_date": "2015-05-22T11:15:21.507", "depth": 2, "position": 0, "path": "00080001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	35	35
2322	75	14	14	json	[{"pk": 14, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.669", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:16.457", "depth": 2, "position": 2, "path": "00050002", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	14	14
2323	75	7	64	json	[{"pk": 7, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Explore your limits</h1>\\n\\n<p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.<br>\\nDonec sollicitudin molestie malesuada.<br>\\nNulla quis lorem ut libero malesuada feugiat.</p>\\n"}}]	Explore your limits...	7
2324	75	15	14	json	[{"pk": 15, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.662", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:28.907", "depth": 2, "position": 1, "path": "00050003", "placeholder": 3, "plugin_type": "TextPlugin"}}]	15	15
2325	75	3	25	json	[{"pk": 3, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "feature-content", "padding_bottom": null, "additional_class_names": "", "label": "Content", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	“Content”: feature-content	3
2326	75	16	14	json	[{"pk": 16, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.676", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:04:47.410", "depth": 2, "position": 3, "path": "00050004", "placeholder": 3, "plugin_type": "TextPlugin"}}]	16	16
2327	75	17	44	json	[{"pk": 17, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "xs"}}]	size-xs 	17
2328	75	17	14	json	[{"pk": 17, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.691", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:12.306", "depth": 2, "position": 4, "path": "00050008", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	17	17
2329	75	29	14	json	[{"pk": 29, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:08:48.535", "language": "en", "parent": 23, "numchild": 1, "creation_date": "2015-05-22T11:08:25.281", "depth": 4, "position": 0, "path": "0005000700030001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	29	29
2330	75	18	14	json	[{"pk": 18, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.683", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:30.146", "depth": 2, "position": 5, "path": "00050005", "placeholder": 3, "plugin_type": "TextPlugin"}}]	18	18
2331	75	19	14	json	[{"pk": 19, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.699", "language": "en", "parent": 12, "numchild": 0, "creation_date": "2015-05-22T11:05:45.474", "depth": 2, "position": 6, "path": "00050006", "placeholder": 3, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	19	19
2332	75	25	14	json	[{"pk": 25, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:07:17.127", "language": "en", "parent": 21, "numchild": 1, "creation_date": "2015-05-22T11:06:36.687", "depth": 4, "position": 0, "path": "0005000700010001", "placeholder": 3, "plugin_type": "TextPlugin"}}]	25	25
2333	75	20	14	json	[{"pk": 20, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:09:53.708", "language": "en", "parent": 12, "numchild": 4, "creation_date": "2015-05-22T11:06:05.640", "depth": 2, "position": 7, "path": "00050007", "placeholder": 3, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	20	20
2334	75	4	14	json	[{"pk": 4, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:01:29.651", "language": "en", "parent": 8, "numchild": 1, "creation_date": "2015-05-22T10:58:44.225", "depth": 3, "position": 0, "path": "000200020001", "placeholder": 2, "plugin_type": "Bootstrap3RowCMSPlugin"}}]	4	4
2335	75	21	14	json	[{"pk": 21, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:06:23.070", "language": "en", "parent": 20, "numchild": 1, "creation_date": "2015-05-22T11:06:23.067", "depth": 3, "position": 0, "path": "000500070001", "placeholder": 3, "plugin_type": "Bootstrap3ColumnCMSPlugin"}}]	21	21
2451	88	3	11	json	[{"pk": 3, "model": "cms.page", "fields": {"navigation_extenders": null, "site": 1, "application_namespace": null, "path": "0003", "in_navigation": true, "reverse_id": null, "login_required": false, "created_by": "angelo.dini-12", "languages": "en", "publication_end_date": null, "template": "INHERIT", "placeholders": [6, 7], "changed_date": "2015-05-22T11:17:59.043", "limit_visibility_in_menu": null, "parent": null, "numchild": 0, "soft_root": false, "is_home": false, "publication_date": "2015-05-22T10:54:04.440", "creation_date": "2015-05-22T10:53:21.999", "application_urls": null, "changed_by": "angelo.dini-12", "xframe_options": 0, "depth": 1, "revision_id": 0}}]	About	3
2452	88	36	64	json	[{"pk": 36, "model": "djangocms_text_ckeditor.text", "fields": {"body": "<h1>Take The Next Step</h1>\\n\\n<p class=\\"lead\\">There are many variations of passages of Lorem Ipsum available.<br>\\nBut the majority have suffered alteration in some form.<br>\\nBy injected humour, or randomised words which don't look even slightly believable.</p>\\n"}}]	Take The Next...	36
2453	88	37	14	json	[{"pk": 37, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.092", "language": "en", "parent": null, "numchild": 0, "creation_date": "2015-05-22T11:16:47.506", "depth": 1, "position": 1, "path": "000A", "placeholder": 7, "plugin_type": "Bootstrap3SpacerCMSPlugin"}}]	37	37
2454	88	38	25	json	[{"pk": 38, "model": "aldryn_style.style", "fields": {"margin_right": null, "class_name": "text-center", "padding_bottom": null, "additional_class_names": "", "label": "", "id_name": "", "padding_right": null, "margin_top": null, "padding_left": null, "margin_bottom": null, "padding_top": null, "margin_left": null, "tag_type": "div"}}]	text-center	38
2455	88	7	13	json	[{"pk": 7, "model": "cms.placeholder", "fields": {"slot": "content", "default_width": null}}]	content	7
2456	88	40	50	json	[{"pk": 40, "model": "aldryn_bootstrap3.bootstrap3listgroupitemplugin", "fields": {"state": "", "classes": "", "context": "", "title": ""}}]		40
2457	88	41	14	json	[{"pk": 41, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:18:20.213", "language": "en", "parent": 40, "numchild": 0, "creation_date": "2015-05-22T11:18:20.205", "depth": 3, "position": 0, "path": "000C00010001", "placeholder": 7, "plugin_type": "Bootstrap3ImageCMSPlugin"}}]	41	41
2458	88	39	49	json	[{"pk": 39, "model": "aldryn_bootstrap3.bootstrap3listgroupplugin", "fields": {"add_list_group_class": true, "classes": "list-timeline"}}]	1 items	39
2459	88	40	14	json	[{"pk": 40, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:58.976", "language": "en", "parent": 39, "numchild": 1, "creation_date": "2015-05-22T11:17:49.188", "depth": 2, "position": 0, "path": "000C0001", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupItemCMSPlugin"}}]	40	40
2460	88	3	19	json	[{"pk": 3, "model": "cms.title", "fields": {"menu_title": "", "meta_description": "", "page_title": "", "language": "en", "title": "About", "has_url_overwrite": false, "redirect": null, "page": 3, "published": true, "path": "about", "creation_date": "2015-05-22T10:53:22.118", "slug": "about"}}]	About (about, en)	3
2461	88	36	14	json	[{"pk": 36, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.084", "language": "en", "parent": 38, "numchild": 0, "creation_date": "2015-05-22T11:16:35.674", "depth": 2, "position": 0, "path": "000B0001", "placeholder": 7, "plugin_type": "TextPlugin"}}]	36	36
2462	88	6	13	json	[{"pk": 6, "model": "cms.placeholder", "fields": {"slot": "feature", "default_width": null}}]	feature	6
2463	88	38	14	json	[{"pk": 38, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:13.099", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:01.481", "depth": 1, "position": 0, "path": "000B", "placeholder": 7, "plugin_type": "StylePlugin"}}]	38	38
2464	88	39	14	json	[{"pk": 39, "model": "cms.cmsplugin", "fields": {"changed_date": "2015-05-22T11:17:42.704", "language": "en", "parent": null, "numchild": 1, "creation_date": "2015-05-22T11:17:35.161", "depth": 1, "position": 3, "path": "000C", "placeholder": 7, "plugin_type": "Bootstrap3ListGroupCMSPlugin"}}]	39	39
2465	88	37	44	json	[{"pk": 37, "model": "aldryn_bootstrap3.boostrap3spacerplugin", "fields": {"classes": "", "size": "lg"}}]	size-lg 	37
\.


--
-- Name: reversion_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('reversion_version_id_seq', 3084, true);


--
-- Data for Name: robots_rule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY robots_rule (id, robot, crawl_delay) FROM stdin;
\.


--
-- Data for Name: robots_rule_allowed; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY robots_rule_allowed (id, rule_id, url_id) FROM stdin;
\.


--
-- Name: robots_rule_allowed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('robots_rule_allowed_id_seq', 1, false);


--
-- Data for Name: robots_rule_disallowed; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY robots_rule_disallowed (id, rule_id, url_id) FROM stdin;
\.


--
-- Name: robots_rule_disallowed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('robots_rule_disallowed_id_seq', 1, false);


--
-- Name: robots_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('robots_rule_id_seq', 1, false);


--
-- Data for Name: robots_rule_sites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY robots_rule_sites (id, rule_id, site_id) FROM stdin;
\.


--
-- Name: robots_rule_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('robots_rule_sites_id_seq', 1, false);


--
-- Data for Name: robots_url; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY robots_url (id, pattern) FROM stdin;
\.


--
-- Name: robots_url_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('robots_url_id_seq', 1, false);


--
-- Data for Name: south_migrationhistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY south_migrationhistory (id, app_name, migration, applied) FROM stdin;
1	cms	0001_initial	2015-05-22 10:15:26.164871+02
2	cms	0002_auto_start	2015-05-22 10:15:26.204337+02
3	cms	0003_remove_placeholder	2015-05-22 10:15:26.239307+02
4	cms	0004_textobjects	2015-05-22 10:15:26.27398+02
5	cms	0005_mptt_added_to_plugins	2015-05-22 10:15:26.311608+02
6	cms	0006_apphook	2015-05-22 10:15:26.347078+02
7	cms	0007_apphook_longer	2015-05-22 10:15:26.383792+02
8	cms	0008_redirects	2015-05-22 10:15:26.419827+02
9	cms	0009_added_meta_fields	2015-05-22 10:15:26.456696+02
10	cms	0010_5char_language	2015-05-22 10:15:26.551459+02
11	cms	0011_title_overwrites	2015-05-22 10:15:26.958552+02
12	cms	0012_publisher	2015-05-22 10:15:26.997002+02
13	cms	0013_site_copy	2015-05-22 10:15:27.034819+02
14	cms	0014_sites_removed	2015-05-22 10:15:27.070303+02
15	cms	0015_modified_by_added	2015-05-22 10:15:27.11079+02
16	cms	0016_author_copy	2015-05-22 10:15:27.236935+02
17	cms	0017_author_removed	2015-05-22 10:15:27.271796+02
18	cms	0018_site_permissions	2015-05-22 10:15:27.309649+02
19	cms	0019_public_table_renames	2015-05-22 10:15:27.345563+02
20	cms	0020_advanced_permissions	2015-05-22 10:15:27.380539+02
21	cms	0021_publisher2	2015-05-22 10:15:27.417063+02
22	cms	0022_login_required_added	2015-05-22 10:15:27.453202+02
23	cms	0023_plugin_table_naming_function_changed	2015-05-22 10:15:27.488446+02
24	cms	0024_added_placeholder_model	2015-05-22 10:15:27.525593+02
25	cms	0025_placeholder_migration	2015-05-22 10:15:27.943112+02
26	cms	0026_finish_placeholder_migration	2015-05-22 10:15:27.982567+02
27	cms	0027_added_width_to_placeholder	2015-05-22 10:15:28.018477+02
28	cms	0028_limit_visibility_in_menu_step1of3	2015-05-22 10:15:28.054322+02
29	cms	0029_limit_visibility_in_menu_step2of3_data	2015-05-22 10:15:28.092003+02
30	cms	0030_limit_visibility_in_menu_step3of3	2015-05-22 10:15:28.127991+02
31	cms	0031_improved_language_code_support	2015-05-22 10:15:28.163744+02
32	cms	0032_auto__del_field_cmsplugin_publisher_public__del_field_cmsplugin_publis	2015-05-22 10:15:28.203373+02
33	cms	0033_auto__del_field_title_publisher_is_draft__del_field_title_publisher_st	2015-05-22 10:15:28.240967+02
34	cms	0034_auto__chg_field_title_language__chg_field_cmsplugin_language__add_fiel	2015-05-22 10:15:28.279897+02
35	cms	0035_auto__add_field_globalpagepermission_can_view__add_field_pagepermissio	2015-05-22 10:15:28.316522+02
36	cms	0036_auto__add_field_cmsplugin_changed_date	2015-05-22 10:15:28.354633+02
37	cms	0037_auto__del_pagemoderator__del_field_globalpagepermission_can_moderate__	2015-05-22 10:15:28.393512+02
38	cms	0038_publish_page_permission	2015-05-22 10:15:28.43444+02
39	cms	0039_auto__del_field_page_moderator_state	2015-05-22 10:15:28.899846+02
40	cms	0040_auto__del_field_title_meta_keywords__chg_field_title_meta_description	2015-05-22 10:15:28.980907+02
41	cms	0041_auto__add_usersettings	2015-05-22 10:15:29.030222+02
42	cms	0042_auto__del_field_title_meta_keywords__chg_field_title_meta_description_	2015-05-22 10:15:29.14207+02
43	cms	0043_auto__add_field_usersettings_clipboard	2015-05-22 10:15:29.189083+02
44	cms	0044_killsettings	2015-05-22 10:15:29.226184+02
45	cms	0045_auto__add_field_page_application_urls	2015-05-22 10:15:29.400755+02
46	cms	0046_move_apphooks	2015-05-22 10:15:29.4408+02
47	cms	0047_auto__del_field_title_application_urls	2015-05-22 10:15:29.478691+02
48	cms	0048_auto__add_field_page_application_namespace__add_unique_page_publisher_	2015-05-22 10:15:29.961237+02
49	cms	0049_auto__add_field_page_is_home	2015-05-22 10:15:30.035897+02
50	cms	0050_save_home	2015-05-22 10:15:30.083911+02
51	cms	0051_auto__add_placeholderreference	2015-05-22 10:15:30.130439+02
52	cms	0051_fix_content_type	2015-05-22 10:15:30.168318+02
53	cms	0052_auto__add_placeholderreference__add_staticplaceholder__add_field_page_	2015-05-22 10:15:30.226633+02
54	cms	0053_auto__add_field_title_published__add_field_title_publisher_is_draft__a	2015-05-22 10:15:30.350306+02
55	cms	0054_new_publisher_data	2015-05-22 10:15:30.40363+02
56	cms	0055_auto__del_field_page_publisher_state__del_field_page_published	2015-05-22 10:15:30.445741+02
57	cms	0056_auto__del_field_page_published_languages	2015-05-22 10:15:30.680777+02
58	cms	0057_fix_values	2015-05-22 10:15:30.813819+02
59	cms	0058_placeholderref_table_rename	2015-05-22 10:15:30.858179+02
60	cms	0059_auto__del_pagemoderatorstate	2015-05-22 10:15:30.900068+02
61	cms	0060_auto__add_field_page_xframe_options	2015-05-22 10:15:30.988219+02
62	cms	0061_revers_id_unique	2015-05-22 10:15:31.035824+02
63	cms	0062_auto__add_field_staticplaceholder_site__del_unique_staticplaceholder_c	2015-05-22 10:15:31.114063+02
64	cms	0063_auto__chg_field_staticplaceholder_site	2015-05-22 10:15:31.200889+02
65	cms	0064_staticplaceholder_site_change	2015-05-22 10:15:31.243168+02
66	cms	0065_auto__add_unique_usersettings_user	2015-05-22 10:15:31.284953+02
67	cms	0066_auto__add_aliaspluginmodel	2015-05-22 10:15:31.332714+02
68	cms	0067_auto__add_field_aliaspluginmodel_alias_placeholder__chg_field_aliasplu	2015-05-22 10:15:31.613649+02
69	cms	0068_auto__chg_field_placeholder_slot	2015-05-22 10:15:31.701691+02
70	cms	0069_static_placeholder_permissions	2015-05-22 10:15:31.750314+02
71	menus	0001_initial	2015-05-22 10:15:32.107313+02
72	cmscloud	0001_initial	2015-05-22 10:15:32.511739+02
73	aldryn_style	0001_initial	2015-05-22 10:15:32.868895+02
74	aldryn_style	0002_cms_table_name_magic_removal	2015-05-22 10:15:32.886125+02
75	aldryn_style	0003_auto__add_field_style_txt_additional_class_names	2015-05-22 10:15:32.903823+02
76	aldryn_style	0004_move_additional_class_names_to_text_field	2015-05-22 10:15:32.916107+02
77	aldryn_style	0005_rename_addional_class_name_field	2015-05-22 10:15:32.958252+02
78	aldryn_style	0006_auto__add_field_style_label__chg_field_style_additional_class_names	2015-05-22 10:15:33.022457+02
79	captcha	0001_initial	2015-05-22 10:15:33.504845+02
80	filer	0001_initial	2015-05-22 10:15:34.417196+02
81	filer	0002_rename_file_field	2015-05-22 10:15:34.475472+02
82	filer	0003_add_description_field	2015-05-22 10:15:34.502369+02
83	filer	0004_auto__del_field_file__file__add_field_file_file__add_field_file_is_pub	2015-05-22 10:15:34.563132+02
84	filer	0005_auto__add_field_file_sha1__chg_field_file_file	2015-05-22 10:15:34.650844+02
85	filer	0006_polymorphic__add_field_file_polymorphic_ctype	2015-05-22 10:15:34.680754+02
86	filer	0007_polymorphic__content_type_data	2015-05-22 10:15:34.705155+02
87	filer	0008_polymorphic__del_field_file__file_type_plugin_name	2015-05-22 10:15:34.729946+02
88	filer	0009_auto__add_field_folderpermission_can_edit_new__add_field_folderpermiss	2015-05-22 10:15:34.755667+02
89	filer	0010_folderpermissions	2015-05-22 10:15:34.779837+02
90	filer	0011_auto__del_field_folderpermission_can_add_children__del_field_folderper	2015-05-22 10:15:34.804757+02
91	filer	0012_renaming_folderpermissions	2015-05-22 10:15:34.857809+02
92	filer	0013_remove_null_file_name	2015-05-22 10:15:34.88443+02
93	filer	0014_auto__add_field_image_related_url__chg_field_file_name	2015-05-22 10:15:34.96457+02
94	aldryn_bootstrap3	0001_initial	2015-05-22 10:15:35.382841+02
95	aldryn_bootstrap3	0002_auto__add_field_boostrap3buttonplugin_size	2015-05-22 10:15:35.397678+02
96	aldryn_bootstrap3	0003_auto__add_field_boostrap3buttonplugin_classes	2015-05-22 10:15:35.414867+02
97	aldryn_bootstrap3	0004_auto__del_field_boostrap3blockquoteplugin_context__add_field_boostrap3	2015-05-22 10:15:35.438284+02
98	aldryn_bootstrap3	0005_auto__add_bootstrap3rowplugin__add_bootstrap3columnplugin	2015-05-22 10:15:35.467877+02
99	aldryn_bootstrap3	0006_auto__add_field_boostrap3buttonplugin_icon_left__add_field_boostrap3bu	2015-05-22 10:15:35.495204+02
100	aldryn_bootstrap3	0007_auto__add_field_boostrap3buttonplugin_page_link__add_field_boostrap3bu	2015-05-22 10:15:35.539015+02
101	aldryn_bootstrap3	0008_auto__del_field_bootstrap3columnplugin_sm_size__del_field_bootstrap3co	2015-05-22 10:15:35.654023+02
102	aldryn_bootstrap3	0009_auto__add_field_bootstrap3columnplugin_tag	2015-05-22 10:15:35.696904+02
103	aldryn_bootstrap3	0010_auto__add_field_boostrap3buttonplugin_file	2015-05-22 10:15:35.74794+02
104	aldryn_bootstrap3	0011_auto__add_boostrap3imageplugin	2015-05-22 10:15:35.806002+02
105	aldryn_bootstrap3	0012_auto__del_field_boostrap3buttonplugin_context__add_field_boostrap3butt	2015-05-22 10:15:35.884279+02
106	aldryn_bootstrap3	0013_auto__add_field_boostrap3buttonplugin_type__add_field_boostrap3buttonp	2015-05-22 10:15:36.441469+02
107	aldryn_bootstrap3	0014_auto__add_field_boostrap3buttonplugin_block	2015-05-22 10:15:36.501121+02
108	aldryn_bootstrap3	0015_auto__del_field_boostrap3buttonplugin_block__del_field_boostrap3button	2015-05-22 10:15:36.580074+02
109	aldryn_bootstrap3	0016_auto__add_boostrap3iconplugin	2015-05-22 10:15:36.631134+02
110	aldryn_bootstrap3	0017_auto__add_boostrap3labelplugin	2015-05-22 10:15:36.687245+02
111	aldryn_bootstrap3	0018_auto__add_boostrap3panelfooterplugin__add_boostrap3panelheadingplugin_	2015-05-22 10:15:36.763182+02
112	aldryn_bootstrap3	0019_auto__del_boostrap3pabelbodyplugin__add_boostrap3panelbodyplugin	2015-05-22 10:15:36.824854+02
113	aldryn_bootstrap3	0020_auto__add_boostrap3wellplugin	2015-05-22 10:15:36.886313+02
114	aldryn_bootstrap3	0021_auto__add_boostrap3alertplugin	2015-05-22 10:15:36.951609+02
115	aldryn_bootstrap3	0022_auto__add_field_boostrap3alertplugin_icon	2015-05-22 10:15:37.464249+02
116	aldryn_bootstrap3	0023_auto__add_bootstrap3accordionplugin__add_bootstrap3accordionitemplugin	2015-05-22 10:15:37.540642+02
117	aldryn_bootstrap3	0024_auto__add_field_bootstrap3accordionplugin_index	2015-05-22 10:15:37.603909+02
118	aldryn_bootstrap3	0025_auto__add_field_boostrap3buttonplugin_responsive__add_field_boostrap3b	2015-05-22 10:15:37.6869+02
119	aldryn_bootstrap3	0026_auto__add_field_boostrap3imageplugin_img_responsive	2015-05-22 10:15:37.759587+02
120	aldryn_bootstrap3	0027_auto__add_bootstrap3listgroupitemplugin__add_bootstrap3listgroupplugin	2015-05-22 10:15:37.840922+02
121	aldryn_bootstrap3	0028_auto__add_field_bootstrap3listgroupplugin_add_list_group_class__add_fi	2015-05-22 10:15:37.920644+02
122	aldryn_bootstrap3	0029_prefix_link_mixin_fields	2015-05-22 10:15:38.038392+02
123	aldryn_bootstrap3	0030_auto__add_boostrap3spacerplugin	2015-05-22 10:15:38.403527+02
124	aldryn_bootstrap3	0031_auto__add_bootstrap3carouselplugin__add_bootstrap3carouselslideplugin	2015-05-22 10:15:38.503633+02
125	aldryn_bootstrap3	0032_auto__add_bootstrap3carouselslidefolderplugin	2015-05-22 10:15:38.587793+02
126	aldryn_bootstrap3	0033_auto__add_field_bootstrap3carouselplugin_aspect_ratio	2015-05-22 10:15:38.672466+02
127	easy_thumbnails	0001_initial	2015-05-22 10:15:39.346855+02
128	easy_thumbnails	0002_filename_indexes	2015-05-22 10:15:39.360832+02
129	easy_thumbnails	0003_auto__add_storagenew	2015-05-22 10:15:39.377469+02
130	easy_thumbnails	0004_auto__add_field_source_storage_new__add_field_thumbnail_storage_new	2015-05-22 10:15:39.395427+02
131	easy_thumbnails	0005_storage_fks_null	2015-05-22 10:15:39.610692+02
132	easy_thumbnails	0006_copy_storage	2015-05-22 10:15:39.621327+02
133	easy_thumbnails	0007_storagenew_fks_not_null	2015-05-22 10:15:40.075153+02
134	easy_thumbnails	0008_auto__del_field_source_storage__del_field_thumbnail_storage	2015-05-22 10:15:40.086682+02
135	easy_thumbnails	0009_auto__del_storage	2015-05-22 10:15:40.097258+02
136	easy_thumbnails	0010_rename_storage	2015-05-22 10:15:40.111664+02
137	easy_thumbnails	0011_auto__add_field_source_storage_hash__add_field_thumbnail_storage_hash	2015-05-22 10:15:40.134286+02
138	easy_thumbnails	0012_build_storage_hashes	2015-05-22 10:15:40.144868+02
139	easy_thumbnails	0013_auto__del_storage__del_field_source_storage__del_field_thumbnail_stora	2015-05-22 10:15:40.158646+02
140	easy_thumbnails	0014_auto__add_unique_source_name_storage_hash__add_unique_thumbnail_name_s	2015-05-22 10:15:40.171121+02
141	easy_thumbnails	0015_auto__del_unique_thumbnail_name_storage_hash__add_unique_thumbnail_sou	2015-05-22 10:15:40.223635+02
142	easy_thumbnails	0016_auto__add_thumbnaildimensions	2015-05-22 10:15:40.239486+02
143	cmsplugin_filer_file	0001_initial	2015-05-22 10:15:41.10822+02
144	cmsplugin_filer_file	0002_auto__add_field_filerfile_target_blank	2015-05-22 10:15:41.142916+02
145	cmsplugin_filer_file	0003_auto__add_field_filerfile_style	2015-05-22 10:15:41.174456+02
146	cmsplugin_filer_file	0004_fix_table_names	2015-05-22 10:15:41.202246+02
147	cmsplugin_filer_image	0001_initial	2015-05-22 10:15:41.408331+02
148	cmsplugin_filer_image	0002_auto__add_field_filerimage_image_url__chg_field_filerimage_image	2015-05-22 10:15:41.553618+02
149	cmsplugin_filer_image	0003_auto__add_thumbnailoption__add_field_filerimage_thumbnail_option	2015-05-22 10:15:41.603649+02
150	cmsplugin_filer_image	0004_auto__del_field_thumbnailoption_is_scaled__del_field_thumbnailoption_i	2015-05-22 10:15:42.026305+02
151	cmsplugin_filer_image	0005_rename_float_to_alignment	2015-05-22 10:15:42.122819+02
152	cmsplugin_filer_image	0006_auto__add_field_filerimage_original_link	2015-05-22 10:15:42.17071+02
153	cmsplugin_filer_image	0007_rename_caption_to_caption_text	2015-05-22 10:15:42.259287+02
154	cmsplugin_filer_image	0008_auto__add_field_filerimage_file_link	2015-05-22 10:15:42.31236+02
155	cmsplugin_filer_image	0009_auto__add_field_filerimage_use_original_image	2015-05-22 10:15:42.362021+02
156	cmsplugin_filer_image	0010_auto__add_field_filerimage_target_blank	2015-05-22 10:15:42.414187+02
157	cmsplugin_filer_image	0011_auto__add_field_filerimage_style	2015-05-22 10:15:42.467628+02
158	cmsplugin_filer_image	0012_fix_table_names	2015-05-22 10:15:42.510186+02
159	reversion	0001_initial	2015-05-22 10:15:43.052438+02
160	reversion	0002_auto__add_field_version_type	2015-05-22 10:15:43.082894+02
161	reversion	0003_auto__add_field_version_object_id_int	2015-05-22 10:15:43.45642+02
162	reversion	0004_populate_object_id_int	2015-05-22 10:15:43.473796+02
163	reversion	0005_auto__add_field_revision_manager_slug	2015-05-22 10:15:43.505158+02
164	reversion	0006_remove_delete_revisions	2015-05-22 10:15:43.5252+02
165	reversion	0007_auto__del_field_version_type	2015-05-22 10:15:43.54163+02
166	reversion	0008_auto__add_index_revision_date_created	2015-05-22 10:15:43.935908+02
167	robots	0001_initial	2015-05-22 10:15:44.137815+02
168	djangocms_text_ckeditor	0001_initial	2015-05-22 10:15:44.306889+02
169	djangocms_text_ckeditor	0002_rename_plugin	2015-05-22 10:15:44.320431+02
170	djangocms_link	0001_initial	2015-05-22 10:15:45.046616+02
171	djangocms_link	0002_auto__add_field_link_phone	2015-05-22 10:15:45.066199+02
172	djangocms_link	0003_auto__add_field_link_anchor__chg_field_link_page_link	2015-05-22 10:15:45.223917+02
173	djangocms_snippet	0001_initial	2015-05-22 10:15:45.407569+02
174	djangocms_snippet	0002_rename_missing_tables	2015-05-22 10:15:45.420129+02
175	djangocms_googlemap	0001_initial	2015-05-22 10:15:45.987742+02
176	aldryn_forms	0001_initial	2015-05-22 10:15:46.173935+02
177	aldryn_forms	0002_auto__add_fieldsetplugin	2015-05-22 10:15:46.191609+02
178	aldryn_forms	0003_auto__add_option	2015-05-22 10:15:46.211616+02
179	aldryn_forms	0004_auto__add_field_fieldplugin_min_value__add_field_fieldplugin_max_value	2015-05-22 10:15:46.230004+02
180	aldryn_forms	0005_auto__add_field_formplugin_error_message	2015-05-22 10:15:46.246952+02
181	aldryn_forms	0006_auto__add_field_fieldplugin_required_message	2015-05-22 10:15:46.261943+02
182	aldryn_forms	0007_auto__add_field_formplugin_redirect_type__add_field_formplugin_page__a	2015-05-22 10:15:46.300584+02
183	aldryn_forms	0008_auto	2015-05-22 10:15:46.937742+02
184	aldryn_forms	0009_auto__add_formdata	2015-05-22 10:15:47.004757+02
185	aldryn_forms	0010_auto__add_textareafieldplugin	2015-05-22 10:15:47.060548+02
186	aldryn_forms	0011_migrate_to_textarea_plugin	2015-05-22 10:15:47.106622+02
187	aldryn_forms	0012_auto__add_field_fieldplugin_input_html_class__add_field_textareafieldp	2015-05-22 10:15:47.161796+02
188	aldryn_forms	0013_auto__add_field_fieldsetplugin_html_class__add_field_formplugin_html_c	2015-05-22 10:15:47.219216+02
189	aldryn_forms	0014_auto__del_field_fieldsetplugin_html_class__add_field_fieldsetplugin_cu	2015-05-22 10:15:47.62446+02
190	aldryn_forms	0015_auto__add_field_option_default_value	2015-05-22 10:15:47.838138+02
191	aldryn_forms	0016_remove_cmsplugin_prefix_from_plugin_table_name	2015-05-22 10:15:47.898314+02
192	aldryn_forms	0017_auto__del_buttonplugin__add_formbuttonplugin	2015-05-22 10:15:47.940041+02
193	aldryn_forms	0018_auto__add_emailfieldplugin	2015-05-22 10:15:47.993815+02
194	aldryn_forms	0019_auto__add_field_formplugin_form_template	2015-05-22 10:15:48.047054+02
195	aldryn_forms	0020_auto__add_field_emailfieldplugin_email_subject	2015-05-22 10:15:48.10455+02
196	aldryn_forms	0021_auto__add_field_formplugin_success_message	2015-05-22 10:15:48.15433+02
197	aldryn_forms	0022_auto__add_field_formdata_language	2015-05-22 10:15:48.213418+02
198	aldryn_forms	0023_auto__add_fileuploadfieldplugin	2015-05-22 10:15:48.281127+02
199	aldryn_forms	0024_auto__add_field_fileuploadfieldplugin_max_size	2015-05-22 10:15:48.336985+02
200	aldryn_forms	0025_auto__add_imageuploadfieldplugin	2015-05-22 10:15:48.812052+02
201	aldryn_forms	0026_auto__add_field_emailfieldplugin_email_body	2015-05-22 10:15:48.886822+02
202	cms	0070_auto__add_field_cmsplugin_path__add_field_cmsplugin_depth__add_field_c	2015-05-22 10:19:13.73764+02
203	cms	0071_mptt_to_mp	2015-05-22 10:19:13.806458+02
204	cms	0072_auto__del_field_cmsplugin_rght__del_field_cmsplugin_level__del_field_c	2015-05-22 10:19:13.854382+02
205	cms	0073_auto__chg_field_cmsplugin_path__chg_field_page_path	2015-05-22 10:19:14.553829+02
206	cms	0074_auto__chg_field_title_redirect	2015-05-22 10:19:14.788151+02
207	cms	0074_auto__del_unique_page_publisher_is_draft_application_namespace__add_un	2015-05-22 10:19:14.926483+02
208	cms	0075_use_structure	2015-05-22 10:19:14.976887+02
209	cms	0076_auto__chg_field_page_created_by__chg_field_page_changed_by	2015-05-22 10:19:15.673377+02
\.


--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('south_migrationhistory_id_seq', 209, true);


--
-- Name: aldryn_bootstrap3_boostrap3alertplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3alertplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3alertplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3blockquoteplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3blockquoteplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3blockquoteplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3buttonplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3buttonplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3buttonplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3iconplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3iconplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3iconplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3imageplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3imageplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3imageplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3labelplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3labelplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3labelplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3panelbodyplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelbodyplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3panelbodyplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3panelfooterplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelfooterplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3panelfooterplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3panelheadingplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelheadingplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3panelheadingplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3panelplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3panelplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3spacerplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3spacerplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3spacerplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3wellplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3wellplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3wellplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3accordionitemplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3accordionitemplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3accordionitemplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3accordionplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3accordionplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3accordionplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3carouselplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3carouselplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3carouselslidefolderplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslidefolderplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3carouselslidefolderplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3carouselslideplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslideplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3carouselslideplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3columnplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3columnplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3columnplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3listgroupitemplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3listgroupitemplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3listgroupitemplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3listgroupplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3listgroupplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3listgroupplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3rowplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3rowplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3rowplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_forms_emailfieldplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_forms_emailfieldplugin
    ADD CONSTRAINT aldryn_forms_emailfieldplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_forms_fileuploadfieldplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_forms_fileuploadfieldplugin
    ADD CONSTRAINT aldryn_forms_fileuploadfieldplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_forms_formdata_people__formdata_id_70e5827c31a71950_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_forms_formdata_people_notified
    ADD CONSTRAINT aldryn_forms_formdata_people__formdata_id_70e5827c31a71950_uniq UNIQUE (formdata_id, user_id);


--
-- Name: aldryn_forms_formdata_people_notified_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_forms_formdata_people_notified
    ADD CONSTRAINT aldryn_forms_formdata_people_notified_pkey PRIMARY KEY (id);


--
-- Name: aldryn_forms_formdata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_forms_formdata
    ADD CONSTRAINT aldryn_forms_formdata_pkey PRIMARY KEY (id);


--
-- Name: aldryn_forms_formplugin_rec_formplugin_id_563c10d526a98459_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_forms_formplugin_recipients
    ADD CONSTRAINT aldryn_forms_formplugin_rec_formplugin_id_563c10d526a98459_uniq UNIQUE (formplugin_id, user_id);


--
-- Name: aldryn_forms_formplugin_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_forms_formplugin_recipients
    ADD CONSTRAINT aldryn_forms_formplugin_recipients_pkey PRIMARY KEY (id);


--
-- Name: aldryn_forms_imageuploadfieldplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_forms_imageuploadfieldplugin
    ADD CONSTRAINT aldryn_forms_imageuploadfieldplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_forms_option_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_forms_option
    ADD CONSTRAINT aldryn_forms_option_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: captcha_captchastore_hashkey_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY captcha_captchastore
    ADD CONSTRAINT captcha_captchastore_hashkey_key UNIQUE (hashkey);


--
-- Name: captcha_captchastore_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY captcha_captchastore
    ADD CONSTRAINT captcha_captchastore_pkey PRIMARY KEY (id);


--
-- Name: cms_aliaspluginmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_aliaspluginmodel
    ADD CONSTRAINT cms_aliaspluginmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cms_cmsplugin_path_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_cmsplugin
    ADD CONSTRAINT cms_cmsplugin_path_key UNIQUE (path);


--
-- Name: cms_cmsplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_cmsplugin
    ADD CONSTRAINT cms_cmsplugin_pkey PRIMARY KEY (id);


--
-- Name: cms_globalpageper_globalpagepermission_id_1ffcd9d4c6c0cbfa_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_globalpagepermission_sites
    ADD CONSTRAINT cms_globalpageper_globalpagepermission_id_1ffcd9d4c6c0cbfa_uniq UNIQUE (globalpagepermission_id, site_id);


--
-- Name: cms_globalpagepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_globalpagepermission
    ADD CONSTRAINT cms_globalpagepermission_pkey PRIMARY KEY (id);


--
-- Name: cms_globalpagepermission_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_globalpagepermission_sites
    ADD CONSTRAINT cms_globalpagepermission_sites_pkey PRIMARY KEY (id);


--
-- Name: cms_page_path_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT cms_page_path_key UNIQUE (path);


--
-- Name: cms_page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT cms_page_pkey PRIMARY KEY (id);


--
-- Name: cms_page_placeholders_page_id_598353cf6a0df834_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_page_placeholders
    ADD CONSTRAINT cms_page_placeholders_page_id_598353cf6a0df834_uniq UNIQUE (page_id, placeholder_id);


--
-- Name: cms_page_placeholders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_page_placeholders
    ADD CONSTRAINT cms_page_placeholders_pkey PRIMARY KEY (id);


--
-- Name: cms_page_publisher_is_draft_7597e61e0082d3aa_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT cms_page_publisher_is_draft_7597e61e0082d3aa_uniq UNIQUE (publisher_is_draft, site_id, application_namespace);


--
-- Name: cms_page_publisher_public_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT cms_page_publisher_public_id_key UNIQUE (publisher_public_id);


--
-- Name: cms_page_reverse_id_a864144bd3516c9_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT cms_page_reverse_id_a864144bd3516c9_uniq UNIQUE (reverse_id, site_id, publisher_is_draft);


--
-- Name: cms_pagepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_pagepermission
    ADD CONSTRAINT cms_pagepermission_pkey PRIMARY KEY (id);


--
-- Name: cms_pageuser_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_pageuser
    ADD CONSTRAINT cms_pageuser_pkey PRIMARY KEY (user_ptr_id);


--
-- Name: cms_pageusergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_pageusergroup
    ADD CONSTRAINT cms_pageusergroup_pkey PRIMARY KEY (group_ptr_id);


--
-- Name: cms_placeholder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_placeholder
    ADD CONSTRAINT cms_placeholder_pkey PRIMARY KEY (id);


--
-- Name: cms_staticplaceholder_code_6c6b490a9fe0e459_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_staticplaceholder
    ADD CONSTRAINT cms_staticplaceholder_code_6c6b490a9fe0e459_uniq UNIQUE (code, site_id);


--
-- Name: cms_staticplaceholder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_staticplaceholder
    ADD CONSTRAINT cms_staticplaceholder_pkey PRIMARY KEY (id);


--
-- Name: cms_title_language_7a69dc7eaf856287_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_title
    ADD CONSTRAINT cms_title_language_7a69dc7eaf856287_uniq UNIQUE (language, page_id);


--
-- Name: cms_title_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_title
    ADD CONSTRAINT cms_title_pkey PRIMARY KEY (id);


--
-- Name: cms_title_publisher_public_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_title
    ADD CONSTRAINT cms_title_publisher_public_id_key UNIQUE (publisher_public_id);


--
-- Name: cms_usersettings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_usersettings
    ADD CONSTRAINT cms_usersettings_pkey PRIMARY KEY (id);


--
-- Name: cms_usersettings_user_id_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_usersettings
    ADD CONSTRAINT cms_usersettings_user_id_uniq UNIQUE (user_id);


--
-- Name: cmscloud_aldrynclouduser_cloud_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cmscloud_aldrynclouduser
    ADD CONSTRAINT cmscloud_aldrynclouduser_cloud_id_key UNIQUE (cloud_id);


--
-- Name: cmscloud_aldrynclouduser_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cmscloud_aldrynclouduser
    ADD CONSTRAINT cmscloud_aldrynclouduser_pkey PRIMARY KEY (id);


--
-- Name: cmscloud_aldrynclouduser_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cmscloud_aldrynclouduser
    ADD CONSTRAINT cmscloud_aldrynclouduser_user_id_key UNIQUE (user_id);


--
-- Name: cmsplugin_buttonplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_forms_formbuttonplugin
    ADD CONSTRAINT cmsplugin_buttonplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cmsplugin_fieldplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_forms_fieldplugin
    ADD CONSTRAINT cmsplugin_fieldplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cmsplugin_fieldsetplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_forms_fieldsetplugin
    ADD CONSTRAINT cmsplugin_fieldsetplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cmsplugin_filer_image_thumbnailoption_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cmsplugin_filer_image_thumbnailoption
    ADD CONSTRAINT cmsplugin_filer_image_thumbnailoption_pkey PRIMARY KEY (id);


--
-- Name: cmsplugin_filerfile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cmsplugin_filer_file_filerfile
    ADD CONSTRAINT cmsplugin_filerfile_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cmsplugin_filerimage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cmsplugin_filer_image_filerimage
    ADD CONSTRAINT cmsplugin_filerimage_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cmsplugin_formplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_forms_formplugin
    ADD CONSTRAINT cmsplugin_formplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cmsplugin_placeholderreference_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_placeholderreference
    ADD CONSTRAINT cmsplugin_placeholderreference_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cmsplugin_style_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_style_style
    ADD CONSTRAINT cmsplugin_style_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cmsplugin_text_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY djangocms_text_ckeditor_text
    ADD CONSTRAINT cmsplugin_text_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cmsplugin_textareafieldplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_forms_textareafieldplugin
    ADD CONSTRAINT cmsplugin_textareafieldplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_model_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_key UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_dbcache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_dbcache
    ADD CONSTRAINT django_dbcache_pkey PRIMARY KEY (cache_key);


--
-- Name: django_select2_keymap_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_select2_keymap
    ADD CONSTRAINT django_select2_keymap_key_key UNIQUE (key);


--
-- Name: django_select2_keymap_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_select2_keymap
    ADD CONSTRAINT django_select2_keymap_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: djangocms_googlemap_googlemap_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY djangocms_googlemap_googlemap
    ADD CONSTRAINT djangocms_googlemap_googlemap_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: djangocms_link_link_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY djangocms_link_link
    ADD CONSTRAINT djangocms_link_link_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: djangocms_snippet_snippet_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY djangocms_snippet_snippet
    ADD CONSTRAINT djangocms_snippet_snippet_name_key UNIQUE (name);


--
-- Name: djangocms_snippet_snippet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY djangocms_snippet_snippet
    ADD CONSTRAINT djangocms_snippet_snippet_pkey PRIMARY KEY (id);


--
-- Name: djangocms_snippet_snippetptr_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY djangocms_snippet_snippetptr
    ADD CONSTRAINT djangocms_snippet_snippetptr_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: easy_thumbnails_source_name_7549c98cc6dd6969_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_name_7549c98cc6dd6969_uniq UNIQUE (name, storage_hash);


--
-- Name: easy_thumbnails_source_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnail_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnail_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnail_source_id_1f50d53db8191480_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnail_source_id_1f50d53db8191480_uniq UNIQUE (source_id, name, storage_hash);


--
-- Name: easy_thumbnails_thumbnaildimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnaildimensions_thumbnail_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_thumbnail_id_key UNIQUE (thumbnail_id);


--
-- Name: filer_clipboard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY filer_clipboard
    ADD CONSTRAINT filer_clipboard_pkey PRIMARY KEY (id);


--
-- Name: filer_clipboarditem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY filer_clipboarditem
    ADD CONSTRAINT filer_clipboarditem_pkey PRIMARY KEY (id);


--
-- Name: filer_file_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY filer_file
    ADD CONSTRAINT filer_file_pkey PRIMARY KEY (id);


--
-- Name: filer_folder_parent_id_30ad83e34d901e49_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY filer_folder
    ADD CONSTRAINT filer_folder_parent_id_30ad83e34d901e49_uniq UNIQUE (parent_id, name);


--
-- Name: filer_folder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY filer_folder
    ADD CONSTRAINT filer_folder_pkey PRIMARY KEY (id);


--
-- Name: filer_folderpermission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY filer_folderpermission
    ADD CONSTRAINT filer_folderpermission_pkey PRIMARY KEY (id);


--
-- Name: filer_image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY filer_image
    ADD CONSTRAINT filer_image_pkey PRIMARY KEY (file_ptr_id);


--
-- Name: health_check_db_testmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY health_check_db_testmodel
    ADD CONSTRAINT health_check_db_testmodel_pkey PRIMARY KEY (id);


--
-- Name: menus_cachekey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY menus_cachekey
    ADD CONSTRAINT menus_cachekey_pkey PRIMARY KEY (id);


--
-- Name: reversion_revision_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY reversion_revision
    ADD CONSTRAINT reversion_revision_pkey PRIMARY KEY (id);


--
-- Name: reversion_version_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY reversion_version
    ADD CONSTRAINT reversion_version_pkey PRIMARY KEY (id);


--
-- Name: robots_rule_allowed_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY robots_rule_allowed
    ADD CONSTRAINT robots_rule_allowed_pkey PRIMARY KEY (id);


--
-- Name: robots_rule_allowed_rule_id_72e63691eaf012ce_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY robots_rule_allowed
    ADD CONSTRAINT robots_rule_allowed_rule_id_72e63691eaf012ce_uniq UNIQUE (rule_id, url_id);


--
-- Name: robots_rule_disallowed_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY robots_rule_disallowed
    ADD CONSTRAINT robots_rule_disallowed_pkey PRIMARY KEY (id);


--
-- Name: robots_rule_disallowed_rule_id_c23d2ff6b2cf8d_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY robots_rule_disallowed
    ADD CONSTRAINT robots_rule_disallowed_rule_id_c23d2ff6b2cf8d_uniq UNIQUE (rule_id, url_id);


--
-- Name: robots_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY robots_rule
    ADD CONSTRAINT robots_rule_pkey PRIMARY KEY (id);


--
-- Name: robots_rule_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY robots_rule_sites
    ADD CONSTRAINT robots_rule_sites_pkey PRIMARY KEY (id);


--
-- Name: robots_rule_sites_rule_id_1e7dae09dc45cde9_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY robots_rule_sites
    ADD CONSTRAINT robots_rule_sites_rule_id_1e7dae09dc45cde9_uniq UNIQUE (rule_id, site_id);


--
-- Name: robots_url_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY robots_url
    ADD CONSTRAINT robots_url_pkey PRIMARY KEY (id);


--
-- Name: south_migrationhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY south_migrationhistory
    ADD CONSTRAINT south_migrationhistory_pkey PRIMARY KEY (id);


--
-- Name: aldryn_bootstrap3_boostrap3buttonplugin_file_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_boostrap3buttonplugin_file_id ON aldryn_bootstrap3_boostrap3buttonplugin USING btree (link_file_id);


--
-- Name: aldryn_bootstrap3_boostrap3buttonplugin_page_link_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_boostrap3buttonplugin_page_link_id ON aldryn_bootstrap3_boostrap3buttonplugin USING btree (link_page_id);


--
-- Name: aldryn_bootstrap3_boostrap3imageplugin_file_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_boostrap3imageplugin_file_id ON aldryn_bootstrap3_boostrap3imageplugin USING btree (file_id);


--
-- Name: aldryn_bootstrap3_bootstrap3carouselslidefolderplugin_folder_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_bootstrap3carouselslidefolderplugin_folder_id ON aldryn_bootstrap3_bootstrap3carouselslidefolderplugin USING btree (folder_id);


--
-- Name: aldryn_bootstrap3_bootstrap3carouselslideplugin_image_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_bootstrap3carouselslideplugin_image_id ON aldryn_bootstrap3_bootstrap3carouselslideplugin USING btree (image_id);


--
-- Name: aldryn_bootstrap3_bootstrap3carouselslideplugin_link_file_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_bootstrap3carouselslideplugin_link_file_id ON aldryn_bootstrap3_bootstrap3carouselslideplugin USING btree (link_file_id);


--
-- Name: aldryn_bootstrap3_bootstrap3carouselslideplugin_link_page_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_bootstrap3carouselslideplugin_link_page_id ON aldryn_bootstrap3_bootstrap3carouselslideplugin USING btree (link_page_id);


--
-- Name: aldryn_bootstrap3_bootstrap3columnplugin_tag; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_bootstrap3columnplugin_tag ON aldryn_bootstrap3_bootstrap3columnplugin USING btree (tag);


--
-- Name: aldryn_bootstrap3_bootstrap3columnplugin_tag_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_bootstrap3columnplugin_tag_like ON aldryn_bootstrap3_bootstrap3columnplugin USING btree (tag varchar_pattern_ops);


--
-- Name: aldryn_forms_fileuploadfieldplugin_upload_to_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_forms_fileuploadfieldplugin_upload_to_id ON aldryn_forms_fileuploadfieldplugin USING btree (upload_to_id);


--
-- Name: aldryn_forms_formdata_name; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_forms_formdata_name ON aldryn_forms_formdata USING btree (name);


--
-- Name: aldryn_forms_formdata_name_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_forms_formdata_name_like ON aldryn_forms_formdata USING btree (name varchar_pattern_ops);


--
-- Name: aldryn_forms_formdata_people_notified_formdata_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_forms_formdata_people_notified_formdata_id ON aldryn_forms_formdata_people_notified USING btree (formdata_id);


--
-- Name: aldryn_forms_formdata_people_notified_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_forms_formdata_people_notified_user_id ON aldryn_forms_formdata_people_notified USING btree (user_id);


--
-- Name: aldryn_forms_formplugin_recipients_formplugin_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_forms_formplugin_recipients_formplugin_id ON aldryn_forms_formplugin_recipients USING btree (formplugin_id);


--
-- Name: aldryn_forms_formplugin_recipients_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_forms_formplugin_recipients_user_id ON aldryn_forms_formplugin_recipients USING btree (user_id);


--
-- Name: aldryn_forms_imageuploadfieldplugin_upload_to_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_forms_imageuploadfieldplugin_upload_to_id ON aldryn_forms_imageuploadfieldplugin USING btree (upload_to_id);


--
-- Name: aldryn_forms_option_field_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_forms_option_field_id ON aldryn_forms_option USING btree (field_id);


--
-- Name: auth_group_name_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_name_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_permissions_group_id ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_permissions_permission_id ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_permission_content_type_id ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_groups_group_id ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_groups_user_id ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_permission_id ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_user_id ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_username_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: captcha_captchastore_hashkey_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX captcha_captchastore_hashkey_like ON captcha_captchastore USING btree (hashkey varchar_pattern_ops);


--
-- Name: cms_aliaspluginmodel_alias_placeholder_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_aliaspluginmodel_alias_placeholder_id ON cms_aliaspluginmodel USING btree (alias_placeholder_id);


--
-- Name: cms_aliaspluginmodel_plugin_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_aliaspluginmodel_plugin_id ON cms_aliaspluginmodel USING btree (plugin_id);


--
-- Name: cms_cmsplugin_language; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_cmsplugin_language ON cms_cmsplugin USING btree (language);


--
-- Name: cms_cmsplugin_language_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_cmsplugin_language_like ON cms_cmsplugin USING btree (language varchar_pattern_ops);


--
-- Name: cms_cmsplugin_parent_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_cmsplugin_parent_id ON cms_cmsplugin USING btree (parent_id);


--
-- Name: cms_cmsplugin_path_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_cmsplugin_path_like ON cms_cmsplugin USING btree (path varchar_pattern_ops);


--
-- Name: cms_cmsplugin_placeholder_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_cmsplugin_placeholder_id ON cms_cmsplugin USING btree (placeholder_id);


--
-- Name: cms_cmsplugin_plugin_type; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_cmsplugin_plugin_type ON cms_cmsplugin USING btree (plugin_type);


--
-- Name: cms_cmsplugin_plugin_type_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_cmsplugin_plugin_type_like ON cms_cmsplugin USING btree (plugin_type varchar_pattern_ops);


--
-- Name: cms_globalpagepermission_group_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_globalpagepermission_group_id ON cms_globalpagepermission USING btree (group_id);


--
-- Name: cms_globalpagepermission_sites_globalpagepermission_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_globalpagepermission_sites_globalpagepermission_id ON cms_globalpagepermission_sites USING btree (globalpagepermission_id);


--
-- Name: cms_globalpagepermission_sites_site_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_globalpagepermission_sites_site_id ON cms_globalpagepermission_sites USING btree (site_id);


--
-- Name: cms_globalpagepermission_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_globalpagepermission_user_id ON cms_globalpagepermission USING btree (user_id);


--
-- Name: cms_page_application_urls; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_application_urls ON cms_page USING btree (application_urls);


--
-- Name: cms_page_application_urls_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_application_urls_like ON cms_page USING btree (application_urls varchar_pattern_ops);


--
-- Name: cms_page_in_navigation; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_in_navigation ON cms_page USING btree (in_navigation);


--
-- Name: cms_page_is_home; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_is_home ON cms_page USING btree (is_home);


--
-- Name: cms_page_limit_visibility_in_menu; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_limit_visibility_in_menu ON cms_page USING btree (limit_visibility_in_menu);


--
-- Name: cms_page_navigation_extenders; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_navigation_extenders ON cms_page USING btree (navigation_extenders);


--
-- Name: cms_page_navigation_extenders_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_navigation_extenders_like ON cms_page USING btree (navigation_extenders varchar_pattern_ops);


--
-- Name: cms_page_parent_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_parent_id ON cms_page USING btree (parent_id);


--
-- Name: cms_page_path_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_path_like ON cms_page USING btree (path varchar_pattern_ops);


--
-- Name: cms_page_placeholders_page_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_placeholders_page_id ON cms_page_placeholders USING btree (page_id);


--
-- Name: cms_page_placeholders_placeholder_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_placeholders_placeholder_id ON cms_page_placeholders USING btree (placeholder_id);


--
-- Name: cms_page_publication_date; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_publication_date ON cms_page USING btree (publication_date);


--
-- Name: cms_page_publication_end_date; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_publication_end_date ON cms_page USING btree (publication_end_date);


--
-- Name: cms_page_publisher_is_draft; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_publisher_is_draft ON cms_page USING btree (publisher_is_draft);


--
-- Name: cms_page_reverse_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_reverse_id ON cms_page USING btree (reverse_id);


--
-- Name: cms_page_reverse_id_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_reverse_id_like ON cms_page USING btree (reverse_id varchar_pattern_ops);


--
-- Name: cms_page_site_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_site_id ON cms_page USING btree (site_id);


--
-- Name: cms_page_soft_root; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_soft_root ON cms_page USING btree (soft_root);


--
-- Name: cms_pagepermission_group_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_pagepermission_group_id ON cms_pagepermission USING btree (group_id);


--
-- Name: cms_pagepermission_page_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_pagepermission_page_id ON cms_pagepermission USING btree (page_id);


--
-- Name: cms_pagepermission_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_pagepermission_user_id ON cms_pagepermission USING btree (user_id);


--
-- Name: cms_pageuser_created_by_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_pageuser_created_by_id ON cms_pageuser USING btree (created_by_id);


--
-- Name: cms_pageusergroup_created_by_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_pageusergroup_created_by_id ON cms_pageusergroup USING btree (created_by_id);


--
-- Name: cms_placeholder_slot; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_placeholder_slot ON cms_placeholder USING btree (slot);


--
-- Name: cms_placeholder_slot_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_placeholder_slot_like ON cms_placeholder USING btree (slot varchar_pattern_ops);


--
-- Name: cms_staticplaceholder_code_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_staticplaceholder_code_like ON cms_staticplaceholder USING btree (code varchar_pattern_ops);


--
-- Name: cms_staticplaceholder_draft_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_staticplaceholder_draft_id ON cms_staticplaceholder USING btree (draft_id);


--
-- Name: cms_staticplaceholder_public_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_staticplaceholder_public_id ON cms_staticplaceholder USING btree (public_id);


--
-- Name: cms_staticplaceholder_site_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_staticplaceholder_site_id ON cms_staticplaceholder USING btree (site_id);


--
-- Name: cms_title_has_url_overwrite; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_has_url_overwrite ON cms_title USING btree (has_url_overwrite);


--
-- Name: cms_title_language; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_language ON cms_title USING btree (language);


--
-- Name: cms_title_language_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_language_like ON cms_title USING btree (language varchar_pattern_ops);


--
-- Name: cms_title_page_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_page_id ON cms_title USING btree (page_id);


--
-- Name: cms_title_path; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_path ON cms_title USING btree (path);


--
-- Name: cms_title_path_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_path_like ON cms_title USING btree (path varchar_pattern_ops);


--
-- Name: cms_title_publisher_is_draft; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_publisher_is_draft ON cms_title USING btree (publisher_is_draft);


--
-- Name: cms_title_publisher_state; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_publisher_state ON cms_title USING btree (publisher_state);


--
-- Name: cms_title_slug; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_slug ON cms_title USING btree (slug);


--
-- Name: cms_title_slug_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_slug_like ON cms_title USING btree (slug varchar_pattern_ops);


--
-- Name: cms_usersettings_clipboard_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_usersettings_clipboard_id ON cms_usersettings USING btree (clipboard_id);


--
-- Name: cms_usersettings_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_usersettings_user_id ON cms_usersettings USING btree (user_id);


--
-- Name: cmsplugin_filerfile_file_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cmsplugin_filerfile_file_id ON cmsplugin_filer_file_filerfile USING btree (file_id);


--
-- Name: cmsplugin_filerimage_file_link_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cmsplugin_filerimage_file_link_id ON cmsplugin_filer_image_filerimage USING btree (file_link_id);


--
-- Name: cmsplugin_filerimage_image_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cmsplugin_filerimage_image_id ON cmsplugin_filer_image_filerimage USING btree (image_id);


--
-- Name: cmsplugin_filerimage_page_link_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cmsplugin_filerimage_page_link_id ON cmsplugin_filer_image_filerimage USING btree (page_link_id);


--
-- Name: cmsplugin_filerimage_thumbnail_option_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cmsplugin_filerimage_thumbnail_option_id ON cmsplugin_filer_image_filerimage USING btree (thumbnail_option_id);


--
-- Name: cmsplugin_formplugin_page_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cmsplugin_formplugin_page_id ON aldryn_forms_formplugin USING btree (page_id);


--
-- Name: cmsplugin_placeholderreference_placeholder_ref_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cmsplugin_placeholderreference_placeholder_ref_id ON cms_placeholderreference USING btree (placeholder_ref_id);


--
-- Name: django_admin_log_content_type_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_admin_log_content_type_id ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_admin_log_user_id ON django_admin_log USING btree (user_id);


--
-- Name: django_dbcache_expires; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_dbcache_expires ON django_dbcache USING btree (expires);


--
-- Name: django_select2_keymap_key_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_select2_keymap_key_like ON django_select2_keymap USING btree (key varchar_pattern_ops);


--
-- Name: django_session_expire_date; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_session_expire_date ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_session_session_key_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: djangocms_link_link_page_link_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX djangocms_link_link_page_link_id ON djangocms_link_link USING btree (page_link_id);


--
-- Name: djangocms_snippet_snippet_name_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX djangocms_snippet_snippet_name_like ON djangocms_snippet_snippet USING btree (name varchar_pattern_ops);


--
-- Name: djangocms_snippet_snippetptr_snippet_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX djangocms_snippet_snippetptr_snippet_id ON djangocms_snippet_snippetptr USING btree (snippet_id);


--
-- Name: easy_thumbnails_source_name; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX easy_thumbnails_source_name ON easy_thumbnails_source USING btree (name);


--
-- Name: easy_thumbnails_source_storage_hash; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX easy_thumbnails_source_storage_hash ON easy_thumbnails_source USING btree (storage_hash);


--
-- Name: easy_thumbnails_thumbnail_name; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX easy_thumbnails_thumbnail_name ON easy_thumbnails_thumbnail USING btree (name);


--
-- Name: easy_thumbnails_thumbnail_source_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX easy_thumbnails_thumbnail_source_id ON easy_thumbnails_thumbnail USING btree (source_id);


--
-- Name: easy_thumbnails_thumbnail_storage_hash; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX easy_thumbnails_thumbnail_storage_hash ON easy_thumbnails_thumbnail USING btree (storage_hash);


--
-- Name: filer_clipboard_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_clipboard_user_id ON filer_clipboard USING btree (user_id);


--
-- Name: filer_clipboarditem_clipboard_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_clipboarditem_clipboard_id ON filer_clipboarditem USING btree (clipboard_id);


--
-- Name: filer_clipboarditem_file_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_clipboarditem_file_id ON filer_clipboarditem USING btree (file_id);


--
-- Name: filer_file_folder_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_file_folder_id ON filer_file USING btree (folder_id);


--
-- Name: filer_file_owner_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_file_owner_id ON filer_file USING btree (owner_id);


--
-- Name: filer_file_polymorphic_ctype_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_file_polymorphic_ctype_id ON filer_file USING btree (polymorphic_ctype_id);


--
-- Name: filer_folder_level; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folder_level ON filer_folder USING btree (level);


--
-- Name: filer_folder_lft; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folder_lft ON filer_folder USING btree (lft);


--
-- Name: filer_folder_owner_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folder_owner_id ON filer_folder USING btree (owner_id);


--
-- Name: filer_folder_parent_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folder_parent_id ON filer_folder USING btree (parent_id);


--
-- Name: filer_folder_rght; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folder_rght ON filer_folder USING btree (rght);


--
-- Name: filer_folder_tree_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folder_tree_id ON filer_folder USING btree (tree_id);


--
-- Name: filer_folderpermission_folder_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folderpermission_folder_id ON filer_folderpermission USING btree (folder_id);


--
-- Name: filer_folderpermission_group_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folderpermission_group_id ON filer_folderpermission USING btree (group_id);


--
-- Name: filer_folderpermission_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folderpermission_user_id ON filer_folderpermission USING btree (user_id);


--
-- Name: reversion_revision_date_created; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX reversion_revision_date_created ON reversion_revision USING btree (date_created);


--
-- Name: reversion_revision_manager_slug; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX reversion_revision_manager_slug ON reversion_revision USING btree (manager_slug);


--
-- Name: reversion_revision_manager_slug_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX reversion_revision_manager_slug_like ON reversion_revision USING btree (manager_slug varchar_pattern_ops);


--
-- Name: reversion_revision_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX reversion_revision_user_id ON reversion_revision USING btree (user_id);


--
-- Name: reversion_version_content_type_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX reversion_version_content_type_id ON reversion_version USING btree (content_type_id);


--
-- Name: reversion_version_object_id_int; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX reversion_version_object_id_int ON reversion_version USING btree (object_id_int);


--
-- Name: reversion_version_revision_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX reversion_version_revision_id ON reversion_version USING btree (revision_id);


--
-- Name: robots_rule_allowed_rule_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX robots_rule_allowed_rule_id ON robots_rule_allowed USING btree (rule_id);


--
-- Name: robots_rule_allowed_url_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX robots_rule_allowed_url_id ON robots_rule_allowed USING btree (url_id);


--
-- Name: robots_rule_disallowed_rule_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX robots_rule_disallowed_rule_id ON robots_rule_disallowed USING btree (rule_id);


--
-- Name: robots_rule_disallowed_url_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX robots_rule_disallowed_url_id ON robots_rule_disallowed USING btree (url_id);


--
-- Name: robots_rule_sites_rule_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX robots_rule_sites_rule_id ON robots_rule_sites USING btree (rule_id);


--
-- Name: robots_rule_sites_site_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX robots_rule_sites_site_id ON robots_rule_sites USING btree (site_id);


--
-- Name: alias_placeholder_id_refs_id_2f6ab753; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_aliaspluginmodel
    ADD CONSTRAINT alias_placeholder_id_refs_id_2f6ab753 FOREIGN KEY (alias_placeholder_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clipboard_id_refs_id_29248006; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_usersettings
    ADD CONSTRAINT clipboard_id_refs_id_29248006 FOREIGN KEY (clipboard_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clipboard_id_refs_id_fd11d4a0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_clipboarditem
    ADD CONSTRAINT clipboard_id_refs_id_fd11d4a0 FOREIGN KEY (clipboard_id) REFERENCES filer_clipboard(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_03752e6e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cmsplugin_filer_image_filerimage
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_03752e6e FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_04cd08a9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_fieldplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_04cd08a9 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_0c0e6fa6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cmsplugin_filer_file_filerfile
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_0c0e6fa6 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_13cf15a3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_formplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_13cf15a3 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_15180c6b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY djangocms_link_link
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_15180c6b FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_2509b51f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelbodyplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_2509b51f FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_2638e014; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_2638e014 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_34ad5108; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY djangocms_text_ckeditor_text
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_34ad5108 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_3dc4645b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3labelplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_3dc4645b FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_49bed0ae; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3blockquoteplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_49bed0ae FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_5b2bc64d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY djangocms_googlemap_googlemap
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_5b2bc64d FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_7459b15b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_formbuttonplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_7459b15b FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_75314bef; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY djangocms_snippet_snippetptr
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_75314bef FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_7587395c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3wellplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_7587395c FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_7f8cd060; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_imageuploadfieldplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_7f8cd060 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_83ae3b7c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslidefolderplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_83ae3b7c FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_8433cb94; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3alertplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_8433cb94 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_888c785f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelfooterplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_888c785f FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_89d244d4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_fileuploadfieldplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_89d244d4 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_8cc1766a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_placeholderreference
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_8cc1766a FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_919f79ce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3buttonplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_919f79ce FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_9541313d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_textareafieldplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_9541313d FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_9808644e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_aliaspluginmodel
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_9808644e FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_9b7cf73d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelheadingplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_9b7cf73d FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_ac601a38; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3listgroupplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_ac601a38 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_aface4e9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslideplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_aface4e9 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_b91508b4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3imageplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_b91508b4 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_ce92c05b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_emailfieldplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_ce92c05b FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_d38f2418; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3columnplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_d38f2418 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_d67faf34; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_style_style
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_d67faf34 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_e015d238; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3listgroupitemplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_e015d238 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_e24a641a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3accordionplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_e24a641a FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_e2a2b105; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_e2a2b105 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_e52fa14e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3rowplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_e52fa14e FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_ea463f2c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3accordionitemplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_ea463f2c FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_ed5a18dd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3spacerplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_ed5a18dd FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_ef662956; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_fieldsetplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_ef662956 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_ptr_id_refs_id_f4435f30; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3iconplugin
    ADD CONSTRAINT cmsplugin_ptr_id_refs_id_f4435f30 FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_d043b34a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT content_type_id_refs_id_d043b34a FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_f5dce86c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reversion_version
    ADD CONSTRAINT content_type_id_refs_id_f5dce86c FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: created_by_id_refs_id_9da6953b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pageuser
    ADD CONSTRAINT created_by_id_refs_id_9da6953b FOREIGN KEY (created_by_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: created_by_id_refs_id_f9e2dd36; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pageusergroup
    ADD CONSTRAINT created_by_id_refs_id_f9e2dd36 FOREIGN KEY (created_by_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_content_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_fkey FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: draft_id_refs_id_81bff591; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_staticplaceholder
    ADD CONSTRAINT draft_id_refs_id_81bff591 FOREIGN KEY (draft_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: field_id_refs_cmsplugin_ptr_id_12885e78; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_option
    ADD CONSTRAINT field_id_refs_cmsplugin_ptr_id_12885e78 FOREIGN KEY (field_id) REFERENCES aldryn_forms_fieldplugin(cmsplugin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: file_id_refs_file_ptr_id_2f703071; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3imageplugin
    ADD CONSTRAINT file_id_refs_file_ptr_id_2f703071 FOREIGN KEY (file_id) REFERENCES filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: file_id_refs_id_a0a03232; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cmsplugin_filer_file_filerfile
    ADD CONSTRAINT file_id_refs_id_a0a03232 FOREIGN KEY (file_id) REFERENCES filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: file_id_refs_id_a869c276; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_clipboarditem
    ADD CONSTRAINT file_id_refs_id_a869c276 FOREIGN KEY (file_id) REFERENCES filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: file_id_refs_id_ce6ce86a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3buttonplugin
    ADD CONSTRAINT file_id_refs_id_ce6ce86a FOREIGN KEY (link_file_id) REFERENCES filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: file_link_id_refs_id_3a714936; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cmsplugin_filer_image_filerimage
    ADD CONSTRAINT file_link_id_refs_id_3a714936 FOREIGN KEY (file_link_id) REFERENCES filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: file_ptr_id_refs_id_7375d00c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_image
    ADD CONSTRAINT file_ptr_id_refs_id_7375d00c FOREIGN KEY (file_ptr_id) REFERENCES filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: folder_id_refs_id_41348f39; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_file
    ADD CONSTRAINT folder_id_refs_id_41348f39 FOREIGN KEY (folder_id) REFERENCES filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: folder_id_refs_id_4e30d5f7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslidefolderplugin
    ADD CONSTRAINT folder_id_refs_id_4e30d5f7 FOREIGN KEY (folder_id) REFERENCES filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: folder_id_refs_id_b2c18baf; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_folderpermission
    ADD CONSTRAINT folder_id_refs_id_b2c18baf FOREIGN KEY (folder_id) REFERENCES filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: formdata_id_refs_id_fc097e6d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_formdata_people_notified
    ADD CONSTRAINT formdata_id_refs_id_fc097e6d FOREIGN KEY (formdata_id) REFERENCES aldryn_forms_formdata(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: formplugin_id_refs_cmsplugin_ptr_id_ee7ed1a2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_formplugin_recipients
    ADD CONSTRAINT formplugin_id_refs_cmsplugin_ptr_id_ee7ed1a2 FOREIGN KEY (formplugin_id) REFERENCES aldryn_forms_formplugin(cmsplugin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: globalpagepermission_id_refs_id_09b826f9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_globalpagepermission_sites
    ADD CONSTRAINT globalpagepermission_id_refs_id_09b826f9 FOREIGN KEY (globalpagepermission_id) REFERENCES cms_globalpagepermission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_5f980916; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_globalpagepermission
    ADD CONSTRAINT group_id_refs_id_5f980916 FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_65c5081c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pagepermission
    ADD CONSTRAINT group_id_refs_id_65c5081c FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_f4b32aac; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT group_id_refs_id_f4b32aac FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_f86eccc7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_folderpermission
    ADD CONSTRAINT group_id_refs_id_f86eccc7 FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_ptr_id_refs_id_b270d7fc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pageusergroup
    ADD CONSTRAINT group_ptr_id_refs_id_b270d7fc FOREIGN KEY (group_ptr_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: image_id_refs_file_ptr_id_93ad39ea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslideplugin
    ADD CONSTRAINT image_id_refs_file_ptr_id_93ad39ea FOREIGN KEY (image_id) REFERENCES filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: image_id_refs_file_ptr_id_affb196b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cmsplugin_filer_image_filerimage
    ADD CONSTRAINT image_id_refs_file_ptr_id_affb196b FOREIGN KEY (image_id) REFERENCES filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: link_file_id_refs_id_f7ce579a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslideplugin
    ADD CONSTRAINT link_file_id_refs_id_f7ce579a FOREIGN KEY (link_file_id) REFERENCES filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: link_page_id_refs_id_8769c837; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslideplugin
    ADD CONSTRAINT link_page_id_refs_id_8769c837 FOREIGN KEY (link_page_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: owner_id_refs_id_a6490af8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_file
    ADD CONSTRAINT owner_id_refs_id_a6490af8 FOREIGN KEY (owner_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: owner_id_refs_id_a9e7dcbc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_folder
    ADD CONSTRAINT owner_id_refs_id_a9e7dcbc FOREIGN KEY (owner_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: page_id_refs_id_0d5e81b6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_title
    ADD CONSTRAINT page_id_refs_id_0d5e81b6 FOREIGN KEY (page_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: page_id_refs_id_3e9cd06c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_formplugin
    ADD CONSTRAINT page_id_refs_id_3e9cd06c FOREIGN KEY (page_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: page_id_refs_id_88abf373; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_page_placeholders
    ADD CONSTRAINT page_id_refs_id_88abf373 FOREIGN KEY (page_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: page_id_refs_id_9d95001c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pagepermission
    ADD CONSTRAINT page_id_refs_id_9d95001c FOREIGN KEY (page_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: page_link_id_refs_id_261dd694; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY djangocms_link_link
    ADD CONSTRAINT page_link_id_refs_id_261dd694 FOREIGN KEY (page_link_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: page_link_id_refs_id_70de2e4a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cmsplugin_filer_image_filerimage
    ADD CONSTRAINT page_link_id_refs_id_70de2e4a FOREIGN KEY (page_link_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: page_link_id_refs_id_fd708e20; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3buttonplugin
    ADD CONSTRAINT page_link_id_refs_id_fd708e20 FOREIGN KEY (link_page_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parent_id_refs_id_42b2c54f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_folder
    ADD CONSTRAINT parent_id_refs_id_42b2c54f FOREIGN KEY (parent_id) REFERENCES filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parent_id_refs_id_8d462df0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_cmsplugin
    ADD CONSTRAINT parent_id_refs_id_8d462df0 FOREIGN KEY (parent_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parent_id_refs_id_ca1f299f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT parent_id_refs_id_ca1f299f FOREIGN KEY (parent_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: placeholder_id_refs_id_0c0bdf3b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_page_placeholders
    ADD CONSTRAINT placeholder_id_refs_id_0c0bdf3b FOREIGN KEY (placeholder_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: placeholder_id_refs_id_6e7caeb8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_cmsplugin
    ADD CONSTRAINT placeholder_id_refs_id_6e7caeb8 FOREIGN KEY (placeholder_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: placeholder_ref_id_refs_id_01a30ec3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_placeholderreference
    ADD CONSTRAINT placeholder_ref_id_refs_id_01a30ec3 FOREIGN KEY (placeholder_ref_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: plugin_id_refs_id_9808644e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_aliaspluginmodel
    ADD CONSTRAINT plugin_id_refs_id_9808644e FOREIGN KEY (plugin_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: polymorphic_ctype_id_refs_id_a03609f3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_file
    ADD CONSTRAINT polymorphic_ctype_id_refs_id_a03609f3 FOREIGN KEY (polymorphic_ctype_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public_id_refs_id_81bff591; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_staticplaceholder
    ADD CONSTRAINT public_id_refs_id_81bff591 FOREIGN KEY (public_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: publisher_public_id_refs_id_579fc503; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_title
    ADD CONSTRAINT publisher_public_id_refs_id_579fc503 FOREIGN KEY (publisher_public_id) REFERENCES cms_title(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: publisher_public_id_refs_id_ca1f299f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT publisher_public_id_refs_id_ca1f299f FOREIGN KEY (publisher_public_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: revision_id_refs_id_a685e913; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reversion_version
    ADD CONSTRAINT revision_id_refs_id_a685e913 FOREIGN KEY (revision_id) REFERENCES reversion_revision(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rule_id_refs_id_5039b4d0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY robots_rule_disallowed
    ADD CONSTRAINT rule_id_refs_id_5039b4d0 FOREIGN KEY (rule_id) REFERENCES robots_rule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rule_id_refs_id_6628ceda; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY robots_rule_allowed
    ADD CONSTRAINT rule_id_refs_id_6628ceda FOREIGN KEY (rule_id) REFERENCES robots_rule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rule_id_refs_id_80b741d5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY robots_rule_sites
    ADD CONSTRAINT rule_id_refs_id_80b741d5 FOREIGN KEY (rule_id) REFERENCES robots_rule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_3757c4f9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_globalpagepermission_sites
    ADD CONSTRAINT site_id_refs_id_3757c4f9 FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_5f61f09c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT site_id_refs_id_5f61f09c FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_a6b8e345; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY robots_rule_sites
    ADD CONSTRAINT site_id_refs_id_a6b8e345 FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_ed874bfd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_staticplaceholder
    ADD CONSTRAINT site_id_refs_id_ed874bfd FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: snippet_id_refs_id_c37eba3f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY djangocms_snippet_snippetptr
    ADD CONSTRAINT snippet_id_refs_id_c37eba3f FOREIGN KEY (snippet_id) REFERENCES djangocms_snippet_snippet(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: source_id_refs_id_0df57a91; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY easy_thumbnails_thumbnail
    ADD CONSTRAINT source_id_refs_id_0df57a91 FOREIGN KEY (source_id) REFERENCES easy_thumbnails_source(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: thumbnail_id_refs_id_ef901436; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT thumbnail_id_refs_id_ef901436 FOREIGN KEY (thumbnail_id) REFERENCES easy_thumbnails_thumbnail(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: thumbnail_option_id_refs_id_c267cfb1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cmsplugin_filer_image_filerimage
    ADD CONSTRAINT thumbnail_option_id_refs_id_c267cfb1 FOREIGN KEY (thumbnail_option_id) REFERENCES cmsplugin_filer_image_thumbnailoption(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: upload_to_id_refs_id_34c2de5b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_imageuploadfieldplugin
    ADD CONSTRAINT upload_to_id_refs_id_34c2de5b FOREIGN KEY (upload_to_id) REFERENCES filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: upload_to_id_refs_id_3d6256c5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_fileuploadfieldplugin
    ADD CONSTRAINT upload_to_id_refs_id_3d6256c5 FOREIGN KEY (upload_to_id) REFERENCES filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: url_id_refs_id_8a66576e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY robots_rule_disallowed
    ADD CONSTRAINT url_id_refs_id_8a66576e FOREIGN KEY (url_id) REFERENCES robots_url(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: url_id_refs_id_fdf7b079; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY robots_rule_allowed
    ADD CONSTRAINT url_id_refs_id_fdf7b079 FOREIGN KEY (url_id) REFERENCES robots_url(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_1f964794; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_globalpagepermission
    ADD CONSTRAINT user_id_refs_id_1f964794 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_2bc29acf; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_folderpermission
    ADD CONSTRAINT user_id_refs_id_2bc29acf FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_40c41112; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT user_id_refs_id_40c41112 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_4dc23c39; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT user_id_refs_id_4dc23c39 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_5b2d2788; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_clipboard
    ADD CONSTRAINT user_id_refs_id_5b2d2788 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_5f222118; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_usersettings
    ADD CONSTRAINT user_id_refs_id_5f222118 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_81bc8eaa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cmscloud_aldrynclouduser
    ADD CONSTRAINT user_id_refs_id_81bc8eaa FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_8f2b5afc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_formdata_people_notified
    ADD CONSTRAINT user_id_refs_id_8f2b5afc FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_d4f35b51; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reversion_revision
    ADD CONSTRAINT user_id_refs_id_d4f35b51 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_e927b528; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pagepermission
    ADD CONSTRAINT user_id_refs_id_e927b528 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_f2aeced6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_forms_formplugin_recipients
    ADD CONSTRAINT user_id_refs_id_f2aeced6 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_ptr_id_refs_id_9da6953b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pageuser
    ADD CONSTRAINT user_ptr_id_refs_id_9da6953b FOREIGN KEY (user_ptr_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: finalangel
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM finalangel;
GRANT ALL ON SCHEMA public TO finalangel;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

