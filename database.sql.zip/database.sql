--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: aldryn_bootstrap3_boostrap3alertplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3alertplugin (
    cmsplugin_ptr_id integer NOT NULL,
    context character varying(255) NOT NULL,
    icon character varying(255) NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3alertplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3blockquoteplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3blockquoteplugin (
    cmsplugin_ptr_id integer NOT NULL,
    reverse boolean NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3blockquoteplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3buttonplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3buttonplugin (
    link_url character varying(200) NOT NULL,
    link_anchor character varying(128) NOT NULL,
    link_mailto character varying(75),
    link_phone character varying(40),
    link_target character varying(100) NOT NULL,
    cmsplugin_ptr_id integer NOT NULL,
    label character varying(256) NOT NULL,
    type character varying(10) NOT NULL,
    btn_context character varying(255) NOT NULL,
    btn_size character varying(255) NOT NULL,
    btn_block boolean NOT NULL,
    txt_context character varying(255) NOT NULL,
    icon_left character varying(255) NOT NULL,
    icon_right character varying(255) NOT NULL,
    classes text NOT NULL,
    responsive text NOT NULL,
    responsive_print text NOT NULL,
    link_file_id integer,
    link_page_id integer
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3buttonplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3iconplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3iconplugin (
    cmsplugin_ptr_id integer NOT NULL,
    icon character varying(255) NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3iconplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3imageplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3imageplugin (
    cmsplugin_ptr_id integer NOT NULL,
    alt text NOT NULL,
    title text NOT NULL,
    aspect_ratio character varying(10) NOT NULL,
    thumbnail boolean NOT NULL,
    shape character varying(64) NOT NULL,
    classes text NOT NULL,
    img_responsive boolean NOT NULL,
    file_id integer
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3imageplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3labelplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3labelplugin (
    cmsplugin_ptr_id integer NOT NULL,
    label character varying(256) NOT NULL,
    context character varying(255) NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3labelplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3panelbodyplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3panelbodyplugin (
    cmsplugin_ptr_id integer NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3panelbodyplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3panelfooterplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3panelfooterplugin (
    cmsplugin_ptr_id integer NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3panelfooterplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3panelheadingplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3panelheadingplugin (
    cmsplugin_ptr_id integer NOT NULL,
    title text NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3panelheadingplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3panelplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3panelplugin (
    cmsplugin_ptr_id integer NOT NULL,
    context character varying(255) NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3panelplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3spacerplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3spacerplugin (
    cmsplugin_ptr_id integer NOT NULL,
    size character varying(255) NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3spacerplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_boostrap3wellplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_boostrap3wellplugin (
    cmsplugin_ptr_id integer NOT NULL,
    size character varying(255) NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_boostrap3wellplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3accordionitemplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3accordionitemplugin (
    cmsplugin_ptr_id integer NOT NULL,
    title text NOT NULL,
    context character varying(255) NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3accordionitemplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3accordionplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3accordionplugin (
    cmsplugin_ptr_id integer NOT NULL,
    index integer,
    classes text NOT NULL,
    CONSTRAINT aldryn_bootstrap3_bootstrap3accordionplugin_index_check CHECK ((index >= 0))
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3accordionplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3carouselplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3carouselplugin (
    cmsplugin_ptr_id integer NOT NULL,
    style character varying(50) NOT NULL,
    aspect_ratio character varying(10) NOT NULL,
    transition_effect character varying(50) NOT NULL,
    ride boolean NOT NULL,
    "interval" integer NOT NULL,
    wrap boolean NOT NULL,
    pause boolean NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3carouselplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3carouselslidefolderplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3carouselslidefolderplugin (
    cmsplugin_ptr_id integer NOT NULL,
    classes text NOT NULL,
    folder_id integer NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3carouselslidefolderplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3carouselslideplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3carouselslideplugin (
    cmsplugin_ptr_id integer NOT NULL,
    link_url character varying(200) NOT NULL,
    link_anchor character varying(128) NOT NULL,
    link_mailto character varying(75),
    link_phone character varying(40),
    link_target character varying(100) NOT NULL,
    link_text character varying(200) NOT NULL,
    content text NOT NULL,
    classes text NOT NULL,
    image_id integer,
    link_file_id integer,
    link_page_id integer
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3carouselslideplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3columnplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3columnplugin (
    cmsplugin_ptr_id integer NOT NULL,
    classes text NOT NULL,
    tag character varying(50) NOT NULL,
    xs_col integer,
    xs_offset integer,
    xs_push integer,
    xs_pull integer,
    sm_col integer,
    sm_offset integer,
    sm_push integer,
    sm_pull integer,
    md_col integer,
    md_offset integer,
    md_push integer,
    md_pull integer,
    lg_col integer,
    lg_offset integer,
    lg_push integer,
    lg_pull integer
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3columnplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3fileplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3fileplugin (
    cmsplugin_ptr_id integer NOT NULL,
    name text NOT NULL,
    open_new_window boolean NOT NULL,
    show_file_size boolean NOT NULL,
    icon_left character varying(255) NOT NULL,
    icon_right character varying(255) NOT NULL,
    classes text NOT NULL,
    file_id integer
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3fileplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3listgroupitemplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3listgroupitemplugin (
    cmsplugin_ptr_id integer NOT NULL,
    title text NOT NULL,
    context character varying(255) NOT NULL,
    state character varying(255) NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3listgroupitemplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3listgroupplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3listgroupplugin (
    cmsplugin_ptr_id integer NOT NULL,
    classes text NOT NULL,
    add_list_group_class boolean NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3listgroupplugin OWNER TO postgres;

--
-- Name: aldryn_bootstrap3_bootstrap3rowplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_bootstrap3_bootstrap3rowplugin (
    cmsplugin_ptr_id integer NOT NULL,
    classes text NOT NULL
);


ALTER TABLE public.aldryn_bootstrap3_bootstrap3rowplugin OWNER TO postgres;

--
-- Name: aldryn_categories_category; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_categories_category (
    id integer NOT NULL,
    lft integer NOT NULL,
    rgt integer NOT NULL,
    tree_id integer NOT NULL,
    depth integer NOT NULL,
    CONSTRAINT aldryn_categories_category_depth_check CHECK ((depth >= 0)),
    CONSTRAINT aldryn_categories_category_lft_check CHECK ((lft >= 0)),
    CONSTRAINT aldryn_categories_category_rgt_check CHECK ((rgt >= 0)),
    CONSTRAINT aldryn_categories_category_tree_id_check CHECK ((tree_id >= 0))
);


ALTER TABLE public.aldryn_categories_category OWNER TO postgres;

--
-- Name: aldryn_categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_categories_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_categories_category_id_seq OWNER TO postgres;

--
-- Name: aldryn_categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_categories_category_id_seq OWNED BY aldryn_categories_category.id;


--
-- Name: aldryn_categories_category_translation; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_categories_category_translation (
    id integer NOT NULL,
    language_code character varying(15) NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    master_id integer
);


ALTER TABLE public.aldryn_categories_category_translation OWNER TO postgres;

--
-- Name: aldryn_categories_category_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_categories_category_translation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_categories_category_translation_id_seq OWNER TO postgres;

--
-- Name: aldryn_categories_category_translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_categories_category_translation_id_seq OWNED BY aldryn_categories_category_translation.id;


--
-- Name: aldryn_newsblog_article; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_newsblog_article (
    id integer NOT NULL,
    publishing_date timestamp with time zone NOT NULL,
    is_published boolean NOT NULL,
    is_featured boolean NOT NULL,
    app_config_id integer NOT NULL,
    author_id integer,
    content_id integer,
    featured_image_id integer,
    owner_id integer NOT NULL
);


ALTER TABLE public.aldryn_newsblog_article OWNER TO postgres;

--
-- Name: aldryn_newsblog_article_categories; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_newsblog_article_categories (
    id integer NOT NULL,
    article_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.aldryn_newsblog_article_categories OWNER TO postgres;

--
-- Name: aldryn_newsblog_article_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_newsblog_article_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_newsblog_article_categories_id_seq OWNER TO postgres;

--
-- Name: aldryn_newsblog_article_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_newsblog_article_categories_id_seq OWNED BY aldryn_newsblog_article_categories.id;


--
-- Name: aldryn_newsblog_article_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_newsblog_article_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_newsblog_article_id_seq OWNER TO postgres;

--
-- Name: aldryn_newsblog_article_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_newsblog_article_id_seq OWNED BY aldryn_newsblog_article.id;


--
-- Name: aldryn_newsblog_article_related; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_newsblog_article_related (
    id integer NOT NULL,
    from_article_id integer NOT NULL,
    to_article_id integer NOT NULL,
    sort_value integer NOT NULL
);


ALTER TABLE public.aldryn_newsblog_article_related OWNER TO postgres;

--
-- Name: aldryn_newsblog_article_related_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_newsblog_article_related_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_newsblog_article_related_id_seq OWNER TO postgres;

--
-- Name: aldryn_newsblog_article_related_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_newsblog_article_related_id_seq OWNED BY aldryn_newsblog_article_related.id;


--
-- Name: aldryn_newsblog_article_translation; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_newsblog_article_translation (
    id integer NOT NULL,
    language_code character varying(15) NOT NULL,
    title character varying(234) NOT NULL,
    slug character varying(255) NOT NULL,
    lead_in text NOT NULL,
    meta_title character varying(255) NOT NULL,
    meta_description text NOT NULL,
    meta_keywords text NOT NULL,
    search_data text NOT NULL,
    master_id integer
);


ALTER TABLE public.aldryn_newsblog_article_translation OWNER TO postgres;

--
-- Name: aldryn_newsblog_article_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_newsblog_article_translation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_newsblog_article_translation_id_seq OWNER TO postgres;

--
-- Name: aldryn_newsblog_article_translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_newsblog_article_translation_id_seq OWNED BY aldryn_newsblog_article_translation.id;


--
-- Name: aldryn_newsblog_newsblogarchiveplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_newsblog_newsblogarchiveplugin (
    cmsplugin_ptr_id integer NOT NULL,
    app_config_id integer NOT NULL
);


ALTER TABLE public.aldryn_newsblog_newsblogarchiveplugin OWNER TO postgres;

--
-- Name: aldryn_newsblog_newsblogarticlesearchplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_newsblog_newsblogarticlesearchplugin (
    cmsplugin_ptr_id integer NOT NULL,
    max_articles integer NOT NULL,
    app_config_id integer NOT NULL,
    CONSTRAINT aldryn_newsblog_newsblogarticlesearchplugin_max_articles_check CHECK ((max_articles >= 0))
);


ALTER TABLE public.aldryn_newsblog_newsblogarticlesearchplugin OWNER TO postgres;

--
-- Name: aldryn_newsblog_newsblogauthorsplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_newsblog_newsblogauthorsplugin (
    cmsplugin_ptr_id integer NOT NULL,
    app_config_id integer NOT NULL
);


ALTER TABLE public.aldryn_newsblog_newsblogauthorsplugin OWNER TO postgres;

--
-- Name: aldryn_newsblog_newsblogcategoriesplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_newsblog_newsblogcategoriesplugin (
    cmsplugin_ptr_id integer NOT NULL,
    app_config_id integer NOT NULL
);


ALTER TABLE public.aldryn_newsblog_newsblogcategoriesplugin OWNER TO postgres;

--
-- Name: aldryn_newsblog_newsblogconfig; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_newsblog_newsblogconfig (
    id integer NOT NULL,
    type character varying(100) NOT NULL,
    namespace character varying(100) NOT NULL,
    app_data text NOT NULL,
    permalink_type character varying(8) NOT NULL,
    non_permalink_handling smallint NOT NULL,
    paginate_by integer NOT NULL,
    create_authors boolean NOT NULL,
    search_indexed boolean NOT NULL,
    placeholder_base_sidebar_id integer,
    placeholder_base_top_id integer,
    placeholder_detail_bottom_id integer,
    placeholder_detail_footer_id integer,
    placeholder_detail_top_id integer,
    placeholder_list_footer_id integer,
    placeholder_list_top_id integer,
    template_prefix character varying(20),
    CONSTRAINT aldryn_newsblog_newsblogconfig_paginate_by_check CHECK ((paginate_by >= 0))
);


ALTER TABLE public.aldryn_newsblog_newsblogconfig OWNER TO postgres;

--
-- Name: aldryn_newsblog_newsblogconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_newsblog_newsblogconfig_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_newsblog_newsblogconfig_id_seq OWNER TO postgres;

--
-- Name: aldryn_newsblog_newsblogconfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_newsblog_newsblogconfig_id_seq OWNED BY aldryn_newsblog_newsblogconfig.id;


--
-- Name: aldryn_newsblog_newsblogconfig_translation; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_newsblog_newsblogconfig_translation (
    id integer NOT NULL,
    language_code character varying(15) NOT NULL,
    app_title character varying(234) NOT NULL,
    master_id integer
);


ALTER TABLE public.aldryn_newsblog_newsblogconfig_translation OWNER TO postgres;

--
-- Name: aldryn_newsblog_newsblogconfig_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_newsblog_newsblogconfig_translation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_newsblog_newsblogconfig_translation_id_seq OWNER TO postgres;

--
-- Name: aldryn_newsblog_newsblogconfig_translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_newsblog_newsblogconfig_translation_id_seq OWNED BY aldryn_newsblog_newsblogconfig_translation.id;


--
-- Name: aldryn_newsblog_newsblogfeaturedarticlesplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_newsblog_newsblogfeaturedarticlesplugin (
    cmsplugin_ptr_id integer NOT NULL,
    article_count integer NOT NULL,
    app_config_id integer NOT NULL,
    CONSTRAINT aldryn_newsblog_newsblogfeaturedarticlesplu_article_count_check CHECK ((article_count >= 0))
);


ALTER TABLE public.aldryn_newsblog_newsblogfeaturedarticlesplugin OWNER TO postgres;

--
-- Name: aldryn_newsblog_newsbloglatestarticlesplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_newsblog_newsbloglatestarticlesplugin (
    cmsplugin_ptr_id integer NOT NULL,
    latest_articles integer NOT NULL,
    app_config_id integer NOT NULL
);


ALTER TABLE public.aldryn_newsblog_newsbloglatestarticlesplugin OWNER TO postgres;

--
-- Name: aldryn_newsblog_newsblogrelatedplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_newsblog_newsblogrelatedplugin (
    cmsplugin_ptr_id integer NOT NULL
);


ALTER TABLE public.aldryn_newsblog_newsblogrelatedplugin OWNER TO postgres;

--
-- Name: aldryn_newsblog_newsblogtagsplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_newsblog_newsblogtagsplugin (
    cmsplugin_ptr_id integer NOT NULL,
    app_config_id integer NOT NULL
);


ALTER TABLE public.aldryn_newsblog_newsblogtagsplugin OWNER TO postgres;

--
-- Name: aldryn_people_group; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_people_group (
    id integer NOT NULL,
    address text NOT NULL,
    postal_code character varying(20) NOT NULL,
    city character varying(255) NOT NULL,
    phone character varying(100),
    fax character varying(100),
    email character varying(75) NOT NULL,
    website character varying(200)
);


ALTER TABLE public.aldryn_people_group OWNER TO postgres;

--
-- Name: aldryn_people_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_people_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_people_group_id_seq OWNER TO postgres;

--
-- Name: aldryn_people_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_people_group_id_seq OWNED BY aldryn_people_group.id;


--
-- Name: aldryn_people_group_translation; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_people_group_translation (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    language_code character varying(15) NOT NULL,
    master_id integer
);


ALTER TABLE public.aldryn_people_group_translation OWNER TO postgres;

--
-- Name: aldryn_people_group_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_people_group_translation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_people_group_translation_id_seq OWNER TO postgres;

--
-- Name: aldryn_people_group_translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_people_group_translation_id_seq OWNED BY aldryn_people_group_translation.id;


--
-- Name: aldryn_people_peopleplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_people_peopleplugin (
    cmsplugin_ptr_id integer NOT NULL,
    style character varying(50) NOT NULL,
    group_by_group boolean NOT NULL,
    show_links boolean NOT NULL,
    show_vcard boolean NOT NULL
);


ALTER TABLE public.aldryn_people_peopleplugin OWNER TO postgres;

--
-- Name: aldryn_people_peopleplugin_people; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_people_peopleplugin_people (
    id integer NOT NULL,
    peopleplugin_id integer NOT NULL,
    person_id integer NOT NULL,
    sort_value integer NOT NULL
);


ALTER TABLE public.aldryn_people_peopleplugin_people OWNER TO postgres;

--
-- Name: aldryn_people_peopleplugin_people_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_people_peopleplugin_people_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_people_peopleplugin_people_id_seq OWNER TO postgres;

--
-- Name: aldryn_people_peopleplugin_people_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_people_peopleplugin_people_id_seq OWNED BY aldryn_people_peopleplugin_people.id;


--
-- Name: aldryn_people_person; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_people_person (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    phone character varying(100),
    mobile character varying(100),
    fax character varying(100),
    email character varying(75) NOT NULL,
    website character varying(200),
    slug character varying(255),
    vcard_enabled boolean NOT NULL,
    group_id integer,
    user_id integer,
    visual_id integer
);


ALTER TABLE public.aldryn_people_person OWNER TO postgres;

--
-- Name: aldryn_people_person_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_people_person_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_people_person_id_seq OWNER TO postgres;

--
-- Name: aldryn_people_person_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_people_person_id_seq OWNED BY aldryn_people_person.id;


--
-- Name: aldryn_people_person_translation; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_people_person_translation (
    id integer NOT NULL,
    function character varying(255) NOT NULL,
    description text NOT NULL,
    language_code character varying(15) NOT NULL,
    master_id integer
);


ALTER TABLE public.aldryn_people_person_translation OWNER TO postgres;

--
-- Name: aldryn_people_person_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aldryn_people_person_translation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aldryn_people_person_translation_id_seq OWNER TO postgres;

--
-- Name: aldryn_people_person_translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aldryn_people_person_translation_id_seq OWNED BY aldryn_people_person_translation.id;


--
-- Name: aldryn_style_style; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE aldryn_style_style (
    label character varying(128) NOT NULL,
    cmsplugin_ptr_id integer NOT NULL,
    class_name character varying(50) NOT NULL,
    id_name character varying(50) NOT NULL,
    tag_type character varying(50) NOT NULL,
    padding_left smallint,
    padding_right smallint,
    padding_top smallint,
    padding_bottom smallint,
    margin_left smallint,
    margin_right smallint,
    margin_top smallint,
    margin_bottom smallint,
    additional_class_names text NOT NULL
);


ALTER TABLE public.aldryn_style_style OWNER TO postgres;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: cms_aliaspluginmodel; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_aliaspluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    plugin_id integer,
    alias_placeholder_id integer
);


ALTER TABLE public.cms_aliaspluginmodel OWNER TO postgres;

--
-- Name: cms_cmsplugin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_cmsplugin (
    id integer NOT NULL,
    "position" smallint,
    language character varying(15) NOT NULL,
    plugin_type character varying(50) NOT NULL,
    creation_date timestamp with time zone NOT NULL,
    changed_date timestamp with time zone NOT NULL,
    parent_id integer,
    placeholder_id integer,
    depth integer NOT NULL,
    numchild integer NOT NULL,
    path character varying(255) NOT NULL,
    CONSTRAINT cms_cmsplugin_depth_check CHECK ((depth >= 0)),
    CONSTRAINT cms_cmsplugin_numchild_check CHECK ((numchild >= 0)),
    CONSTRAINT cms_cmsplugin_position_check CHECK (("position" >= 0))
);


ALTER TABLE public.cms_cmsplugin OWNER TO postgres;

--
-- Name: cms_cmsplugin_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_cmsplugin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_cmsplugin_id_seq OWNER TO postgres;

--
-- Name: cms_cmsplugin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_cmsplugin_id_seq OWNED BY cms_cmsplugin.id;


--
-- Name: cms_globalpagepermission; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_globalpagepermission (
    id integer NOT NULL,
    can_change boolean NOT NULL,
    can_add boolean NOT NULL,
    can_delete boolean NOT NULL,
    can_change_advanced_settings boolean NOT NULL,
    can_publish boolean NOT NULL,
    can_change_permissions boolean NOT NULL,
    can_move_page boolean NOT NULL,
    can_view boolean NOT NULL,
    can_recover_page boolean NOT NULL,
    group_id integer,
    user_id integer
);


ALTER TABLE public.cms_globalpagepermission OWNER TO postgres;

--
-- Name: cms_globalpagepermission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_globalpagepermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_globalpagepermission_id_seq OWNER TO postgres;

--
-- Name: cms_globalpagepermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_globalpagepermission_id_seq OWNED BY cms_globalpagepermission.id;


--
-- Name: cms_globalpagepermission_sites; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_globalpagepermission_sites (
    id integer NOT NULL,
    globalpagepermission_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.cms_globalpagepermission_sites OWNER TO postgres;

--
-- Name: cms_globalpagepermission_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_globalpagepermission_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_globalpagepermission_sites_id_seq OWNER TO postgres;

--
-- Name: cms_globalpagepermission_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_globalpagepermission_sites_id_seq OWNED BY cms_globalpagepermission_sites.id;


--
-- Name: cms_page; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_page (
    id integer NOT NULL,
    created_by character varying(255) NOT NULL,
    changed_by character varying(255) NOT NULL,
    creation_date timestamp with time zone NOT NULL,
    changed_date timestamp with time zone NOT NULL,
    publication_date timestamp with time zone,
    publication_end_date timestamp with time zone,
    in_navigation boolean NOT NULL,
    soft_root boolean NOT NULL,
    reverse_id character varying(40),
    navigation_extenders character varying(80),
    template character varying(100) NOT NULL,
    login_required boolean NOT NULL,
    limit_visibility_in_menu smallint,
    is_home boolean NOT NULL,
    application_urls character varying(200),
    application_namespace character varying(200),
    publisher_is_draft boolean NOT NULL,
    languages character varying(255),
    revision_id integer NOT NULL,
    xframe_options integer NOT NULL,
    parent_id integer,
    publisher_public_id integer,
    site_id integer NOT NULL,
    depth integer NOT NULL,
    numchild integer NOT NULL,
    path character varying(255) NOT NULL,
    CONSTRAINT cms_page_depth_check CHECK ((depth >= 0)),
    CONSTRAINT cms_page_numchild_check CHECK ((numchild >= 0)),
    CONSTRAINT cms_page_revision_id_check CHECK ((revision_id >= 0))
);


ALTER TABLE public.cms_page OWNER TO postgres;

--
-- Name: cms_page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_page_id_seq OWNER TO postgres;

--
-- Name: cms_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_page_id_seq OWNED BY cms_page.id;


--
-- Name: cms_page_placeholders; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_page_placeholders (
    id integer NOT NULL,
    page_id integer NOT NULL,
    placeholder_id integer NOT NULL
);


ALTER TABLE public.cms_page_placeholders OWNER TO postgres;

--
-- Name: cms_page_placeholders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_page_placeholders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_page_placeholders_id_seq OWNER TO postgres;

--
-- Name: cms_page_placeholders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_page_placeholders_id_seq OWNED BY cms_page_placeholders.id;


--
-- Name: cms_pagepermission; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_pagepermission (
    id integer NOT NULL,
    can_change boolean NOT NULL,
    can_add boolean NOT NULL,
    can_delete boolean NOT NULL,
    can_change_advanced_settings boolean NOT NULL,
    can_publish boolean NOT NULL,
    can_change_permissions boolean NOT NULL,
    can_move_page boolean NOT NULL,
    can_view boolean NOT NULL,
    grant_on integer NOT NULL,
    group_id integer,
    page_id integer,
    user_id integer
);


ALTER TABLE public.cms_pagepermission OWNER TO postgres;

--
-- Name: cms_pagepermission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_pagepermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_pagepermission_id_seq OWNER TO postgres;

--
-- Name: cms_pagepermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_pagepermission_id_seq OWNED BY cms_pagepermission.id;


--
-- Name: cms_pageuser; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_pageuser (
    user_ptr_id integer NOT NULL,
    created_by_id integer NOT NULL
);


ALTER TABLE public.cms_pageuser OWNER TO postgres;

--
-- Name: cms_pageusergroup; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_pageusergroup (
    group_ptr_id integer NOT NULL,
    created_by_id integer NOT NULL
);


ALTER TABLE public.cms_pageusergroup OWNER TO postgres;

--
-- Name: cms_placeholder; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_placeholder (
    id integer NOT NULL,
    slot character varying(255) NOT NULL,
    default_width smallint,
    CONSTRAINT cms_placeholder_default_width_check CHECK ((default_width >= 0))
);


ALTER TABLE public.cms_placeholder OWNER TO postgres;

--
-- Name: cms_placeholder_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_placeholder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_placeholder_id_seq OWNER TO postgres;

--
-- Name: cms_placeholder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_placeholder_id_seq OWNED BY cms_placeholder.id;


--
-- Name: cms_placeholderreference; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_placeholderreference (
    cmsplugin_ptr_id integer NOT NULL,
    name character varying(255) NOT NULL,
    placeholder_ref_id integer
);


ALTER TABLE public.cms_placeholderreference OWNER TO postgres;

--
-- Name: cms_staticplaceholder; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_staticplaceholder (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    dirty boolean NOT NULL,
    creation_method character varying(20) NOT NULL,
    draft_id integer,
    public_id integer,
    site_id integer
);


ALTER TABLE public.cms_staticplaceholder OWNER TO postgres;

--
-- Name: cms_staticplaceholder_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_staticplaceholder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_staticplaceholder_id_seq OWNER TO postgres;

--
-- Name: cms_staticplaceholder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_staticplaceholder_id_seq OWNED BY cms_staticplaceholder.id;


--
-- Name: cms_title; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_title (
    id integer NOT NULL,
    language character varying(15) NOT NULL,
    title character varying(255) NOT NULL,
    page_title character varying(255),
    menu_title character varying(255),
    meta_description text,
    slug character varying(255) NOT NULL,
    path character varying(255) NOT NULL,
    has_url_overwrite boolean NOT NULL,
    redirect character varying(2048),
    creation_date timestamp with time zone NOT NULL,
    published boolean NOT NULL,
    publisher_is_draft boolean NOT NULL,
    publisher_state smallint NOT NULL,
    page_id integer NOT NULL,
    publisher_public_id integer
);


ALTER TABLE public.cms_title OWNER TO postgres;

--
-- Name: cms_title_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_title_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_title_id_seq OWNER TO postgres;

--
-- Name: cms_title_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_title_id_seq OWNED BY cms_title.id;


--
-- Name: cms_usersettings; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cms_usersettings (
    id integer NOT NULL,
    language character varying(10) NOT NULL,
    clipboard_id integer,
    user_id integer NOT NULL
);


ALTER TABLE public.cms_usersettings OWNER TO postgres;

--
-- Name: cms_usersettings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cms_usersettings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cms_usersettings_id_seq OWNER TO postgres;

--
-- Name: cms_usersettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cms_usersettings_id_seq OWNED BY cms_usersettings.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: djangocms_text_ckeditor_text; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE djangocms_text_ckeditor_text (
    cmsplugin_ptr_id integer NOT NULL,
    body text NOT NULL
);


ALTER TABLE public.djangocms_text_ckeditor_text OWNER TO postgres;

--
-- Name: easy_thumbnails_source; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE easy_thumbnails_source (
    id integer NOT NULL,
    storage_hash character varying(40) NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE public.easy_thumbnails_source OWNER TO postgres;

--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE easy_thumbnails_source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_source_id_seq OWNER TO postgres;

--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE easy_thumbnails_source_id_seq OWNED BY easy_thumbnails_source.id;


--
-- Name: easy_thumbnails_thumbnail; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE easy_thumbnails_thumbnail (
    id integer NOT NULL,
    storage_hash character varying(40) NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL,
    source_id integer NOT NULL
);


ALTER TABLE public.easy_thumbnails_thumbnail OWNER TO postgres;

--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE easy_thumbnails_thumbnail_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_thumbnail_id_seq OWNER TO postgres;

--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE easy_thumbnails_thumbnail_id_seq OWNED BY easy_thumbnails_thumbnail.id;


--
-- Name: easy_thumbnails_thumbnaildimensions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE easy_thumbnails_thumbnaildimensions (
    id integer NOT NULL,
    thumbnail_id integer NOT NULL,
    width integer,
    height integer,
    CONSTRAINT easy_thumbnails_thumbnaildimensions_height_check CHECK ((height >= 0)),
    CONSTRAINT easy_thumbnails_thumbnaildimensions_width_check CHECK ((width >= 0))
);


ALTER TABLE public.easy_thumbnails_thumbnaildimensions OWNER TO postgres;

--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE easy_thumbnails_thumbnaildimensions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_thumbnaildimensions_id_seq OWNER TO postgres;

--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE easy_thumbnails_thumbnaildimensions_id_seq OWNED BY easy_thumbnails_thumbnaildimensions.id;


--
-- Name: filer_clipboard; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE filer_clipboard (
    id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.filer_clipboard OWNER TO postgres;

--
-- Name: filer_clipboard_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE filer_clipboard_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.filer_clipboard_id_seq OWNER TO postgres;

--
-- Name: filer_clipboard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE filer_clipboard_id_seq OWNED BY filer_clipboard.id;


--
-- Name: filer_clipboarditem; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE filer_clipboarditem (
    id integer NOT NULL,
    clipboard_id integer NOT NULL,
    file_id integer NOT NULL
);


ALTER TABLE public.filer_clipboarditem OWNER TO postgres;

--
-- Name: filer_clipboarditem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE filer_clipboarditem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.filer_clipboarditem_id_seq OWNER TO postgres;

--
-- Name: filer_clipboarditem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE filer_clipboarditem_id_seq OWNED BY filer_clipboarditem.id;


--
-- Name: filer_file; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE filer_file (
    id integer NOT NULL,
    file character varying(255),
    _file_size integer,
    sha1 character varying(40) NOT NULL,
    has_all_mandatory_data boolean NOT NULL,
    original_filename character varying(255),
    name character varying(255) NOT NULL,
    description text,
    uploaded_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    is_public boolean NOT NULL,
    folder_id integer,
    owner_id integer,
    polymorphic_ctype_id integer
);


ALTER TABLE public.filer_file OWNER TO postgres;

--
-- Name: filer_file_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE filer_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.filer_file_id_seq OWNER TO postgres;

--
-- Name: filer_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE filer_file_id_seq OWNED BY filer_file.id;


--
-- Name: filer_folder; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE filer_folder (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    uploaded_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    owner_id integer,
    parent_id integer,
    CONSTRAINT filer_folder_level_check CHECK ((level >= 0)),
    CONSTRAINT filer_folder_lft_check CHECK ((lft >= 0)),
    CONSTRAINT filer_folder_rght_check CHECK ((rght >= 0)),
    CONSTRAINT filer_folder_tree_id_check CHECK ((tree_id >= 0))
);


ALTER TABLE public.filer_folder OWNER TO postgres;

--
-- Name: filer_folder_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE filer_folder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.filer_folder_id_seq OWNER TO postgres;

--
-- Name: filer_folder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE filer_folder_id_seq OWNED BY filer_folder.id;


--
-- Name: filer_folderpermission; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE filer_folderpermission (
    id integer NOT NULL,
    type smallint NOT NULL,
    everybody boolean NOT NULL,
    can_edit smallint,
    can_read smallint,
    can_add_children smallint,
    folder_id integer,
    group_id integer,
    user_id integer
);


ALTER TABLE public.filer_folderpermission OWNER TO postgres;

--
-- Name: filer_folderpermission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE filer_folderpermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.filer_folderpermission_id_seq OWNER TO postgres;

--
-- Name: filer_folderpermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE filer_folderpermission_id_seq OWNED BY filer_folderpermission.id;


--
-- Name: filer_image; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE filer_image (
    file_ptr_id integer NOT NULL,
    _height integer,
    _width integer,
    date_taken timestamp with time zone,
    default_alt_text character varying(255),
    default_caption character varying(255),
    author character varying(255),
    must_always_publish_author_credit boolean NOT NULL,
    must_always_publish_copyright boolean NOT NULL,
    subject_location character varying(64)
);


ALTER TABLE public.filer_image OWNER TO postgres;

--
-- Name: menus_cachekey; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE menus_cachekey (
    id integer NOT NULL,
    language character varying(255) NOT NULL,
    site integer NOT NULL,
    key character varying(255) NOT NULL,
    CONSTRAINT menus_cachekey_site_check CHECK ((site >= 0))
);


ALTER TABLE public.menus_cachekey OWNER TO postgres;

--
-- Name: menus_cachekey_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE menus_cachekey_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menus_cachekey_id_seq OWNER TO postgres;

--
-- Name: menus_cachekey_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE menus_cachekey_id_seq OWNED BY menus_cachekey.id;


--
-- Name: reversion_revision; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE reversion_revision (
    id integer NOT NULL,
    manager_slug character varying(191) NOT NULL,
    date_created timestamp with time zone NOT NULL,
    comment text NOT NULL,
    user_id integer
);


ALTER TABLE public.reversion_revision OWNER TO postgres;

--
-- Name: reversion_revision_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE reversion_revision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reversion_revision_id_seq OWNER TO postgres;

--
-- Name: reversion_revision_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE reversion_revision_id_seq OWNED BY reversion_revision.id;


--
-- Name: reversion_version; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE reversion_version (
    id integer NOT NULL,
    object_id text NOT NULL,
    object_id_int integer,
    format character varying(255) NOT NULL,
    serialized_data text NOT NULL,
    object_repr text NOT NULL,
    content_type_id integer NOT NULL,
    revision_id integer NOT NULL
);


ALTER TABLE public.reversion_version OWNER TO postgres;

--
-- Name: reversion_version_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE reversion_version_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reversion_version_id_seq OWNER TO postgres;

--
-- Name: reversion_version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE reversion_version_id_seq OWNED BY reversion_version.id;


--
-- Name: taggit_tag; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE taggit_tag (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL
);


ALTER TABLE public.taggit_tag OWNER TO postgres;

--
-- Name: taggit_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE taggit_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.taggit_tag_id_seq OWNER TO postgres;

--
-- Name: taggit_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE taggit_tag_id_seq OWNED BY taggit_tag.id;


--
-- Name: taggit_taggeditem; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE taggit_taggeditem (
    id integer NOT NULL,
    object_id integer NOT NULL,
    content_type_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.taggit_taggeditem OWNER TO postgres;

--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE taggit_taggeditem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.taggit_taggeditem_id_seq OWNER TO postgres;

--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE taggit_taggeditem_id_seq OWNED BY taggit_taggeditem.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_categories_category ALTER COLUMN id SET DEFAULT nextval('aldryn_categories_category_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_categories_category_translation ALTER COLUMN id SET DEFAULT nextval('aldryn_categories_category_translation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_article ALTER COLUMN id SET DEFAULT nextval('aldryn_newsblog_article_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_article_categories ALTER COLUMN id SET DEFAULT nextval('aldryn_newsblog_article_categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_article_related ALTER COLUMN id SET DEFAULT nextval('aldryn_newsblog_article_related_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_article_translation ALTER COLUMN id SET DEFAULT nextval('aldryn_newsblog_article_translation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogconfig ALTER COLUMN id SET DEFAULT nextval('aldryn_newsblog_newsblogconfig_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogconfig_translation ALTER COLUMN id SET DEFAULT nextval('aldryn_newsblog_newsblogconfig_translation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_people_group ALTER COLUMN id SET DEFAULT nextval('aldryn_people_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_people_group_translation ALTER COLUMN id SET DEFAULT nextval('aldryn_people_group_translation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_people_peopleplugin_people ALTER COLUMN id SET DEFAULT nextval('aldryn_people_peopleplugin_people_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_people_person ALTER COLUMN id SET DEFAULT nextval('aldryn_people_person_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_people_person_translation ALTER COLUMN id SET DEFAULT nextval('aldryn_people_person_translation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_cmsplugin ALTER COLUMN id SET DEFAULT nextval('cms_cmsplugin_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_globalpagepermission ALTER COLUMN id SET DEFAULT nextval('cms_globalpagepermission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_globalpagepermission_sites ALTER COLUMN id SET DEFAULT nextval('cms_globalpagepermission_sites_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_page ALTER COLUMN id SET DEFAULT nextval('cms_page_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_page_placeholders ALTER COLUMN id SET DEFAULT nextval('cms_page_placeholders_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pagepermission ALTER COLUMN id SET DEFAULT nextval('cms_pagepermission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_placeholder ALTER COLUMN id SET DEFAULT nextval('cms_placeholder_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_staticplaceholder ALTER COLUMN id SET DEFAULT nextval('cms_staticplaceholder_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_title ALTER COLUMN id SET DEFAULT nextval('cms_title_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_usersettings ALTER COLUMN id SET DEFAULT nextval('cms_usersettings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY easy_thumbnails_source ALTER COLUMN id SET DEFAULT nextval('easy_thumbnails_source_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY easy_thumbnails_thumbnail ALTER COLUMN id SET DEFAULT nextval('easy_thumbnails_thumbnail_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY easy_thumbnails_thumbnaildimensions ALTER COLUMN id SET DEFAULT nextval('easy_thumbnails_thumbnaildimensions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_clipboard ALTER COLUMN id SET DEFAULT nextval('filer_clipboard_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_clipboarditem ALTER COLUMN id SET DEFAULT nextval('filer_clipboarditem_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_file ALTER COLUMN id SET DEFAULT nextval('filer_file_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_folder ALTER COLUMN id SET DEFAULT nextval('filer_folder_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_folderpermission ALTER COLUMN id SET DEFAULT nextval('filer_folderpermission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY menus_cachekey ALTER COLUMN id SET DEFAULT nextval('menus_cachekey_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reversion_revision ALTER COLUMN id SET DEFAULT nextval('reversion_revision_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reversion_version ALTER COLUMN id SET DEFAULT nextval('reversion_version_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY taggit_tag ALTER COLUMN id SET DEFAULT nextval('taggit_tag_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY taggit_taggeditem ALTER COLUMN id SET DEFAULT nextval('taggit_taggeditem_id_seq'::regclass);


--
-- Data for Name: aldryn_bootstrap3_boostrap3alertplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3alertplugin (cmsplugin_ptr_id, context, icon, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3blockquoteplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3blockquoteplugin (cmsplugin_ptr_id, reverse, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3buttonplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3buttonplugin (link_url, link_anchor, link_mailto, link_phone, link_target, cmsplugin_ptr_id, label, type, btn_context, btn_size, btn_block, txt_context, icon_left, icon_right, classes, responsive, responsive_print, link_file_id, link_page_id) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3iconplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3iconplugin (cmsplugin_ptr_id, icon, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3imageplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3imageplugin (cmsplugin_ptr_id, alt, title, aspect_ratio, thumbnail, shape, classes, img_responsive, file_id) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3labelplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3labelplugin (cmsplugin_ptr_id, label, context, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3panelbodyplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3panelbodyplugin (cmsplugin_ptr_id, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3panelfooterplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3panelfooterplugin (cmsplugin_ptr_id, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3panelheadingplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3panelheadingplugin (cmsplugin_ptr_id, title, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3panelplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3panelplugin (cmsplugin_ptr_id, context, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3spacerplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3spacerplugin (cmsplugin_ptr_id, size, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_boostrap3wellplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_boostrap3wellplugin (cmsplugin_ptr_id, size, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3accordionitemplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3accordionitemplugin (cmsplugin_ptr_id, title, context, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3accordionplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3accordionplugin (cmsplugin_ptr_id, index, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3carouselplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3carouselplugin (cmsplugin_ptr_id, style, aspect_ratio, transition_effect, ride, "interval", wrap, pause, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3carouselslidefolderplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3carouselslidefolderplugin (cmsplugin_ptr_id, classes, folder_id) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3carouselslideplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3carouselslideplugin (cmsplugin_ptr_id, link_url, link_anchor, link_mailto, link_phone, link_target, link_text, content, classes, image_id, link_file_id, link_page_id) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3columnplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3columnplugin (cmsplugin_ptr_id, classes, tag, xs_col, xs_offset, xs_push, xs_pull, sm_col, sm_offset, sm_push, sm_pull, md_col, md_offset, md_push, md_pull, lg_col, lg_offset, lg_push, lg_pull) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3fileplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3fileplugin (cmsplugin_ptr_id, name, open_new_window, show_file_size, icon_left, icon_right, classes, file_id) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3listgroupitemplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3listgroupitemplugin (cmsplugin_ptr_id, title, context, state, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3listgroupplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3listgroupplugin (cmsplugin_ptr_id, classes, add_list_group_class) FROM stdin;
\.


--
-- Data for Name: aldryn_bootstrap3_bootstrap3rowplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_bootstrap3_bootstrap3rowplugin (cmsplugin_ptr_id, classes) FROM stdin;
\.


--
-- Data for Name: aldryn_categories_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_categories_category (id, lft, rgt, tree_id, depth) FROM stdin;
\.


--
-- Name: aldryn_categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_categories_category_id_seq', 1, false);


--
-- Data for Name: aldryn_categories_category_translation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_categories_category_translation (id, language_code, name, slug, master_id) FROM stdin;
\.


--
-- Name: aldryn_categories_category_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_categories_category_translation_id_seq', 1, false);


--
-- Data for Name: aldryn_newsblog_article; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_newsblog_article (id, publishing_date, is_published, is_featured, app_config_id, author_id, content_id, featured_image_id, owner_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_article_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_newsblog_article_categories (id, article_id, category_id) FROM stdin;
\.


--
-- Name: aldryn_newsblog_article_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_newsblog_article_categories_id_seq', 1, false);


--
-- Name: aldryn_newsblog_article_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_newsblog_article_id_seq', 1, false);


--
-- Data for Name: aldryn_newsblog_article_related; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_newsblog_article_related (id, from_article_id, to_article_id, sort_value) FROM stdin;
\.


--
-- Name: aldryn_newsblog_article_related_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_newsblog_article_related_id_seq', 1, false);


--
-- Data for Name: aldryn_newsblog_article_translation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_newsblog_article_translation (id, language_code, title, slug, lead_in, meta_title, meta_description, meta_keywords, search_data, master_id) FROM stdin;
\.


--
-- Name: aldryn_newsblog_article_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_newsblog_article_translation_id_seq', 1, false);


--
-- Data for Name: aldryn_newsblog_newsblogarchiveplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_newsblog_newsblogarchiveplugin (cmsplugin_ptr_id, app_config_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_newsblogarticlesearchplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_newsblog_newsblogarticlesearchplugin (cmsplugin_ptr_id, max_articles, app_config_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_newsblogauthorsplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_newsblog_newsblogauthorsplugin (cmsplugin_ptr_id, app_config_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_newsblogcategoriesplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_newsblog_newsblogcategoriesplugin (cmsplugin_ptr_id, app_config_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_newsblogconfig; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_newsblog_newsblogconfig (id, type, namespace, app_data, permalink_type, non_permalink_handling, paginate_by, create_authors, search_indexed, placeholder_base_sidebar_id, placeholder_base_top_id, placeholder_detail_bottom_id, placeholder_detail_footer_id, placeholder_detail_top_id, placeholder_list_footer_id, placeholder_list_top_id, template_prefix) FROM stdin;
\.


--
-- Name: aldryn_newsblog_newsblogconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_newsblog_newsblogconfig_id_seq', 1, false);


--
-- Data for Name: aldryn_newsblog_newsblogconfig_translation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_newsblog_newsblogconfig_translation (id, language_code, app_title, master_id) FROM stdin;
\.


--
-- Name: aldryn_newsblog_newsblogconfig_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_newsblog_newsblogconfig_translation_id_seq', 1, false);


--
-- Data for Name: aldryn_newsblog_newsblogfeaturedarticlesplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_newsblog_newsblogfeaturedarticlesplugin (cmsplugin_ptr_id, article_count, app_config_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_newsbloglatestarticlesplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_newsblog_newsbloglatestarticlesplugin (cmsplugin_ptr_id, latest_articles, app_config_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_newsblogrelatedplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_newsblog_newsblogrelatedplugin (cmsplugin_ptr_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_newsblogtagsplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_newsblog_newsblogtagsplugin (cmsplugin_ptr_id, app_config_id) FROM stdin;
\.


--
-- Data for Name: aldryn_people_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_people_group (id, address, postal_code, city, phone, fax, email, website) FROM stdin;
\.


--
-- Name: aldryn_people_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_people_group_id_seq', 1, false);


--
-- Data for Name: aldryn_people_group_translation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_people_group_translation (id, name, description, language_code, master_id) FROM stdin;
\.


--
-- Name: aldryn_people_group_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_people_group_translation_id_seq', 1, false);


--
-- Data for Name: aldryn_people_peopleplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_people_peopleplugin (cmsplugin_ptr_id, style, group_by_group, show_links, show_vcard) FROM stdin;
\.


--
-- Data for Name: aldryn_people_peopleplugin_people; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_people_peopleplugin_people (id, peopleplugin_id, person_id, sort_value) FROM stdin;
\.


--
-- Name: aldryn_people_peopleplugin_people_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_people_peopleplugin_people_id_seq', 1, false);


--
-- Data for Name: aldryn_people_person; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_people_person (id, name, phone, mobile, fax, email, website, slug, vcard_enabled, group_id, user_id, visual_id) FROM stdin;
\.


--
-- Name: aldryn_people_person_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_people_person_id_seq', 1, false);


--
-- Data for Name: aldryn_people_person_translation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_people_person_translation (id, function, description, language_code, master_id) FROM stdin;
\.


--
-- Name: aldryn_people_person_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('aldryn_people_person_translation_id_seq', 1, false);


--
-- Data for Name: aldryn_style_style; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aldryn_style_style (label, cmsplugin_ptr_id, class_name, id_name, tag_type, padding_left, padding_right, padding_top, padding_bottom, margin_left, margin_right, margin_top, margin_bottom, additional_class_names) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can add permission	2	add_permission
5	Can change permission	2	change_permission
6	Can delete permission	2	delete_permission
7	Can add group	3	add_group
8	Can change group	3	change_group
9	Can delete group	3	delete_group
10	Can add user	4	add_user
11	Can change user	4	change_user
12	Can delete user	4	delete_user
13	Can add content type	5	add_contenttype
14	Can change content type	5	change_contenttype
15	Can delete content type	5	delete_contenttype
16	Can add session	6	add_session
17	Can change session	6	change_session
18	Can delete session	6	delete_session
19	Can add site	7	add_site
20	Can change site	7	change_site
21	Can delete site	7	delete_site
22	Can add user setting	8	add_usersettings
23	Can change user setting	8	change_usersettings
24	Can delete user setting	8	delete_usersettings
25	Can add placeholder	9	add_placeholder
26	Can change placeholder	9	change_placeholder
27	Can delete placeholder	9	delete_placeholder
28	Can use Structure mode	9	use_structure
29	Can add cms plugin	10	add_cmsplugin
30	Can change cms plugin	10	change_cmsplugin
31	Can delete cms plugin	10	delete_cmsplugin
32	Can add page	11	add_page
33	Can change page	11	change_page
34	Can delete page	11	delete_page
35	Can view page	11	view_page
36	Can publish page	11	publish_page
37	Can edit static placeholders	11	edit_static_placeholder
38	Can add Page global permission	12	add_globalpagepermission
39	Can change Page global permission	12	change_globalpagepermission
40	Can delete Page global permission	12	delete_globalpagepermission
41	Can add Page permission	13	add_pagepermission
42	Can change Page permission	13	change_pagepermission
43	Can delete Page permission	13	delete_pagepermission
44	Can add User (page)	14	add_pageuser
45	Can change User (page)	14	change_pageuser
46	Can delete User (page)	14	delete_pageuser
47	Can add User group (page)	15	add_pageusergroup
48	Can change User group (page)	15	change_pageusergroup
49	Can delete User group (page)	15	delete_pageusergroup
50	Can add title	16	add_title
51	Can change title	16	change_title
52	Can delete title	16	delete_title
53	Can add placeholder reference	17	add_placeholderreference
54	Can change placeholder reference	17	change_placeholderreference
55	Can delete placeholder reference	17	delete_placeholderreference
56	Can add static placeholder	18	add_staticplaceholder
57	Can change static placeholder	18	change_staticplaceholder
58	Can delete static placeholder	18	delete_staticplaceholder
59	Can add alias plugin model	19	add_aliaspluginmodel
60	Can change alias plugin model	19	change_aliaspluginmodel
61	Can delete alias plugin model	19	delete_aliaspluginmodel
62	Can add cache key	20	add_cachekey
63	Can change cache key	20	change_cachekey
64	Can delete cache key	20	delete_cachekey
65	Can add revision	21	add_revision
66	Can change revision	21	change_revision
67	Can delete revision	21	delete_revision
68	Can add version	22	add_version
69	Can change version	22	change_version
70	Can delete version	22	delete_version
71	Can add text	23	add_text
72	Can change text	23	change_text
73	Can delete text	23	delete_text
74	Can add Folder	24	add_folder
75	Can change Folder	24	change_folder
76	Can delete Folder	24	delete_folder
77	Can use directory listing	24	can_use_directory_listing
78	Can add folder permission	25	add_folderpermission
79	Can change folder permission	25	change_folderpermission
80	Can delete folder permission	25	delete_folderpermission
81	Can add file	26	add_file
82	Can change file	26	change_file
83	Can delete file	26	delete_file
84	Can add clipboard	27	add_clipboard
85	Can change clipboard	27	change_clipboard
86	Can delete clipboard	27	delete_clipboard
87	Can add clipboard item	28	add_clipboarditem
88	Can change clipboard item	28	change_clipboarditem
89	Can delete clipboard item	28	delete_clipboarditem
90	Can add image	29	add_image
91	Can change image	29	change_image
92	Can delete image	29	delete_image
93	Can add source	30	add_source
94	Can change source	30	change_source
95	Can delete source	30	delete_source
96	Can add thumbnail	31	add_thumbnail
97	Can change thumbnail	31	change_thumbnail
98	Can delete thumbnail	31	delete_thumbnail
99	Can add thumbnail dimensions	32	add_thumbnaildimensions
100	Can change thumbnail dimensions	32	change_thumbnaildimensions
101	Can delete thumbnail dimensions	32	delete_thumbnaildimensions
102	Can add category	34	add_category
103	Can change category	34	change_category
104	Can delete category	34	delete_category
105	Can add Group	36	add_group
106	Can change Group	36	change_group
107	Can delete Group	36	delete_group
108	Can add Person	38	add_person
109	Can change Person	38	change_person
110	Can delete Person	38	delete_person
111	Can add people plugin	39	add_peopleplugin
112	Can change people plugin	39	change_peopleplugin
113	Can delete people plugin	39	delete_peopleplugin
114	Can add Tag	40	add_tag
115	Can change Tag	40	change_tag
116	Can delete Tag	40	delete_tag
117	Can add Tagged Item	41	add_taggeditem
118	Can change Tagged Item	41	change_taggeditem
119	Can delete Tagged Item	41	delete_taggeditem
120	Can add boostrap3 button plugin	42	add_boostrap3buttonplugin
121	Can change boostrap3 button plugin	42	change_boostrap3buttonplugin
122	Can delete boostrap3 button plugin	42	delete_boostrap3buttonplugin
123	Can add boostrap3 blockquote plugin	43	add_boostrap3blockquoteplugin
124	Can change boostrap3 blockquote plugin	43	change_boostrap3blockquoteplugin
125	Can delete boostrap3 blockquote plugin	43	delete_boostrap3blockquoteplugin
126	Can add boostrap3 icon plugin	44	add_boostrap3iconplugin
127	Can change boostrap3 icon plugin	44	change_boostrap3iconplugin
128	Can delete boostrap3 icon plugin	44	delete_boostrap3iconplugin
129	Can add boostrap3 label plugin	45	add_boostrap3labelplugin
130	Can change boostrap3 label plugin	45	change_boostrap3labelplugin
131	Can delete boostrap3 label plugin	45	delete_boostrap3labelplugin
132	Can add boostrap3 well plugin	46	add_boostrap3wellplugin
133	Can change boostrap3 well plugin	46	change_boostrap3wellplugin
134	Can delete boostrap3 well plugin	46	delete_boostrap3wellplugin
135	Can add boostrap3 alert plugin	47	add_boostrap3alertplugin
136	Can change boostrap3 alert plugin	47	change_boostrap3alertplugin
137	Can delete boostrap3 alert plugin	47	delete_boostrap3alertplugin
138	Can add boostrap3 image plugin	48	add_boostrap3imageplugin
139	Can change boostrap3 image plugin	48	change_boostrap3imageplugin
140	Can delete boostrap3 image plugin	48	delete_boostrap3imageplugin
141	Can add boostrap3 spacer plugin	49	add_boostrap3spacerplugin
142	Can change boostrap3 spacer plugin	49	change_boostrap3spacerplugin
143	Can delete boostrap3 spacer plugin	49	delete_boostrap3spacerplugin
144	Can add bootstrap3 file plugin	50	add_bootstrap3fileplugin
145	Can change bootstrap3 file plugin	50	change_bootstrap3fileplugin
146	Can delete bootstrap3 file plugin	50	delete_bootstrap3fileplugin
147	Can add boostrap3 panel plugin	51	add_boostrap3panelplugin
148	Can change boostrap3 panel plugin	51	change_boostrap3panelplugin
149	Can delete boostrap3 panel plugin	51	delete_boostrap3panelplugin
150	Can add boostrap3 panel heading plugin	52	add_boostrap3panelheadingplugin
151	Can change boostrap3 panel heading plugin	52	change_boostrap3panelheadingplugin
152	Can delete boostrap3 panel heading plugin	52	delete_boostrap3panelheadingplugin
153	Can add boostrap3 panel body plugin	53	add_boostrap3panelbodyplugin
154	Can change boostrap3 panel body plugin	53	change_boostrap3panelbodyplugin
155	Can delete boostrap3 panel body plugin	53	delete_boostrap3panelbodyplugin
156	Can add boostrap3 panel footer plugin	54	add_boostrap3panelfooterplugin
157	Can change boostrap3 panel footer plugin	54	change_boostrap3panelfooterplugin
158	Can delete boostrap3 panel footer plugin	54	delete_boostrap3panelfooterplugin
159	Can add bootstrap3 row plugin	55	add_bootstrap3rowplugin
160	Can change bootstrap3 row plugin	55	change_bootstrap3rowplugin
161	Can delete bootstrap3 row plugin	55	delete_bootstrap3rowplugin
162	Can add bootstrap3 column plugin	56	add_bootstrap3columnplugin
163	Can change bootstrap3 column plugin	56	change_bootstrap3columnplugin
164	Can delete bootstrap3 column plugin	56	delete_bootstrap3columnplugin
165	Can add bootstrap3 accordion plugin	57	add_bootstrap3accordionplugin
166	Can change bootstrap3 accordion plugin	57	change_bootstrap3accordionplugin
167	Can delete bootstrap3 accordion plugin	57	delete_bootstrap3accordionplugin
168	Can add bootstrap3 accordion item plugin	58	add_bootstrap3accordionitemplugin
169	Can change bootstrap3 accordion item plugin	58	change_bootstrap3accordionitemplugin
170	Can delete bootstrap3 accordion item plugin	58	delete_bootstrap3accordionitemplugin
171	Can add bootstrap3 list group plugin	59	add_bootstrap3listgroupplugin
172	Can change bootstrap3 list group plugin	59	change_bootstrap3listgroupplugin
173	Can delete bootstrap3 list group plugin	59	delete_bootstrap3listgroupplugin
174	Can add bootstrap3 list group item plugin	60	add_bootstrap3listgroupitemplugin
175	Can change bootstrap3 list group item plugin	60	change_bootstrap3listgroupitemplugin
176	Can delete bootstrap3 list group item plugin	60	delete_bootstrap3listgroupitemplugin
177	Can add bootstrap3 carousel plugin	61	add_bootstrap3carouselplugin
178	Can change bootstrap3 carousel plugin	61	change_bootstrap3carouselplugin
179	Can delete bootstrap3 carousel plugin	61	delete_bootstrap3carouselplugin
180	Can add bootstrap3 carousel slide plugin	62	add_bootstrap3carouselslideplugin
181	Can change bootstrap3 carousel slide plugin	62	change_bootstrap3carouselslideplugin
182	Can delete bootstrap3 carousel slide plugin	62	delete_bootstrap3carouselslideplugin
183	Can add bootstrap3 carousel slide folder plugin	63	add_bootstrap3carouselslidefolderplugin
184	Can change bootstrap3 carousel slide folder plugin	63	change_bootstrap3carouselslidefolderplugin
185	Can delete bootstrap3 carousel slide folder plugin	63	delete_bootstrap3carouselslidefolderplugin
186	Can add news blog config	65	add_newsblogconfig
187	Can change news blog config	65	change_newsblogconfig
188	Can delete news blog config	65	delete_newsblogconfig
189	Can add article	67	add_article
190	Can change article	67	change_article
191	Can delete article	67	delete_article
192	Can add news blog archive plugin	68	add_newsblogarchiveplugin
193	Can change news blog archive plugin	68	change_newsblogarchiveplugin
194	Can delete news blog archive plugin	68	delete_newsblogarchiveplugin
195	Can add news blog article search plugin	69	add_newsblogarticlesearchplugin
196	Can change news blog article search plugin	69	change_newsblogarticlesearchplugin
197	Can delete news blog article search plugin	69	delete_newsblogarticlesearchplugin
198	Can add news blog authors plugin	70	add_newsblogauthorsplugin
199	Can change news blog authors plugin	70	change_newsblogauthorsplugin
200	Can delete news blog authors plugin	70	delete_newsblogauthorsplugin
201	Can add news blog categories plugin	71	add_newsblogcategoriesplugin
202	Can change news blog categories plugin	71	change_newsblogcategoriesplugin
203	Can delete news blog categories plugin	71	delete_newsblogcategoriesplugin
204	Can add news blog featured articles plugin	72	add_newsblogfeaturedarticlesplugin
205	Can change news blog featured articles plugin	72	change_newsblogfeaturedarticlesplugin
206	Can delete news blog featured articles plugin	72	delete_newsblogfeaturedarticlesplugin
207	Can add news blog latest articles plugin	73	add_newsbloglatestarticlesplugin
208	Can change news blog latest articles plugin	73	change_newsbloglatestarticlesplugin
209	Can delete news blog latest articles plugin	73	delete_newsbloglatestarticlesplugin
210	Can add news blog related plugin	74	add_newsblogrelatedplugin
211	Can change news blog related plugin	74	change_newsblogrelatedplugin
212	Can delete news blog related plugin	74	delete_newsblogrelatedplugin
213	Can add news blog tags plugin	75	add_newsblogtagsplugin
214	Can change news blog tags plugin	75	change_newsblogtagsplugin
215	Can delete news blog tags plugin	75	delete_newsblogtagsplugin
216	Can add style	76	add_style
217	Can change style	76	change_style
218	Can delete style	76	delete_style
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_permission_id_seq', 218, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$15000$XNaoyQnenlZv$n7EOo6r0kaH+29dcY++IcXPJc3SUdPAdfm/OcdKS9Gk=	2015-06-18 16:36:31.540139+02	t	admin				t	t	2015-06-18 16:36:31.540139+02
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_id_seq', 1, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: cms_aliaspluginmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_aliaspluginmodel (cmsplugin_ptr_id, plugin_id, alias_placeholder_id) FROM stdin;
\.


--
-- Data for Name: cms_cmsplugin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_cmsplugin (id, "position", language, plugin_type, creation_date, changed_date, parent_id, placeholder_id, depth, numchild, path) FROM stdin;
\.


--
-- Name: cms_cmsplugin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_cmsplugin_id_seq', 1, false);


--
-- Data for Name: cms_globalpagepermission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_globalpagepermission (id, can_change, can_add, can_delete, can_change_advanced_settings, can_publish, can_change_permissions, can_move_page, can_view, can_recover_page, group_id, user_id) FROM stdin;
\.


--
-- Name: cms_globalpagepermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_globalpagepermission_id_seq', 1, false);


--
-- Data for Name: cms_globalpagepermission_sites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_globalpagepermission_sites (id, globalpagepermission_id, site_id) FROM stdin;
\.


--
-- Name: cms_globalpagepermission_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_globalpagepermission_sites_id_seq', 1, false);


--
-- Data for Name: cms_page; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_page (id, created_by, changed_by, creation_date, changed_date, publication_date, publication_end_date, in_navigation, soft_root, reverse_id, navigation_extenders, template, login_required, limit_visibility_in_menu, is_home, application_urls, application_namespace, publisher_is_draft, languages, revision_id, xframe_options, parent_id, publisher_public_id, site_id, depth, numchild, path) FROM stdin;
\.


--
-- Name: cms_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_page_id_seq', 1, false);


--
-- Data for Name: cms_page_placeholders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_page_placeholders (id, page_id, placeholder_id) FROM stdin;
\.


--
-- Name: cms_page_placeholders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_page_placeholders_id_seq', 1, false);


--
-- Data for Name: cms_pagepermission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_pagepermission (id, can_change, can_add, can_delete, can_change_advanced_settings, can_publish, can_change_permissions, can_move_page, can_view, grant_on, group_id, page_id, user_id) FROM stdin;
\.


--
-- Name: cms_pagepermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_pagepermission_id_seq', 1, false);


--
-- Data for Name: cms_pageuser; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_pageuser (user_ptr_id, created_by_id) FROM stdin;
\.


--
-- Data for Name: cms_pageusergroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_pageusergroup (group_ptr_id, created_by_id) FROM stdin;
\.


--
-- Data for Name: cms_placeholder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_placeholder (id, slot, default_width) FROM stdin;
\.


--
-- Name: cms_placeholder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_placeholder_id_seq', 1, false);


--
-- Data for Name: cms_placeholderreference; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_placeholderreference (cmsplugin_ptr_id, name, placeholder_ref_id) FROM stdin;
\.


--
-- Data for Name: cms_staticplaceholder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_staticplaceholder (id, name, code, dirty, creation_method, draft_id, public_id, site_id) FROM stdin;
\.


--
-- Name: cms_staticplaceholder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_staticplaceholder_id_seq', 1, false);


--
-- Data for Name: cms_title; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_title (id, language, title, page_title, menu_title, meta_description, slug, path, has_url_overwrite, redirect, creation_date, published, publisher_is_draft, publisher_state, page_id, publisher_public_id) FROM stdin;
\.


--
-- Name: cms_title_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_title_id_seq', 1, false);


--
-- Data for Name: cms_usersettings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cms_usersettings (id, language, clipboard_id, user_id) FROM stdin;
\.


--
-- Name: cms_usersettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cms_usersettings_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 1, false);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
1	log entry	admin	logentry
2	permission	auth	permission
3	group	auth	group
4	user	auth	user
5	content type	contenttypes	contenttype
6	session	sessions	session
7	site	sites	site
8	user setting	cms	usersettings
9	placeholder	cms	placeholder
10	cms plugin	cms	cmsplugin
11	page	cms	page
12	Page global permission	cms	globalpagepermission
13	Page permission	cms	pagepermission
14	User (page)	cms	pageuser
15	User group (page)	cms	pageusergroup
16	title	cms	title
17	placeholder reference	cms	placeholderreference
18	static placeholder	cms	staticplaceholder
19	alias plugin model	cms	aliaspluginmodel
20	cache key	menus	cachekey
21	revision	reversion	revision
22	version	reversion	version
23	text	djangocms_text_ckeditor	text
24	Folder	filer	folder
25	folder permission	filer	folderpermission
26	file	filer	file
27	clipboard	filer	clipboard
28	clipboard item	filer	clipboarditem
29	image	filer	image
30	source	easy_thumbnails	source
31	thumbnail	easy_thumbnails	thumbnail
32	thumbnail dimensions	easy_thumbnails	thumbnaildimensions
33	category Translation	aldryn_categories	categorytranslation
34	category	aldryn_categories	category
35	Group Translation	aldryn_people	grouptranslation
36	Group	aldryn_people	group
37	Person Translation	aldryn_people	persontranslation
38	Person	aldryn_people	person
39	people plugin	aldryn_people	peopleplugin
40	Tag	taggit	tag
41	Tagged Item	taggit	taggeditem
42	boostrap3 button plugin	aldryn_bootstrap3	boostrap3buttonplugin
43	boostrap3 blockquote plugin	aldryn_bootstrap3	boostrap3blockquoteplugin
44	boostrap3 icon plugin	aldryn_bootstrap3	boostrap3iconplugin
45	boostrap3 label plugin	aldryn_bootstrap3	boostrap3labelplugin
46	boostrap3 well plugin	aldryn_bootstrap3	boostrap3wellplugin
47	boostrap3 alert plugin	aldryn_bootstrap3	boostrap3alertplugin
48	boostrap3 image plugin	aldryn_bootstrap3	boostrap3imageplugin
49	boostrap3 spacer plugin	aldryn_bootstrap3	boostrap3spacerplugin
50	bootstrap3 file plugin	aldryn_bootstrap3	bootstrap3fileplugin
51	boostrap3 panel plugin	aldryn_bootstrap3	boostrap3panelplugin
52	boostrap3 panel heading plugin	aldryn_bootstrap3	boostrap3panelheadingplugin
53	boostrap3 panel body plugin	aldryn_bootstrap3	boostrap3panelbodyplugin
54	boostrap3 panel footer plugin	aldryn_bootstrap3	boostrap3panelfooterplugin
55	bootstrap3 row plugin	aldryn_bootstrap3	bootstrap3rowplugin
56	bootstrap3 column plugin	aldryn_bootstrap3	bootstrap3columnplugin
57	bootstrap3 accordion plugin	aldryn_bootstrap3	bootstrap3accordionplugin
58	bootstrap3 accordion item plugin	aldryn_bootstrap3	bootstrap3accordionitemplugin
59	bootstrap3 list group plugin	aldryn_bootstrap3	bootstrap3listgroupplugin
60	bootstrap3 list group item plugin	aldryn_bootstrap3	bootstrap3listgroupitemplugin
61	bootstrap3 carousel plugin	aldryn_bootstrap3	bootstrap3carouselplugin
62	bootstrap3 carousel slide plugin	aldryn_bootstrap3	bootstrap3carouselslideplugin
63	bootstrap3 carousel slide folder plugin	aldryn_bootstrap3	bootstrap3carouselslidefolderplugin
64	news blog config Translation	aldryn_newsblog	newsblogconfigtranslation
65	news blog config	aldryn_newsblog	newsblogconfig
66	article Translation	aldryn_newsblog	articletranslation
67	article	aldryn_newsblog	article
68	news blog archive plugin	aldryn_newsblog	newsblogarchiveplugin
69	news blog article search plugin	aldryn_newsblog	newsblogarticlesearchplugin
70	news blog authors plugin	aldryn_newsblog	newsblogauthorsplugin
71	news blog categories plugin	aldryn_newsblog	newsblogcategoriesplugin
72	news blog featured articles plugin	aldryn_newsblog	newsblogfeaturedarticlesplugin
73	news blog latest articles plugin	aldryn_newsblog	newsbloglatestarticlesplugin
74	news blog related plugin	aldryn_newsblog	newsblogrelatedplugin
75	news blog tags plugin	aldryn_newsblog	newsblogtagsplugin
76	style	aldryn_style	style
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_content_type_id_seq', 76, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2015-06-18 16:35:16.99441+02
2	auth	0001_initial	2015-06-18 16:35:17.068882+02
3	admin	0001_initial	2015-06-18 16:35:17.122332+02
4	filer	0001_initial	2015-06-18 16:35:17.527327+02
5	filer	0002_auto_20150606_2003	2015-06-18 16:35:17.69545+02
6	sites	0001_initial	2015-06-18 16:35:17.709142+02
7	cms	0001_initial	2015-06-18 16:35:18.124006+02
8	cms	0002_auto_20140816_1918	2015-06-18 16:35:18.933054+02
9	cms	0003_auto_20140926_2347	2015-06-18 16:35:19.111016+02
10	cms	0004_auto_20140924_1038	2015-06-18 16:35:19.96821+02
11	cms	0005_auto_20140924_1039	2015-06-18 16:35:20.315262+02
12	cms	0006_auto_20140924_1110	2015-06-18 16:35:21.213041+02
13	cms	0007_auto_20141028_1559	2015-06-18 16:35:21.701217+02
14	cms	0008_auto_20150208_2149	2015-06-18 16:35:22.148787+02
15	cms	0008_auto_20150121_0059	2015-06-18 16:35:22.522327+02
16	cms	0009_merge	2015-06-18 16:35:22.788716+02
17	cms	0010_migrate_use_structure	2015-06-18 16:35:23.325309+02
18	cms	0011_auto_20150419_1006	2015-06-18 16:35:23.926531+02
19	aldryn_bootstrap3	0001_initial	2015-06-18 16:35:26.727069+02
20	aldryn_bootstrap3	0002_bootstrap3fileplugin	2015-06-18 16:35:27.527575+02
21	aldryn_categories	0001_initial	2015-06-18 16:35:27.561286+02
22	aldryn_categories	0002_auto_20150109_1415	2015-06-18 16:35:27.576288+02
23	aldryn_categories	0003_auto_20150128_1359	2015-06-18 16:35:27.596096+02
24	taggit	0001_initial	2015-06-18 16:35:27.62184+02
25	aldryn_people	0001_initial	2015-06-18 16:35:28.446303+02
26	aldryn_newsblog	0001_initial	2015-06-18 16:35:31.750241+02
27	aldryn_newsblog	0002_newsblogconfig_template_prefix	2015-06-18 16:35:32.272176+02
28	aldryn_newsblog	0003_auto_20150422_1921	2015-06-18 16:35:32.949892+02
29	aldryn_people	0002_auto_20150128_1411	2015-06-18 16:35:33.393348+02
30	aldryn_people	0003_auto_20150425_2103	2015-06-18 16:35:33.906601+02
31	aldryn_style	0001_initial	2015-06-18 16:35:34.297007+02
32	djangocms_text_ckeditor	0001_initial	2015-06-18 16:35:34.368801+02
33	easy_thumbnails	0001_initial	2015-06-18 16:35:34.400595+02
34	easy_thumbnails	0002_thumbnaildimensions	2015-06-18 16:35:34.418821+02
35	menus	0001_initial	2015-06-18 16:35:34.429522+02
36	reversion	0001_initial	2015-06-18 16:35:34.594785+02
37	reversion	0002_auto_20141216_1509	2015-06-18 16:35:34.64731+02
38	sessions	0001_initial	2015-06-18 16:35:34.659907+02
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_migrations_id_seq', 38, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_site (id, domain, name) FROM stdin;
1	example.com	example.com
\.


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_site_id_seq', 1, true);


--
-- Data for Name: djangocms_text_ckeditor_text; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY djangocms_text_ckeditor_text (cmsplugin_ptr_id, body) FROM stdin;
\.


--
-- Data for Name: easy_thumbnails_source; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY easy_thumbnails_source (id, storage_hash, name, modified) FROM stdin;
\.


--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('easy_thumbnails_source_id_seq', 1, false);


--
-- Data for Name: easy_thumbnails_thumbnail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY easy_thumbnails_thumbnail (id, storage_hash, name, modified, source_id) FROM stdin;
\.


--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('easy_thumbnails_thumbnail_id_seq', 1, false);


--
-- Data for Name: easy_thumbnails_thumbnaildimensions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY easy_thumbnails_thumbnaildimensions (id, thumbnail_id, width, height) FROM stdin;
\.


--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('easy_thumbnails_thumbnaildimensions_id_seq', 1, false);


--
-- Data for Name: filer_clipboard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY filer_clipboard (id, user_id) FROM stdin;
\.


--
-- Name: filer_clipboard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('filer_clipboard_id_seq', 1, false);


--
-- Data for Name: filer_clipboarditem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY filer_clipboarditem (id, clipboard_id, file_id) FROM stdin;
\.


--
-- Name: filer_clipboarditem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('filer_clipboarditem_id_seq', 1, false);


--
-- Data for Name: filer_file; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY filer_file (id, file, _file_size, sha1, has_all_mandatory_data, original_filename, name, description, uploaded_at, modified_at, is_public, folder_id, owner_id, polymorphic_ctype_id) FROM stdin;
\.


--
-- Name: filer_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('filer_file_id_seq', 1, false);


--
-- Data for Name: filer_folder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY filer_folder (id, name, uploaded_at, created_at, modified_at, lft, rght, tree_id, level, owner_id, parent_id) FROM stdin;
\.


--
-- Name: filer_folder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('filer_folder_id_seq', 1, false);


--
-- Data for Name: filer_folderpermission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY filer_folderpermission (id, type, everybody, can_edit, can_read, can_add_children, folder_id, group_id, user_id) FROM stdin;
\.


--
-- Name: filer_folderpermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('filer_folderpermission_id_seq', 1, false);


--
-- Data for Name: filer_image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY filer_image (file_ptr_id, _height, _width, date_taken, default_alt_text, default_caption, author, must_always_publish_author_credit, must_always_publish_copyright, subject_location) FROM stdin;
\.


--
-- Data for Name: menus_cachekey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY menus_cachekey (id, language, site, key) FROM stdin;
\.


--
-- Name: menus_cachekey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('menus_cachekey_id_seq', 1, false);


--
-- Data for Name: reversion_revision; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY reversion_revision (id, manager_slug, date_created, comment, user_id) FROM stdin;
\.


--
-- Name: reversion_revision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('reversion_revision_id_seq', 1, false);


--
-- Data for Name: reversion_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY reversion_version (id, object_id, object_id_int, format, serialized_data, object_repr, content_type_id, revision_id) FROM stdin;
\.


--
-- Name: reversion_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('reversion_version_id_seq', 1, false);


--
-- Data for Name: taggit_tag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY taggit_tag (id, name, slug) FROM stdin;
\.


--
-- Name: taggit_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('taggit_tag_id_seq', 1, false);


--
-- Data for Name: taggit_taggeditem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY taggit_taggeditem (id, object_id, content_type_id, tag_id) FROM stdin;
\.


--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('taggit_taggeditem_id_seq', 1, false);


--
-- Name: aldryn_bootstrap3_boostrap3alertplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3alertplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3alertplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3blockquoteplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3blockquoteplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3blockquoteplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3buttonplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3buttonplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3buttonplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3iconplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3iconplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3iconplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3imageplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3imageplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3imageplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3labelplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3labelplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3labelplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3panelbodyplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelbodyplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3panelbodyplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3panelfooterplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelfooterplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3panelfooterplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3panelheadingplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelheadingplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3panelheadingplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3panelplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3panelplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3spacerplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3spacerplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3spacerplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_boostrap3wellplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3wellplugin
    ADD CONSTRAINT aldryn_bootstrap3_boostrap3wellplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3accordionitemplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3accordionitemplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3accordionitemplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3accordionplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3accordionplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3accordionplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3carouselplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3carouselplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3carouselslidefolderplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslidefolderplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3carouselslidefolderplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3carouselslideplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslideplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3carouselslideplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3columnplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3columnplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3columnplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3fileplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3fileplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3fileplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3listgroupitemplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3listgroupitemplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3listgroupitemplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3listgroupplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3listgroupplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3listgroupplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_bootstrap3_bootstrap3rowplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3rowplugin
    ADD CONSTRAINT aldryn_bootstrap3_bootstrap3rowplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_categories_category__language_code_465c17f45a1604da_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_categories_category_translation
    ADD CONSTRAINT aldryn_categories_category__language_code_465c17f45a1604da_uniq UNIQUE (language_code, master_id);


--
-- Name: aldryn_categories_category__language_code_54049a87a2ca44c0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_categories_category_translation
    ADD CONSTRAINT aldryn_categories_category__language_code_54049a87a2ca44c0_uniq UNIQUE (language_code, slug);


--
-- Name: aldryn_categories_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_categories_category
    ADD CONSTRAINT aldryn_categories_category_pkey PRIMARY KEY (id);


--
-- Name: aldryn_categories_category_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_categories_category_translation
    ADD CONSTRAINT aldryn_categories_category_translation_pkey PRIMARY KEY (id);


--
-- Name: aldryn_newsblog_article_categories_article_id_category_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_article_categories
    ADD CONSTRAINT aldryn_newsblog_article_categories_article_id_category_id_key UNIQUE (article_id, category_id);


--
-- Name: aldryn_newsblog_article_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_article_categories
    ADD CONSTRAINT aldryn_newsblog_article_categories_pkey PRIMARY KEY (id);


--
-- Name: aldryn_newsblog_article_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_article
    ADD CONSTRAINT aldryn_newsblog_article_pkey PRIMARY KEY (id);


--
-- Name: aldryn_newsblog_article_relat_from_article_id_to_article_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_article_related
    ADD CONSTRAINT aldryn_newsblog_article_relat_from_article_id_to_article_id_key UNIQUE (from_article_id, to_article_id);


--
-- Name: aldryn_newsblog_article_related_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_article_related
    ADD CONSTRAINT aldryn_newsblog_article_related_pkey PRIMARY KEY (id);


--
-- Name: aldryn_newsblog_article_tra_language_code_2960efa31cdd5250_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_article_translation
    ADD CONSTRAINT aldryn_newsblog_article_tra_language_code_2960efa31cdd5250_uniq UNIQUE (language_code, master_id);


--
-- Name: aldryn_newsblog_article_tra_language_code_5cac8eb2196f7e76_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_article_translation
    ADD CONSTRAINT aldryn_newsblog_article_tra_language_code_5cac8eb2196f7e76_uniq UNIQUE (language_code, slug);


--
-- Name: aldryn_newsblog_article_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_article_translation
    ADD CONSTRAINT aldryn_newsblog_article_translation_pkey PRIMARY KEY (id);


--
-- Name: aldryn_newsblog_newsblogarchiveplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_newsblogarchiveplugin
    ADD CONSTRAINT aldryn_newsblog_newsblogarchiveplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_newsblog_newsblogarticlesearchplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_newsblogarticlesearchplugin
    ADD CONSTRAINT aldryn_newsblog_newsblogarticlesearchplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_newsblog_newsblogauthorsplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_newsblogauthorsplugin
    ADD CONSTRAINT aldryn_newsblog_newsblogauthorsplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_newsblog_newsblogcategoriesplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_newsblogcategoriesplugin
    ADD CONSTRAINT aldryn_newsblog_newsblogcategoriesplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_newsblog_newsblogcon_language_code_18e012335cb67d1e_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_newsblogconfig_translation
    ADD CONSTRAINT aldryn_newsblog_newsblogcon_language_code_18e012335cb67d1e_uniq UNIQUE (language_code, master_id);


--
-- Name: aldryn_newsblog_newsblogconfig_namespace_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT aldryn_newsblog_newsblogconfig_namespace_key UNIQUE (namespace);


--
-- Name: aldryn_newsblog_newsblogconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT aldryn_newsblog_newsblogconfig_pkey PRIMARY KEY (id);


--
-- Name: aldryn_newsblog_newsblogconfig_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_newsblogconfig_translation
    ADD CONSTRAINT aldryn_newsblog_newsblogconfig_translation_pkey PRIMARY KEY (id);


--
-- Name: aldryn_newsblog_newsblogfeaturedarticlesplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_newsblogfeaturedarticlesplugin
    ADD CONSTRAINT aldryn_newsblog_newsblogfeaturedarticlesplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_newsblog_newsbloglatestarticlesplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_newsbloglatestarticlesplugin
    ADD CONSTRAINT aldryn_newsblog_newsbloglatestarticlesplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_newsblog_newsblogrelatedplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_newsblogrelatedplugin
    ADD CONSTRAINT aldryn_newsblog_newsblogrelatedplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_newsblog_newsblogtagsplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_newsblog_newsblogtagsplugin
    ADD CONSTRAINT aldryn_newsblog_newsblogtagsplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_people_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_people_group
    ADD CONSTRAINT aldryn_people_group_pkey PRIMARY KEY (id);


--
-- Name: aldryn_people_group_transla_language_code_4102cf7495e150a7_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_people_group_translation
    ADD CONSTRAINT aldryn_people_group_transla_language_code_4102cf7495e150a7_uniq UNIQUE (language_code, master_id);


--
-- Name: aldryn_people_group_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_people_group_translation
    ADD CONSTRAINT aldryn_people_group_translation_pkey PRIMARY KEY (id);


--
-- Name: aldryn_people_peopleplugin_people_peopleplugin_id_person_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_people_peopleplugin_people
    ADD CONSTRAINT aldryn_people_peopleplugin_people_peopleplugin_id_person_id_key UNIQUE (peopleplugin_id, person_id);


--
-- Name: aldryn_people_peopleplugin_people_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_people_peopleplugin_people
    ADD CONSTRAINT aldryn_people_peopleplugin_people_pkey PRIMARY KEY (id);


--
-- Name: aldryn_people_peopleplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_people_peopleplugin
    ADD CONSTRAINT aldryn_people_peopleplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_people_person_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_people_person
    ADD CONSTRAINT aldryn_people_person_pkey PRIMARY KEY (id);


--
-- Name: aldryn_people_person_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_people_person
    ADD CONSTRAINT aldryn_people_person_slug_key UNIQUE (slug);


--
-- Name: aldryn_people_person_transl_language_code_262df9c1550a4c40_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_people_person_translation
    ADD CONSTRAINT aldryn_people_person_transl_language_code_262df9c1550a4c40_uniq UNIQUE (language_code, master_id);


--
-- Name: aldryn_people_person_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_people_person_translation
    ADD CONSTRAINT aldryn_people_person_translation_pkey PRIMARY KEY (id);


--
-- Name: aldryn_people_person_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_people_person
    ADD CONSTRAINT aldryn_people_person_user_id_key UNIQUE (user_id);


--
-- Name: aldryn_style_style_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY aldryn_style_style
    ADD CONSTRAINT aldryn_style_style_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: cms_aliaspluginmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_aliaspluginmodel
    ADD CONSTRAINT cms_aliaspluginmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cms_cmsplugin_path_7692c19a7d5df9d5_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_cmsplugin
    ADD CONSTRAINT cms_cmsplugin_path_7692c19a7d5df9d5_uniq UNIQUE (path);


--
-- Name: cms_cmsplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_cmsplugin
    ADD CONSTRAINT cms_cmsplugin_pkey PRIMARY KEY (id);


--
-- Name: cms_globalpagepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_globalpagepermission
    ADD CONSTRAINT cms_globalpagepermission_pkey PRIMARY KEY (id);


--
-- Name: cms_globalpagepermission_site_globalpagepermission_id_site__key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_globalpagepermission_sites
    ADD CONSTRAINT cms_globalpagepermission_site_globalpagepermission_id_site__key UNIQUE (globalpagepermission_id, site_id);


--
-- Name: cms_globalpagepermission_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_globalpagepermission_sites
    ADD CONSTRAINT cms_globalpagepermission_sites_pkey PRIMARY KEY (id);


--
-- Name: cms_page_path_518270318703c18f_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT cms_page_path_518270318703c18f_uniq UNIQUE (path);


--
-- Name: cms_page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT cms_page_pkey PRIMARY KEY (id);


--
-- Name: cms_page_placeholders_page_id_placeholder_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_page_placeholders
    ADD CONSTRAINT cms_page_placeholders_page_id_placeholder_id_key UNIQUE (page_id, placeholder_id);


--
-- Name: cms_page_placeholders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_page_placeholders
    ADD CONSTRAINT cms_page_placeholders_pkey PRIMARY KEY (id);


--
-- Name: cms_page_publisher_is_draft_7597e61e0082d3aa_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT cms_page_publisher_is_draft_7597e61e0082d3aa_uniq UNIQUE (publisher_is_draft, site_id, application_namespace);


--
-- Name: cms_page_publisher_public_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT cms_page_publisher_public_id_key UNIQUE (publisher_public_id);


--
-- Name: cms_page_reverse_id_a864144bd3516c9_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT cms_page_reverse_id_a864144bd3516c9_uniq UNIQUE (reverse_id, site_id, publisher_is_draft);


--
-- Name: cms_pagepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_pagepermission
    ADD CONSTRAINT cms_pagepermission_pkey PRIMARY KEY (id);


--
-- Name: cms_pageuser_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_pageuser
    ADD CONSTRAINT cms_pageuser_pkey PRIMARY KEY (user_ptr_id);


--
-- Name: cms_pageusergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_pageusergroup
    ADD CONSTRAINT cms_pageusergroup_pkey PRIMARY KEY (group_ptr_id);


--
-- Name: cms_placeholder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_placeholder
    ADD CONSTRAINT cms_placeholder_pkey PRIMARY KEY (id);


--
-- Name: cms_placeholderreference_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_placeholderreference
    ADD CONSTRAINT cms_placeholderreference_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cms_staticplaceholder_code_6c6b490a9fe0e459_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_staticplaceholder
    ADD CONSTRAINT cms_staticplaceholder_code_6c6b490a9fe0e459_uniq UNIQUE (code, site_id);


--
-- Name: cms_staticplaceholder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_staticplaceholder
    ADD CONSTRAINT cms_staticplaceholder_pkey PRIMARY KEY (id);


--
-- Name: cms_title_language_7a69dc7eaf856287_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_title
    ADD CONSTRAINT cms_title_language_7a69dc7eaf856287_uniq UNIQUE (language, page_id);


--
-- Name: cms_title_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_title
    ADD CONSTRAINT cms_title_pkey PRIMARY KEY (id);


--
-- Name: cms_title_publisher_public_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_title
    ADD CONSTRAINT cms_title_publisher_public_id_key UNIQUE (publisher_public_id);


--
-- Name: cms_usersettings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_usersettings
    ADD CONSTRAINT cms_usersettings_pkey PRIMARY KEY (id);


--
-- Name: cms_usersettings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cms_usersettings
    ADD CONSTRAINT cms_usersettings_user_id_key UNIQUE (user_id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_45f3b1d93ec8c61c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_45f3b1d93ec8c61c_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: djangocms_text_ckeditor_text_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY djangocms_text_ckeditor_text
    ADD CONSTRAINT djangocms_text_ckeditor_text_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: easy_thumbnails_source_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_source_storage_hash_40116450c1e4f2ed_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_storage_hash_40116450c1e4f2ed_uniq UNIQUE (storage_hash, name);


--
-- Name: easy_thumbnails_thumbnail_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnail_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnail_storage_hash_66cc758d07ef9fce_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnail_storage_hash_66cc758d07ef9fce_uniq UNIQUE (storage_hash, name, source_id);


--
-- Name: easy_thumbnails_thumbnaildimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnaildimensions_thumbnail_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_thumbnail_id_key UNIQUE (thumbnail_id);


--
-- Name: filer_clipboard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY filer_clipboard
    ADD CONSTRAINT filer_clipboard_pkey PRIMARY KEY (id);


--
-- Name: filer_clipboarditem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY filer_clipboarditem
    ADD CONSTRAINT filer_clipboarditem_pkey PRIMARY KEY (id);


--
-- Name: filer_file_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY filer_file
    ADD CONSTRAINT filer_file_pkey PRIMARY KEY (id);


--
-- Name: filer_folder_parent_id_30ad83e34d901e49_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY filer_folder
    ADD CONSTRAINT filer_folder_parent_id_30ad83e34d901e49_uniq UNIQUE (parent_id, name);


--
-- Name: filer_folder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY filer_folder
    ADD CONSTRAINT filer_folder_pkey PRIMARY KEY (id);


--
-- Name: filer_folderpermission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY filer_folderpermission
    ADD CONSTRAINT filer_folderpermission_pkey PRIMARY KEY (id);


--
-- Name: filer_image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY filer_image
    ADD CONSTRAINT filer_image_pkey PRIMARY KEY (file_ptr_id);


--
-- Name: menus_cachekey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY menus_cachekey
    ADD CONSTRAINT menus_cachekey_pkey PRIMARY KEY (id);


--
-- Name: reversion_revision_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY reversion_revision
    ADD CONSTRAINT reversion_revision_pkey PRIMARY KEY (id);


--
-- Name: reversion_version_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY reversion_version
    ADD CONSTRAINT reversion_version_pkey PRIMARY KEY (id);


--
-- Name: taggit_tag_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY taggit_tag
    ADD CONSTRAINT taggit_tag_name_key UNIQUE (name);


--
-- Name: taggit_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY taggit_tag
    ADD CONSTRAINT taggit_tag_pkey PRIMARY KEY (id);


--
-- Name: taggit_tag_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY taggit_tag
    ADD CONSTRAINT taggit_tag_slug_key UNIQUE (slug);


--
-- Name: taggit_taggeditem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_pkey PRIMARY KEY (id);


--
-- Name: aldryn_bootstrap3_boostrap3buttonplugin_5b76e141; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_boostrap3buttonplugin_5b76e141 ON aldryn_bootstrap3_boostrap3buttonplugin USING btree (link_page_id);


--
-- Name: aldryn_bootstrap3_boostrap3buttonplugin_6e2e5dae; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_boostrap3buttonplugin_6e2e5dae ON aldryn_bootstrap3_boostrap3buttonplugin USING btree (link_file_id);


--
-- Name: aldryn_bootstrap3_boostrap3imageplugin_814552b9; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_boostrap3imageplugin_814552b9 ON aldryn_bootstrap3_boostrap3imageplugin USING btree (file_id);


--
-- Name: aldryn_bootstrap3_bootstrap3carouselslidefolderplugin_a8a44dbb; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_bootstrap3carouselslidefolderplugin_a8a44dbb ON aldryn_bootstrap3_bootstrap3carouselslidefolderplugin USING btree (folder_id);


--
-- Name: aldryn_bootstrap3_bootstrap3carouselslideplugin_5b76e141; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_bootstrap3carouselslideplugin_5b76e141 ON aldryn_bootstrap3_bootstrap3carouselslideplugin USING btree (link_page_id);


--
-- Name: aldryn_bootstrap3_bootstrap3carouselslideplugin_6e2e5dae; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_bootstrap3carouselslideplugin_6e2e5dae ON aldryn_bootstrap3_bootstrap3carouselslideplugin USING btree (link_file_id);


--
-- Name: aldryn_bootstrap3_bootstrap3carouselslideplugin_f33175e6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_bootstrap3carouselslideplugin_f33175e6 ON aldryn_bootstrap3_bootstrap3carouselslideplugin USING btree (image_id);


--
-- Name: aldryn_bootstrap3_bootstrap3columnplug_tag_800b217631a4aa5_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_bootstrap3columnplug_tag_800b217631a4aa5_like ON aldryn_bootstrap3_bootstrap3columnplugin USING btree (tag varchar_pattern_ops);


--
-- Name: aldryn_bootstrap3_bootstrap3columnplugin_e4d23e84; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_bootstrap3columnplugin_e4d23e84 ON aldryn_bootstrap3_bootstrap3columnplugin USING btree (tag);


--
-- Name: aldryn_bootstrap3_bootstrap3fileplugin_814552b9; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_bootstrap3_bootstrap3fileplugin_814552b9 ON aldryn_bootstrap3_bootstrap3fileplugin USING btree (file_id);


--
-- Name: aldryn_categories_category_0d000fbb; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_categories_category_0d000fbb ON aldryn_categories_category USING btree (rgt);


--
-- Name: aldryn_categories_category_12a055bf; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_categories_category_12a055bf ON aldryn_categories_category USING btree (depth);


--
-- Name: aldryn_categories_category_656442a0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_categories_category_656442a0 ON aldryn_categories_category USING btree (tree_id);


--
-- Name: aldryn_categories_category__language_code_303294cfb3179c92_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_categories_category__language_code_303294cfb3179c92_like ON aldryn_categories_category_translation USING btree (language_code varchar_pattern_ops);


--
-- Name: aldryn_categories_category_caf7cc51; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_categories_category_caf7cc51 ON aldryn_categories_category USING btree (lft);


--
-- Name: aldryn_categories_category_translati_slug_19898e76c68fc88c_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_categories_category_translati_slug_19898e76c68fc88c_like ON aldryn_categories_category_translation USING btree (slug varchar_pattern_ops);


--
-- Name: aldryn_categories_category_translation_2dbcba41; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_categories_category_translation_2dbcba41 ON aldryn_categories_category_translation USING btree (slug);


--
-- Name: aldryn_categories_category_translation_60716c2f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_categories_category_translation_60716c2f ON aldryn_categories_category_translation USING btree (language_code);


--
-- Name: aldryn_categories_category_translation_90349b61; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_categories_category_translation_90349b61 ON aldryn_categories_category_translation USING btree (master_id);


--
-- Name: aldryn_newsblog_article_39b2604d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_39b2604d ON aldryn_newsblog_article USING btree (is_featured);


--
-- Name: aldryn_newsblog_article_40e85b1f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_40e85b1f ON aldryn_newsblog_article USING btree (app_config_id);


--
-- Name: aldryn_newsblog_article_4f331e2f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_4f331e2f ON aldryn_newsblog_article USING btree (author_id);


--
-- Name: aldryn_newsblog_article_5e7b1936; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_5e7b1936 ON aldryn_newsblog_article USING btree (owner_id);


--
-- Name: aldryn_newsblog_article_75892900; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_75892900 ON aldryn_newsblog_article USING btree (is_published);


--
-- Name: aldryn_newsblog_article_categories_a00c1b00; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_categories_a00c1b00 ON aldryn_newsblog_article_categories USING btree (article_id);


--
-- Name: aldryn_newsblog_article_categories_b583a629; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_categories_b583a629 ON aldryn_newsblog_article_categories USING btree (category_id);


--
-- Name: aldryn_newsblog_article_cdbc3e64; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_cdbc3e64 ON aldryn_newsblog_article USING btree (featured_image_id);


--
-- Name: aldryn_newsblog_article_e14f02ad; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_e14f02ad ON aldryn_newsblog_article USING btree (content_id);


--
-- Name: aldryn_newsblog_article_related_58b6ddc3; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_related_58b6ddc3 ON aldryn_newsblog_article_related USING btree (to_article_id);


--
-- Name: aldryn_newsblog_article_related_be73af96; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_related_be73af96 ON aldryn_newsblog_article_related USING btree (from_article_id);


--
-- Name: aldryn_newsblog_article_tran_language_code_f9cb6c0461dc7c4_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_tran_language_code_f9cb6c0461dc7c4_like ON aldryn_newsblog_article_translation USING btree (language_code varchar_pattern_ops);


--
-- Name: aldryn_newsblog_article_translation_2dbcba41; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_translation_2dbcba41 ON aldryn_newsblog_article_translation USING btree (slug);


--
-- Name: aldryn_newsblog_article_translation_60716c2f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_translation_60716c2f ON aldryn_newsblog_article_translation USING btree (language_code);


--
-- Name: aldryn_newsblog_article_translation_90349b61; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_translation_90349b61 ON aldryn_newsblog_article_translation USING btree (master_id);


--
-- Name: aldryn_newsblog_article_translation_slug_6376b6c13e40422a_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_article_translation_slug_6376b6c13e40422a_like ON aldryn_newsblog_article_translation USING btree (slug varchar_pattern_ops);


--
-- Name: aldryn_newsblog_newsblogarchiveplugin_40e85b1f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogarchiveplugin_40e85b1f ON aldryn_newsblog_newsblogarchiveplugin USING btree (app_config_id);


--
-- Name: aldryn_newsblog_newsblogarticlesearchplugin_40e85b1f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogarticlesearchplugin_40e85b1f ON aldryn_newsblog_newsblogarticlesearchplugin USING btree (app_config_id);


--
-- Name: aldryn_newsblog_newsblogauthorsplugin_40e85b1f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogauthorsplugin_40e85b1f ON aldryn_newsblog_newsblogauthorsplugin USING btree (app_config_id);


--
-- Name: aldryn_newsblog_newsblogcategoriesplugin_40e85b1f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogcategoriesplugin_40e85b1f ON aldryn_newsblog_newsblogcategoriesplugin USING btree (app_config_id);


--
-- Name: aldryn_newsblog_newsblogcon_language_code_6a88de0a7d7e0f36_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogcon_language_code_6a88de0a7d7e0f36_like ON aldryn_newsblog_newsblogconfig_translation USING btree (language_code varchar_pattern_ops);


--
-- Name: aldryn_newsblog_newsblogconfig_55561819; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogconfig_55561819 ON aldryn_newsblog_newsblogconfig USING btree (placeholder_base_top_id);


--
-- Name: aldryn_newsblog_newsblogconfig_5918df56; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogconfig_5918df56 ON aldryn_newsblog_newsblogconfig USING btree (placeholder_detail_footer_id);


--
-- Name: aldryn_newsblog_newsblogconfig_7c049d9f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogconfig_7c049d9f ON aldryn_newsblog_newsblogconfig USING btree (placeholder_base_sidebar_id);


--
-- Name: aldryn_newsblog_newsblogconfig_8806551e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogconfig_8806551e ON aldryn_newsblog_newsblogconfig USING btree (placeholder_list_footer_id);


--
-- Name: aldryn_newsblog_newsblogconfig_90b0156f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogconfig_90b0156f ON aldryn_newsblog_newsblogconfig USING btree (placeholder_detail_top_id);


--
-- Name: aldryn_newsblog_newsblogconfig_ba2f8115; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogconfig_ba2f8115 ON aldryn_newsblog_newsblogconfig USING btree (placeholder_list_top_id);


--
-- Name: aldryn_newsblog_newsblogconfig_e2d1ed82; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogconfig_e2d1ed82 ON aldryn_newsblog_newsblogconfig USING btree (placeholder_detail_bottom_id);


--
-- Name: aldryn_newsblog_newsblogconfig_namespace_5c4c821e28ad92ef_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogconfig_namespace_5c4c821e28ad92ef_like ON aldryn_newsblog_newsblogconfig USING btree (namespace varchar_pattern_ops);


--
-- Name: aldryn_newsblog_newsblogconfig_translation_60716c2f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogconfig_translation_60716c2f ON aldryn_newsblog_newsblogconfig_translation USING btree (language_code);


--
-- Name: aldryn_newsblog_newsblogconfig_translation_90349b61; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogconfig_translation_90349b61 ON aldryn_newsblog_newsblogconfig_translation USING btree (master_id);


--
-- Name: aldryn_newsblog_newsblogfeaturedarticlesplugin_40e85b1f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogfeaturedarticlesplugin_40e85b1f ON aldryn_newsblog_newsblogfeaturedarticlesplugin USING btree (app_config_id);


--
-- Name: aldryn_newsblog_newsbloglatestarticlesplugin_40e85b1f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsbloglatestarticlesplugin_40e85b1f ON aldryn_newsblog_newsbloglatestarticlesplugin USING btree (app_config_id);


--
-- Name: aldryn_newsblog_newsblogtagsplugin_40e85b1f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_newsblog_newsblogtagsplugin_40e85b1f ON aldryn_newsblog_newsblogtagsplugin USING btree (app_config_id);


--
-- Name: aldryn_people_group_transla_language_code_700f6f184e8bbb93_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_people_group_transla_language_code_700f6f184e8bbb93_like ON aldryn_people_group_translation USING btree (language_code varchar_pattern_ops);


--
-- Name: aldryn_people_group_translation_60716c2f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_people_group_translation_60716c2f ON aldryn_people_group_translation USING btree (language_code);


--
-- Name: aldryn_people_group_translation_90349b61; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_people_group_translation_90349b61 ON aldryn_people_group_translation USING btree (master_id);


--
-- Name: aldryn_people_peopleplugin_people_7d22caae; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_people_peopleplugin_people_7d22caae ON aldryn_people_peopleplugin_people USING btree (peopleplugin_id);


--
-- Name: aldryn_people_peopleplugin_people_a8452ca7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_people_peopleplugin_people_a8452ca7 ON aldryn_people_peopleplugin_people USING btree (person_id);


--
-- Name: aldryn_people_person_0e939a4f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_people_person_0e939a4f ON aldryn_people_person USING btree (group_id);


--
-- Name: aldryn_people_person_6e0547d0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_people_person_6e0547d0 ON aldryn_people_person USING btree (visual_id);


--
-- Name: aldryn_people_person_slug_15f4ec4dd2e4aa4e_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_people_person_slug_15f4ec4dd2e4aa4e_like ON aldryn_people_person USING btree (slug varchar_pattern_ops);


--
-- Name: aldryn_people_person_transl_language_code_46968449ec3c8a6c_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_people_person_transl_language_code_46968449ec3c8a6c_like ON aldryn_people_person_translation USING btree (language_code varchar_pattern_ops);


--
-- Name: aldryn_people_person_translation_60716c2f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_people_person_translation_60716c2f ON aldryn_people_person_translation USING btree (language_code);


--
-- Name: aldryn_people_person_translation_90349b61; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX aldryn_people_person_translation_90349b61 ON aldryn_people_person_translation USING btree (master_id);


--
-- Name: auth_group_name_253ae2a6331666e8_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_name_253ae2a6331666e8_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_groups_0e939a4f ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_groups_e8701ad4 ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_8373b171 ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_51b3b110094b8aae_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_username_51b3b110094b8aae_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: cms_aliaspluginmodel_921abf5c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_aliaspluginmodel_921abf5c ON cms_aliaspluginmodel USING btree (alias_placeholder_id);


--
-- Name: cms_aliaspluginmodel_b25eaab4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_aliaspluginmodel_b25eaab4 ON cms_aliaspluginmodel USING btree (plugin_id);


--
-- Name: cms_cmsplugin_667a6151; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_cmsplugin_667a6151 ON cms_cmsplugin USING btree (placeholder_id);


--
-- Name: cms_cmsplugin_6be37982; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_cmsplugin_6be37982 ON cms_cmsplugin USING btree (parent_id);


--
-- Name: cms_cmsplugin_8512ae7d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_cmsplugin_8512ae7d ON cms_cmsplugin USING btree (language);


--
-- Name: cms_cmsplugin_b5e4cf8f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_cmsplugin_b5e4cf8f ON cms_cmsplugin USING btree (plugin_type);


--
-- Name: cms_cmsplugin_language_25e8267b6b921b3c_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_cmsplugin_language_25e8267b6b921b3c_like ON cms_cmsplugin USING btree (language varchar_pattern_ops);


--
-- Name: cms_cmsplugin_plugin_type_13246ba49a202411_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_cmsplugin_plugin_type_13246ba49a202411_like ON cms_cmsplugin USING btree (plugin_type varchar_pattern_ops);


--
-- Name: cms_globalpagepermission_0e939a4f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_globalpagepermission_0e939a4f ON cms_globalpagepermission USING btree (group_id);


--
-- Name: cms_globalpagepermission_e8701ad4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_globalpagepermission_e8701ad4 ON cms_globalpagepermission USING btree (user_id);


--
-- Name: cms_globalpagepermission_sites_9365d6e7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_globalpagepermission_sites_9365d6e7 ON cms_globalpagepermission_sites USING btree (site_id);


--
-- Name: cms_globalpagepermission_sites_a3d12ecd; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_globalpagepermission_sites_a3d12ecd ON cms_globalpagepermission_sites USING btree (globalpagepermission_id);


--
-- Name: cms_page_1d85575d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_1d85575d ON cms_page USING btree (soft_root);


--
-- Name: cms_page_2247c5f0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_2247c5f0 ON cms_page USING btree (publication_end_date);


--
-- Name: cms_page_3d9ef52f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_3d9ef52f ON cms_page USING btree (reverse_id);


--
-- Name: cms_page_4fa1c803; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_4fa1c803 ON cms_page USING btree (is_home);


--
-- Name: cms_page_6be37982; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_6be37982 ON cms_page USING btree (parent_id);


--
-- Name: cms_page_7b8acfa6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_7b8acfa6 ON cms_page USING btree (navigation_extenders);


--
-- Name: cms_page_9365d6e7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_9365d6e7 ON cms_page USING btree (site_id);


--
-- Name: cms_page_93b83098; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_93b83098 ON cms_page USING btree (publication_date);


--
-- Name: cms_page_application_urls_55ae69847a069593_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_application_urls_55ae69847a069593_like ON cms_page USING btree (application_urls varchar_pattern_ops);


--
-- Name: cms_page_b7700099; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_b7700099 ON cms_page USING btree (publisher_is_draft);


--
-- Name: cms_page_cb540373; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_cb540373 ON cms_page USING btree (limit_visibility_in_menu);


--
-- Name: cms_page_db3eb53f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_db3eb53f ON cms_page USING btree (in_navigation);


--
-- Name: cms_page_e721871e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_e721871e ON cms_page USING btree (application_urls);


--
-- Name: cms_page_navigation_extenders_273e8b3b3d661759_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_navigation_extenders_273e8b3b3d661759_like ON cms_page USING btree (navigation_extenders varchar_pattern_ops);


--
-- Name: cms_page_placeholders_1a63c800; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_placeholders_1a63c800 ON cms_page_placeholders USING btree (page_id);


--
-- Name: cms_page_placeholders_667a6151; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_placeholders_667a6151 ON cms_page_placeholders USING btree (placeholder_id);


--
-- Name: cms_page_reverse_id_5b199d3a21c59064_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_page_reverse_id_5b199d3a21c59064_like ON cms_page USING btree (reverse_id varchar_pattern_ops);


--
-- Name: cms_pagepermission_0e939a4f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_pagepermission_0e939a4f ON cms_pagepermission USING btree (group_id);


--
-- Name: cms_pagepermission_1a63c800; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_pagepermission_1a63c800 ON cms_pagepermission USING btree (page_id);


--
-- Name: cms_pagepermission_e8701ad4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_pagepermission_e8701ad4 ON cms_pagepermission USING btree (user_id);


--
-- Name: cms_pageuser_e93cb7eb; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_pageuser_e93cb7eb ON cms_pageuser USING btree (created_by_id);


--
-- Name: cms_pageusergroup_e93cb7eb; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_pageusergroup_e93cb7eb ON cms_pageusergroup USING btree (created_by_id);


--
-- Name: cms_placeholder_5e97994e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_placeholder_5e97994e ON cms_placeholder USING btree (slot);


--
-- Name: cms_placeholder_slot_5bd367f0f4cc7d75_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_placeholder_slot_5bd367f0f4cc7d75_like ON cms_placeholder USING btree (slot varchar_pattern_ops);


--
-- Name: cms_placeholderreference_328d0afc; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_placeholderreference_328d0afc ON cms_placeholderreference USING btree (placeholder_ref_id);


--
-- Name: cms_staticplaceholder_1ee2744d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_staticplaceholder_1ee2744d ON cms_staticplaceholder USING btree (public_id);


--
-- Name: cms_staticplaceholder_5cb48773; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_staticplaceholder_5cb48773 ON cms_staticplaceholder USING btree (draft_id);


--
-- Name: cms_staticplaceholder_9365d6e7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_staticplaceholder_9365d6e7 ON cms_staticplaceholder USING btree (site_id);


--
-- Name: cms_title_1268de9a; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_1268de9a ON cms_title USING btree (has_url_overwrite);


--
-- Name: cms_title_1a63c800; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_1a63c800 ON cms_title USING btree (page_id);


--
-- Name: cms_title_2dbcba41; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_2dbcba41 ON cms_title USING btree (slug);


--
-- Name: cms_title_8512ae7d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_8512ae7d ON cms_title USING btree (language);


--
-- Name: cms_title_b7700099; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_b7700099 ON cms_title USING btree (publisher_is_draft);


--
-- Name: cms_title_d6fe1d0b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_d6fe1d0b ON cms_title USING btree (path);


--
-- Name: cms_title_f7202fc0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_f7202fc0 ON cms_title USING btree (publisher_state);


--
-- Name: cms_title_language_485fe28eccda6924_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_language_485fe28eccda6924_like ON cms_title USING btree (language varchar_pattern_ops);


--
-- Name: cms_title_path_340447daeb3069bd_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_path_340447daeb3069bd_like ON cms_title USING btree (path varchar_pattern_ops);


--
-- Name: cms_title_slug_5affc35728a8631_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_title_slug_5affc35728a8631_like ON cms_title USING btree (slug varchar_pattern_ops);


--
-- Name: cms_usersettings_2655b062; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX cms_usersettings_2655b062 ON cms_usersettings USING btree (clipboard_id);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_461cfeaa630ca218_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_session_session_key_461cfeaa630ca218_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: easy_thumbnails_source_b068931c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX easy_thumbnails_source_b068931c ON easy_thumbnails_source USING btree (name);


--
-- Name: easy_thumbnails_source_b454e115; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX easy_thumbnails_source_b454e115 ON easy_thumbnails_source USING btree (storage_hash);


--
-- Name: easy_thumbnails_source_name_30f1630fdb723040_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX easy_thumbnails_source_name_30f1630fdb723040_like ON easy_thumbnails_source USING btree (name varchar_pattern_ops);


--
-- Name: easy_thumbnails_source_storage_hash_67630ca484c5f723_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX easy_thumbnails_source_storage_hash_67630ca484c5f723_like ON easy_thumbnails_source USING btree (storage_hash varchar_pattern_ops);


--
-- Name: easy_thumbnails_thumbnail_0afd9202; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX easy_thumbnails_thumbnail_0afd9202 ON easy_thumbnails_thumbnail USING btree (source_id);


--
-- Name: easy_thumbnails_thumbnail_b068931c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX easy_thumbnails_thumbnail_b068931c ON easy_thumbnails_thumbnail USING btree (name);


--
-- Name: easy_thumbnails_thumbnail_b454e115; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX easy_thumbnails_thumbnail_b454e115 ON easy_thumbnails_thumbnail USING btree (storage_hash);


--
-- Name: easy_thumbnails_thumbnail_name_6faf8e189302c6aa_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX easy_thumbnails_thumbnail_name_6faf8e189302c6aa_like ON easy_thumbnails_thumbnail USING btree (name varchar_pattern_ops);


--
-- Name: easy_thumbnails_thumbnail_storage_hash_31873c4cca5ed053_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX easy_thumbnails_thumbnail_storage_hash_31873c4cca5ed053_like ON easy_thumbnails_thumbnail USING btree (storage_hash varchar_pattern_ops);


--
-- Name: filer_clipboard_e8701ad4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_clipboard_e8701ad4 ON filer_clipboard USING btree (user_id);


--
-- Name: filer_clipboarditem_2655b062; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_clipboarditem_2655b062 ON filer_clipboarditem USING btree (clipboard_id);


--
-- Name: filer_clipboarditem_814552b9; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_clipboarditem_814552b9 ON filer_clipboarditem USING btree (file_id);


--
-- Name: filer_file_5e7b1936; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_file_5e7b1936 ON filer_file USING btree (owner_id);


--
-- Name: filer_file_a8a44dbb; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_file_a8a44dbb ON filer_file USING btree (folder_id);


--
-- Name: filer_file_d3e32c49; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_file_d3e32c49 ON filer_file USING btree (polymorphic_ctype_id);


--
-- Name: filer_folder_3cfbd988; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folder_3cfbd988 ON filer_folder USING btree (rght);


--
-- Name: filer_folder_5e7b1936; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folder_5e7b1936 ON filer_folder USING btree (owner_id);


--
-- Name: filer_folder_656442a0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folder_656442a0 ON filer_folder USING btree (tree_id);


--
-- Name: filer_folder_6be37982; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folder_6be37982 ON filer_folder USING btree (parent_id);


--
-- Name: filer_folder_c9e9a848; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folder_c9e9a848 ON filer_folder USING btree (level);


--
-- Name: filer_folder_caf7cc51; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folder_caf7cc51 ON filer_folder USING btree (lft);


--
-- Name: filer_folderpermission_0e939a4f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folderpermission_0e939a4f ON filer_folderpermission USING btree (group_id);


--
-- Name: filer_folderpermission_a8a44dbb; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folderpermission_a8a44dbb ON filer_folderpermission USING btree (folder_id);


--
-- Name: filer_folderpermission_e8701ad4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX filer_folderpermission_e8701ad4 ON filer_folderpermission USING btree (user_id);


--
-- Name: reversion_revision_b16b0f06; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX reversion_revision_b16b0f06 ON reversion_revision USING btree (manager_slug);


--
-- Name: reversion_revision_c69e55a4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX reversion_revision_c69e55a4 ON reversion_revision USING btree (date_created);


--
-- Name: reversion_revision_e8701ad4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX reversion_revision_e8701ad4 ON reversion_revision USING btree (user_id);


--
-- Name: reversion_revision_manager_slug_54d21219582503b1_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX reversion_revision_manager_slug_54d21219582503b1_like ON reversion_revision USING btree (manager_slug varchar_pattern_ops);


--
-- Name: reversion_version_0c9ba3a3; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX reversion_version_0c9ba3a3 ON reversion_version USING btree (object_id_int);


--
-- Name: reversion_version_417f1b1c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX reversion_version_417f1b1c ON reversion_version USING btree (content_type_id);


--
-- Name: reversion_version_5de09a8d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX reversion_version_5de09a8d ON reversion_version USING btree (revision_id);


--
-- Name: taggit_tag_name_4ed9aad194b72af1_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX taggit_tag_name_4ed9aad194b72af1_like ON taggit_tag USING btree (name varchar_pattern_ops);


--
-- Name: taggit_tag_slug_703438030cd922a7_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX taggit_tag_slug_703438030cd922a7_like ON taggit_tag USING btree (slug varchar_pattern_ops);


--
-- Name: taggit_taggeditem_417f1b1c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX taggit_taggeditem_417f1b1c ON taggit_taggeditem USING btree (content_type_id);


--
-- Name: taggit_taggeditem_76f094bc; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX taggit_taggeditem_76f094bc ON taggit_taggeditem USING btree (tag_id);


--
-- Name: taggit_taggeditem_af31437c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX taggit_taggeditem_af31437c ON taggit_taggeditem USING btree (object_id);


--
-- Name: D0a6bd22b24473d70b225fe1f1aeac94; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT "D0a6bd22b24473d70b225fe1f1aeac94" FOREIGN KEY (placeholder_list_footer_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D0d6e4813a02bb11bd4848fb6afd51a2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT "D0d6e4813a02bb11bd4848fb6afd51a2" FOREIGN KEY (placeholder_base_sidebar_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D1b8a0990dd8c5192e50f2283c15c29d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogauthorsplugin
    ADD CONSTRAINT "D1b8a0990dd8c5192e50f2283c15c29d" FOREIGN KEY (app_config_id) REFERENCES aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D2a6f1e8c63a872ccce27f3cfe47212b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogcategoriesplugin
    ADD CONSTRAINT "D2a6f1e8c63a872ccce27f3cfe47212b" FOREIGN KEY (app_config_id) REFERENCES aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D3a9871747ec3dc23d916e6133a23d32; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogfeaturedarticlesplugin
    ADD CONSTRAINT "D3a9871747ec3dc23d916e6133a23d32" FOREIGN KEY (app_config_id) REFERENCES aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D3d2d3c319cafb2911ff27b5be1f7200; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_article
    ADD CONSTRAINT "D3d2d3c319cafb2911ff27b5be1f7200" FOREIGN KEY (app_config_id) REFERENCES aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D78b1919611212d5b020ee49187da39e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_file
    ADD CONSTRAINT "D78b1919611212d5b020ee49187da39e" FOREIGN KEY (polymorphic_ctype_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D97c2c643e0f7f331072ca1fc75ef6b7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_people_peopleplugin_people
    ADD CONSTRAINT "D97c2c643e0f7f331072ca1fc75ef6b7" FOREIGN KEY (peopleplugin_id) REFERENCES aldryn_people_peopleplugin(cmsplugin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D97e73b352cdfd8346e934c94d84e7d1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogtagsplugin
    ADD CONSTRAINT "D97e73b352cdfd8346e934c94d84e7d1" FOREIGN KEY (app_config_id) REFERENCES aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D9a69b26e1725804a23933e0d81c61b5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogconfig_translation
    ADD CONSTRAINT "D9a69b26e1725804a23933e0d81c61b5" FOREIGN KEY (master_id) REFERENCES aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: a2b9609ee6889b1c2bb4be01c2faa4aa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogarticlesearchplugin
    ADD CONSTRAINT a2b9609ee6889b1c2bb4be01c2faa4aa FOREIGN KEY (app_config_id) REFERENCES aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: a_category_id_515e816c8cdf033c_fk_aldryn_categories_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_article_categories
    ADD CONSTRAINT a_category_id_515e816c8cdf033c_fk_aldryn_categories_category_id FOREIGN KEY (category_id) REFERENCES aldryn_categories_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: a_featured_image_id_27d6e6996d18e496_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_article
    ADD CONSTRAINT a_featured_image_id_27d6e6996d18e496_fk_filer_image_file_ptr_id FOREIGN KEY (featured_image_id) REFERENCES filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ald_to_article_id_fbda2436440d5f6_fk_aldryn_newsblog_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_article_related
    ADD CONSTRAINT ald_to_article_id_fbda2436440d5f6_fk_aldryn_newsblog_article_id FOREIGN KEY (to_article_id) REFERENCES aldryn_newsblog_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldr_master_id_a1f5710864cf9ce_fk_aldryn_categories_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_categories_category_translation
    ADD CONSTRAINT aldr_master_id_a1f5710864cf9ce_fk_aldryn_categories_category_id FOREIGN KEY (master_id) REFERENCES aldryn_categories_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldry_article_id_4c06a4cdf2b7c78d_fk_aldryn_newsblog_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_article_categories
    ADD CONSTRAINT aldry_article_id_4c06a4cdf2b7c78d_fk_aldryn_newsblog_article_id FOREIGN KEY (article_id) REFERENCES aldryn_newsblog_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_10f28053f96a0fcb_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3fileplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_10f28053f96a0fcb_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_1e6f5b935628dca5_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_1e6f5b935628dca5_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_1e85a816567daa14_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3imageplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_1e85a816567daa14_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_22148ed3668c619a_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelfooterplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_22148ed3668c619a_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_23eeaeb886645d41_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3alertplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_23eeaeb886645d41_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_2651d31113e817ef_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3listgroupplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_2651d31113e817ef_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_2b3c18f7e511e08b_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3columnplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_2b3c18f7e511e08b_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_32bed68319625dd3_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslidefolderplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_32bed68319625dd3_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_415e45f04c4848ab_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3iconplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_415e45f04c4848ab_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_463718163e0564e6_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3accordionplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_463718163e0564e6_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_48bad58968d2fd4a_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3rowplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_48bad58968d2fd4a_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_4c0f8730c123eb96_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3buttonplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_4c0f8730c123eb96_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_54010a691c1d39b7_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3labelplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_54010a691c1d39b7_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_5c15de90480dda7b_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3blockquoteplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_5c15de90480dda7b_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_5cf00348e3810a4f_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslideplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_5cf00348e3810a4f_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_5f4d0d45dd074b98_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelheadingplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_5f4d0d45dd074b98_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_6a538d3eba92ea30_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3listgroupitemplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_6a538d3eba92ea30_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_70bde3480e8969d9_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelbodyplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_70bde3480e8969d9_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_74bba5aabb3eb3b1_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3panelplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_74bba5aabb3eb3b1_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_78fe6a94db1bb1e6_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3spacerplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_78fe6a94db1bb1e6_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_7964362dcd0d9783_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3accordionitemplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_7964362dcd0d9783_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bo_cmsplugin_ptr_id_7be7b408bae60dd0_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3wellplugin
    ADD CONSTRAINT aldryn_bo_cmsplugin_ptr_id_7be7b408bae60dd0_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_boo_image_id_4c92230673adeea7_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslideplugin
    ADD CONSTRAINT aldryn_boo_image_id_4c92230673adeea7_fk_filer_image_file_ptr_id FOREIGN KEY (image_id) REFERENCES filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_boot_file_id_661c0051c20cb6f6_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3imageplugin
    ADD CONSTRAINT aldryn_boot_file_id_661c0051c20cb6f6_fk_filer_image_file_ptr_id FOREIGN KEY (file_id) REFERENCES filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bootstrap3__link_page_id_74458fee04d19791_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3buttonplugin
    ADD CONSTRAINT aldryn_bootstrap3__link_page_id_74458fee04d19791_fk_cms_page_id FOREIGN KEY (link_page_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bootstrap3_b_link_page_id_ebaa817f8d1cb4a_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslideplugin
    ADD CONSTRAINT aldryn_bootstrap3_b_link_page_id_ebaa817f8d1cb4a_fk_cms_page_id FOREIGN KEY (link_page_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bootstrap3_boo_file_id_170c7e6e5e6a0cb7_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3fileplugin
    ADD CONSTRAINT aldryn_bootstrap3_boo_file_id_170c7e6e5e6a0cb7_fk_filer_file_id FOREIGN KEY (file_id) REFERENCES filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bootstrap3_folder_id_369f5f84bcd59c11_fk_filer_folder_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslidefolderplugin
    ADD CONSTRAINT aldryn_bootstrap3_folder_id_369f5f84bcd59c11_fk_filer_folder_id FOREIGN KEY (folder_id) REFERENCES filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bootstrap_link_file_id_473a2399daa5f493_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_bootstrap3carouselslideplugin
    ADD CONSTRAINT aldryn_bootstrap_link_file_id_473a2399daa5f493_fk_filer_file_id FOREIGN KEY (link_file_id) REFERENCES filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_bootstrap_link_file_id_7a62a38be957d76e_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_bootstrap3_boostrap3buttonplugin
    ADD CONSTRAINT aldryn_bootstrap_link_file_id_7a62a38be957d76e_fk_filer_file_id FOREIGN KEY (link_file_id) REFERENCES filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_master_id_5b41b9b68fff6578_fk_aldryn_newsblog_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_article_translation
    ADD CONSTRAINT aldryn_master_id_5b41b9b68fff6578_fk_aldryn_newsblog_article_id FOREIGN KEY (master_id) REFERENCES aldryn_newsblog_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_ne_author_id_3e34d5b39e3c8e6b_fk_aldryn_people_person_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_article
    ADD CONSTRAINT aldryn_ne_author_id_3e34d5b39e3c8e6b_fk_aldryn_people_person_id FOREIGN KEY (author_id) REFERENCES aldryn_people_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_ne_cmsplugin_ptr_id_11e965a81d23920a_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogfeaturedarticlesplugin
    ADD CONSTRAINT aldryn_ne_cmsplugin_ptr_id_11e965a81d23920a_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_ne_cmsplugin_ptr_id_331a28b3017dd34b_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogcategoriesplugin
    ADD CONSTRAINT aldryn_ne_cmsplugin_ptr_id_331a28b3017dd34b_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_ne_cmsplugin_ptr_id_396e8a4b2dda959b_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsbloglatestarticlesplugin
    ADD CONSTRAINT aldryn_ne_cmsplugin_ptr_id_396e8a4b2dda959b_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_ne_cmsplugin_ptr_id_3a052cfc51b75e32_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogtagsplugin
    ADD CONSTRAINT aldryn_ne_cmsplugin_ptr_id_3a052cfc51b75e32_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_ne_cmsplugin_ptr_id_470e64e798a49696_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogarticlesearchplugin
    ADD CONSTRAINT aldryn_ne_cmsplugin_ptr_id_470e64e798a49696_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_ne_cmsplugin_ptr_id_594e771e75057123_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogrelatedplugin
    ADD CONSTRAINT aldryn_ne_cmsplugin_ptr_id_594e771e75057123_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_new_cmsplugin_ptr_id_7c0b3c0a7553e06_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogauthorsplugin
    ADD CONSTRAINT aldryn_new_cmsplugin_ptr_id_7c0b3c0a7553e06_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_new_cmsplugin_ptr_id_9b26e86ee3af454_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogarchiveplugin
    ADD CONSTRAINT aldryn_new_cmsplugin_ptr_id_9b26e86ee3af454_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsbl_content_id_35a9a957d6e39d78_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_article
    ADD CONSTRAINT aldryn_newsbl_content_id_35a9a957d6e39d78_fk_cms_placeholder_id FOREIGN KEY (content_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_articl_owner_id_60975a935474b44_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_article
    ADD CONSTRAINT aldryn_newsblog_articl_owner_id_60975a935474b44_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_pe_cmsplugin_ptr_id_7160bd381dccf5db_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_people_peopleplugin
    ADD CONSTRAINT aldryn_pe_cmsplugin_ptr_id_7160bd381dccf5db_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_pe_master_id_57558ff868697ee8_fk_aldryn_people_person_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_people_person_translation
    ADD CONSTRAINT aldryn_pe_master_id_57558ff868697ee8_fk_aldryn_people_person_id FOREIGN KEY (master_id) REFERENCES aldryn_people_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_pe_visual_id_6a1f1d0fbcdf9ac2_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_people_person
    ADD CONSTRAINT aldryn_pe_visual_id_6a1f1d0fbcdf9ac2_fk_filer_image_file_ptr_id FOREIGN KEY (visual_id) REFERENCES filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_peo_master_id_209df5526d4c1401_fk_aldryn_people_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_people_group_translation
    ADD CONSTRAINT aldryn_peo_master_id_209df5526d4c1401_fk_aldryn_people_group_id FOREIGN KEY (master_id) REFERENCES aldryn_people_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_peo_person_id_b9e861036378099_fk_aldryn_people_person_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_people_peopleplugin_people
    ADD CONSTRAINT aldryn_peo_person_id_b9e861036378099_fk_aldryn_people_person_id FOREIGN KEY (person_id) REFERENCES aldryn_people_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_peop_group_id_3944d5eea384fb80_fk_aldryn_people_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_people_person
    ADD CONSTRAINT aldryn_peop_group_id_3944d5eea384fb80_fk_aldryn_people_group_id FOREIGN KEY (group_id) REFERENCES aldryn_people_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_people_person_user_id_79139e030003f547_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_people_person
    ADD CONSTRAINT aldryn_people_person_user_id_79139e030003f547_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_st_cmsplugin_ptr_id_6e4aecc2c939ab40_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_style_style
    ADD CONSTRAINT aldryn_st_cmsplugin_ptr_id_6e4aecc2c939ab40_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_content_type_id_508cf46651277a81_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_content_type_id_508cf46651277a81_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user__permission_id_384b62483d7071f0_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user__permission_id_384b62483d7071f0_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permiss_user_id_7f0938558328534a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permiss_user_id_7f0938558328534a_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: b65bf0fabc223e29bf8c0438f283294d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogarchiveplugin
    ADD CONSTRAINT b65bf0fabc223e29bf8c0438f283294d FOREIGN KEY (app_config_id) REFERENCES aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_alias_placeholder_id_19ff87f4b6506f7d_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_aliaspluginmodel
    ADD CONSTRAINT cms_alias_placeholder_id_19ff87f4b6506f7d_fk_cms_placeholder_id FOREIGN KEY (alias_placeholder_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_aliasp_cmsplugin_ptr_id_a146238a4a634c4_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_aliaspluginmodel
    ADD CONSTRAINT cms_aliasp_cmsplugin_ptr_id_a146238a4a634c4_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_aliaspluginm_plugin_id_6cb0e8f62e7b802f_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_aliaspluginmodel
    ADD CONSTRAINT cms_aliaspluginm_plugin_id_6cb0e8f62e7b802f_fk_cms_cmsplugin_id FOREIGN KEY (plugin_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_cmspl_placeholder_id_45e08772be34ec0f_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_cmsplugin
    ADD CONSTRAINT cms_cmspl_placeholder_id_45e08772be34ec0f_fk_cms_placeholder_id FOREIGN KEY (placeholder_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_cmsplugin_parent_id_3227a3752b89b923_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_cmsplugin
    ADD CONSTRAINT cms_cmsplugin_parent_id_3227a3752b89b923_fk_cms_cmsplugin_id FOREIGN KEY (parent_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_globalpagepermis_group_id_5495c04a8b715951_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_globalpagepermission
    ADD CONSTRAINT cms_globalpagepermis_group_id_5495c04a8b715951_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_globalpagepermis_site_id_2805b267618ef941_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_globalpagepermission_sites
    ADD CONSTRAINT cms_globalpagepermis_site_id_2805b267618ef941_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_globalpagepermissi_user_id_5b7e387d572f1d18_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_globalpagepermission
    ADD CONSTRAINT cms_globalpagepermissi_user_id_5b7e387d572f1d18_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_p_placeholder_ref_id_6d7ea115a2f488ec_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_placeholderreference
    ADD CONSTRAINT cms_p_placeholder_ref_id_6d7ea115a2f488ec_fk_cms_placeholder_id FOREIGN KEY (placeholder_ref_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_page__placeholder_id_1e2710bd8c76d9ad_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_page_placeholders
    ADD CONSTRAINT cms_page__placeholder_id_1e2710bd8c76d9ad_fk_cms_placeholder_id FOREIGN KEY (placeholder_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_page_parent_id_3a1df0ef76fe1197_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT cms_page_parent_id_3a1df0ef76fe1197_fk_cms_page_id FOREIGN KEY (parent_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_page_placeholders_page_id_2339fb692425adb6_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_page_placeholders
    ADD CONSTRAINT cms_page_placeholders_page_id_2339fb692425adb6_fk_cms_page_id FOREIGN KEY (page_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_page_publisher_public_id_6d3414df27b14e29_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT cms_page_publisher_public_id_6d3414df27b14e29_fk_cms_page_id FOREIGN KEY (publisher_public_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_page_site_id_74f6849b7245e838_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_page
    ADD CONSTRAINT cms_page_site_id_74f6849b7245e838_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pagepermission_group_id_39f298fdb5026_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pagepermission
    ADD CONSTRAINT cms_pagepermission_group_id_39f298fdb5026_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pagepermission_page_id_214a878c4fb6ec65_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pagepermission
    ADD CONSTRAINT cms_pagepermission_page_id_214a878c4fb6ec65_fk_cms_page_id FOREIGN KEY (page_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pagepermission_user_id_b6429a51a3e8e53_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pagepermission
    ADD CONSTRAINT cms_pagepermission_user_id_b6429a51a3e8e53_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pageuser_created_by_id_18eb7aa0ce6f1c16_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pageuser
    ADD CONSTRAINT cms_pageuser_created_by_id_18eb7aa0ce6f1c16_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pageuser_user_ptr_id_7b1c6e2f6b58ccde_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pageuser
    ADD CONSTRAINT cms_pageuser_user_ptr_id_7b1c6e2f6b58ccde_fk_auth_user_id FOREIGN KEY (user_ptr_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pageusergrou_group_ptr_id_2fed9cde9e11700f_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pageusergroup
    ADD CONSTRAINT cms_pageusergrou_group_ptr_id_2fed9cde9e11700f_fk_auth_group_id FOREIGN KEY (group_ptr_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pageusergroup_created_by_id_53218d1b0250196_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_pageusergroup
    ADD CONSTRAINT cms_pageusergroup_created_by_id_53218d1b0250196_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_place_cmsplugin_ptr_id_57d93b52c864bee6_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_placeholderreference
    ADD CONSTRAINT cms_place_cmsplugin_ptr_id_57d93b52c864bee6_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_staticplac_public_id_20b32af3aef57809_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_staticplaceholder
    ADD CONSTRAINT cms_staticplac_public_id_20b32af3aef57809_fk_cms_placeholder_id FOREIGN KEY (public_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_staticplace_draft_id_6c2edc7f36488820_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_staticplaceholder
    ADD CONSTRAINT cms_staticplace_draft_id_6c2edc7f36488820_fk_cms_placeholder_id FOREIGN KEY (draft_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_staticplaceholde_site_id_65c8a138163af08f_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_staticplaceholder
    ADD CONSTRAINT cms_staticplaceholde_site_id_65c8a138163af08f_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_title_page_id_527ebd61f3936a12_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_title
    ADD CONSTRAINT cms_title_page_id_527ebd61f3936a12_fk_cms_page_id FOREIGN KEY (page_id) REFERENCES cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_title_publisher_public_id_74e956b52b3e4a1d_fk_cms_title_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_title
    ADD CONSTRAINT cms_title_publisher_public_id_74e956b52b3e4a1d_fk_cms_title_id FOREIGN KEY (publisher_public_id) REFERENCES cms_title(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_userset_clipboard_id_15eac87d124304f3_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_usersettings
    ADD CONSTRAINT cms_userset_clipboard_id_15eac87d124304f3_fk_cms_placeholder_id FOREIGN KEY (clipboard_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_usersettings_user_id_2cfe7a2128ccc2b3_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_usersettings
    ADD CONSTRAINT cms_usersettings_user_id_2cfe7a2128ccc2b3_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ded25e628a45184c02ca255994174c87; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT ded25e628a45184c02ca255994174c87 FOREIGN KEY (placeholder_detail_top_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djan_content_type_id_697914295151027a_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT djan_content_type_id_697914295151027a_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_cmsplugin_ptr_id_5cfb7ff7d38a35c0_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY djangocms_text_ckeditor_text
    ADD CONSTRAINT djangocms_cmsplugin_ptr_id_5cfb7ff7d38a35c0_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: e1f6e04d85328b41a00c7676eee76587; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cms_globalpagepermission_sites
    ADD CONSTRAINT e1f6e04d85328b41a00c7676eee76587 FOREIGN KEY (globalpagepermission_id) REFERENCES cms_globalpagepermission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: e5daf9c62052dfedce01dcb8cea197a0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT e5daf9c62052dfedce01dcb8cea197a0 FOREIGN KEY (placeholder_detail_bottom_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: e_thumbnail_id_29ad34faceb3c17c_fk_easy_thumbnails_thumbnail_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT e_thumbnail_id_29ad34faceb3c17c_fk_easy_thumbnails_thumbnail_id FOREIGN KEY (thumbnail_id) REFERENCES easy_thumbnails_thumbnail(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: easy_th_source_id_50b260de7106e1b7_fk_easy_thumbnails_source_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_th_source_id_50b260de7106e1b7_fk_easy_thumbnails_source_id FOREIGN KEY (source_id) REFERENCES easy_thumbnails_source(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: f129a2413cc90ab6934f0cdcb8501b92; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT f129a2413cc90ab6934f0cdcb8501b92 FOREIGN KEY (placeholder_detail_footer_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: f74fe9d18155cad962aeddc19dc9e3ac; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsbloglatestarticlesplugin
    ADD CONSTRAINT f74fe9d18155cad962aeddc19dc9e3ac FOREIGN KEY (app_config_id) REFERENCES aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_clipb_clipboard_id_335d159e1aea2cdc_fk_filer_clipboard_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_clipboarditem
    ADD CONSTRAINT filer_clipb_clipboard_id_335d159e1aea2cdc_fk_filer_clipboard_id FOREIGN KEY (clipboard_id) REFERENCES filer_clipboard(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_clipboard_user_id_2b30c76f2cd235df_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_clipboard
    ADD CONSTRAINT filer_clipboard_user_id_2b30c76f2cd235df_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_clipboarditem_file_id_7b1b6a14b5a3f2b1_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_clipboarditem
    ADD CONSTRAINT filer_clipboarditem_file_id_7b1b6a14b5a3f2b1_fk_filer_file_id FOREIGN KEY (file_id) REFERENCES filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_file_folder_id_24318dda71f59785_fk_filer_folder_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_file
    ADD CONSTRAINT filer_file_folder_id_24318dda71f59785_fk_filer_folder_id FOREIGN KEY (folder_id) REFERENCES filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_file_owner_id_67317c663ea33283_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_file
    ADD CONSTRAINT filer_file_owner_id_67317c663ea33283_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_folder_owner_id_6527f5f13a76f3ed_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_folder
    ADD CONSTRAINT filer_folder_owner_id_6527f5f13a76f3ed_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_folder_parent_id_4170098ac31c2cbf_fk_filer_folder_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_folder
    ADD CONSTRAINT filer_folder_parent_id_4170098ac31c2cbf_fk_filer_folder_id FOREIGN KEY (parent_id) REFERENCES filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_folderpermi_folder_id_442a5347ee209a98_fk_filer_folder_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_folderpermission
    ADD CONSTRAINT filer_folderpermi_folder_id_442a5347ee209a98_fk_filer_folder_id FOREIGN KEY (folder_id) REFERENCES filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_folderpermissi_group_id_7c2389ac07ebbde2_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_folderpermission
    ADD CONSTRAINT filer_folderpermissi_group_id_7c2389ac07ebbde2_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_folderpermission_user_id_7c6e1a7187a0f15b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_folderpermission
    ADD CONSTRAINT filer_folderpermission_user_id_7c6e1a7187a0f15b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_image_file_ptr_id_1dde9ad32bce39a6_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filer_image
    ADD CONSTRAINT filer_image_file_ptr_id_1dde9ad32bce39a6_fk_filer_file_id FOREIGN KEY (file_ptr_id) REFERENCES filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: from_article_id_4705fc830e4d1981_fk_aldryn_newsblog_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_article_related
    ADD CONSTRAINT from_article_id_4705fc830e4d1981_fk_aldryn_newsblog_article_id FOREIGN KEY (from_article_id) REFERENCES aldryn_newsblog_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: placeholder_base_top_id_6f679abc3118e5d3_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT placeholder_base_top_id_6f679abc3118e5d3_fk_cms_placeholder_id FOREIGN KEY (placeholder_base_top_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: placeholder_list_top_id_39cda3ff846a59a4_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT placeholder_list_top_id_39cda3ff846a59a4_fk_cms_placeholder_id FOREIGN KEY (placeholder_list_top_id) REFERENCES cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rever_content_type_id_c01a11926d4c4a9_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reversion_version
    ADD CONSTRAINT rever_content_type_id_c01a11926d4c4a9_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reversion__revision_id_48ec3744916a950_fk_reversion_revision_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reversion_version
    ADD CONSTRAINT reversion__revision_id_48ec3744916a950_fk_reversion_revision_id FOREIGN KEY (revision_id) REFERENCES reversion_revision(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reversion_revision_user_id_53d027e45b2ec55e_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reversion_revision
    ADD CONSTRAINT reversion_revision_user_id_53d027e45b2ec55e_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tagg_content_type_id_62e0524705c3ec8f_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY taggit_taggeditem
    ADD CONSTRAINT tagg_content_type_id_62e0524705c3ec8f_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: taggit_taggeditem_tag_id_6318217c0d95e0d2_fk_taggit_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_tag_id_6318217c0d95e0d2_fk_taggit_tag_id FOREIGN KEY (tag_id) REFERENCES taggit_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: finalangel
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM finalangel;
GRANT ALL ON SCHEMA public TO finalangel;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

